#include <Arduino.h>

// ==========================================
// 0. Name of this station (appears in the Station column in the files)
// When we set up an ESP for a new station, we change only this line
// ==========================================
#define STATION_NAME "Grabber"

// ==========================================
// 1. Pins Definitions
// ==========================================
// Reference Switches
#define REF_SWITCH_VERTICAL_AXIS       36
#define REF_SWITCH_HORIZONTAL_AXIS     39
#define REF_SWITCH_ROTATE              34

// Encoders
#define ENC_VERT_AXIS_IMPULSE_1        35
#define ENC_VERT_AXIS_IMPULSE_2        32
#define ENC_HORZ_AXIS_IMPULSE_1        33
#define ENC_HORZ_AXIS_IMPULSE_2        25
#define ENC_ROTATE_IMPULSE_1           26
#define ENC_ROTATE_IMPULSE_2           27

// Motors & Vacuum
#define MOTOR_VERT_AXIS_UP             16
#define MOTOR_VERT_AXIS_DOWN           17
#define MOTOR_HORZ_AXIS_BACKWARD       4
#define MOTOR_HORZ_AXIS_FORWARD        18
#define MOTOR_ROTATE_CLOCKWISE         19
#define MOTOR_ROTATE_COUNTERCLOCKWISE  21
#define COMPRESSOR                     22
#define VALVE_VACUUM                   23

volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int rotatePulseCount     = 0;

volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;
volatile int8_t rotateMoveDirection     = 0;

const int8_t encoder_table[16] = {
   0, -1,  1,  0,
   1,  0,  0, -1,
  -1,  0,  0,  1,
   0,  1, -1,  0
};

// ==========================================
// 1.b Periodic Logger variables (every 20ms)
// ==========================================
unsigned long lastLogTime = 0;
const unsigned long LOG_INTERVAL_MS = 20;

// ==========================================
// 1.c Event Logger variables (for precise measurement on the ESP32)
// ==========================================
const int NUM_TRACKED_PINS = 11;

// Pin names (same order as the periodic logger)
const char* PIN_NAMES[NUM_TRACKED_PINS] = {
  "REF_SWITCH_VERTICAL_AXIS",
  "REF_SWITCH_HORIZONTAL_AXIS",
  "REF_SWITCH_ROTATE",
  "MOTOR_VERT_AXIS_UP",
  "MOTOR_VERT_AXIS_DOWN",
  "MOTOR_HORZ_AXIS_BACKWARD",
  "MOTOR_HORZ_AXIS_FORWARD",
  "MOTOR_ROTATE_CLOCKWISE",
  "MOTOR_ROTATE_COUNTERCLOCKWISE",
  "COMPRESSOR",
  "VALVE_VACUUM"
};

const int PIN_NUMBERS[NUM_TRACKED_PINS] = {
  REF_SWITCH_VERTICAL_AXIS,
  REF_SWITCH_HORIZONTAL_AXIS,
  REF_SWITCH_ROTATE,
  MOTOR_VERT_AXIS_UP,
  MOTOR_VERT_AXIS_DOWN,
  MOTOR_HORZ_AXIS_BACKWARD,
  MOTOR_HORZ_AXIS_FORWARD,
  MOTOR_ROTATE_CLOCKWISE,
  MOTOR_ROTATE_COUNTERCLOCKWISE,
  COMPRESSOR,
  VALVE_VACUUM
};

// Last known state for each pin
int lastPinStates[NUM_TRACKED_PINS];

// Last change time for each pin (in milliseconds)
unsigned long lastChangeTime[NUM_TRACKED_PINS];

// Debouncing variables: to ignore fast electrical fluctuations
int candidateState[NUM_TRACKED_PINS];        // The new candidate state
unsigned long candidateSince[NUM_TRACKED_PINS]; // When the candidate state started
const unsigned long DEBOUNCE_MS = 5;          // The state must stay stable for 5ms before being considered a change

// The trigger flag and t=0
// ⚠️ In the Grabber: t_zero comes from the Bridge via a SET_T_ZERO command
//    (not from self-detecting a pin change like HBW)
// Reason: the actual trigger for the whole factory = MOTOR_HORZ_TO_RACK=HIGH at HBW
// and the Grabber cannot detect it, so the Bridge tells it when it happens
bool esp_trigger_seen = false;
unsigned long esp_t_zero = 0;

const unsigned long EVT_MIN_DURATION_MS = 20;  // Ignore changes shorter than 20ms

// ==========================================
// 1.c.1 Rounding function to the nearest 10ms (same as q10 in Python)
// ==========================================
unsigned long q10(unsigned long x) {
  return ((x + 5) / 10) * 10;
}

// ==========================================
// 1.d Function to print periodic Pin states (every 20ms) for the bridge/sender
// with the station name prefix (Station,timestamp,p1,p2,...)
// ==========================================
void printPinStates() {
  unsigned long now = millis();
  if (now - lastLogTime < LOG_INTERVAL_MS) return;
  lastLogTime = now;
  
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.print(now);
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_VERTICAL_AXIS));
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_HORIZONTAL_AXIS));
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_ROTATE));
  Serial.print(","); Serial.print(digitalRead(MOTOR_VERT_AXIS_UP));
  Serial.print(","); Serial.print(digitalRead(MOTOR_VERT_AXIS_DOWN));
  Serial.print(","); Serial.print(digitalRead(MOTOR_HORZ_AXIS_BACKWARD));
  Serial.print(","); Serial.print(digitalRead(MOTOR_HORZ_AXIS_FORWARD));
  Serial.print(","); Serial.print(digitalRead(MOTOR_ROTATE_CLOCKWISE));
  Serial.print(","); Serial.print(digitalRead(MOTOR_ROTATE_COUNTERCLOCKWISE));
  Serial.print(","); Serial.print(digitalRead(COMPRESSOR));
  Serial.print(","); Serial.println(digitalRead(VALVE_VACUUM));
}

// ==========================================
// 1.e Function to check Pin changes and print EVT for precise measurement
// ==========================================
void checkPinChanges() {
  unsigned long now = millis();
  
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int cur = digitalRead(PIN_NUMBERS[i]);
    
    // If the current state == the last confirmed state -> no change, cancel any old candidate
    if (cur == lastPinStates[i]) {
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;
    }
    
    // The current state differs from lastPinStates[i]
    // -> we must confirm it lasted DEBOUNCE_MS before considering it a real change
    
    if (cur != candidateState[i]) {
      // The candidate state changed for the first time -> start counting from now
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;  // Not confirmed yet
    }
    
    // The candidate state is stable, confirm it has settled long enough
    if (now - candidateSince[i] < DEBOUNCE_MS) {
      continue;  // Not settled long enough yet
    }
    
    // ✅ Confirmed: a real change
    // The real change time = candidateSince[i] (the moment the new state began)
    unsigned long change_time = candidateSince[i];
    
    // Before the trigger: only update the state without printing
    // (the trigger comes from the Bridge as a SET_T_ZERO command, not from self-detection)
    if (!esp_trigger_seen) {
      lastPinStates[i] = cur;
      lastChangeTime[i] = change_time;
      continue;
    }
    
    // After the trigger: calculate the duration and print
    unsigned long duration = change_time - lastChangeTime[i];
    
    if (duration > EVT_MIN_DURATION_MS) {
      unsigned long rel_time = change_time - esp_t_zero;
      // Format: EVT,Station,RelativeTime,Pin,NewState,Duration
      // Rounded to the nearest 10ms (same as Python q10)
      Serial.print("EVT,");
      Serial.print(STATION_NAME);
      Serial.print(",");
      Serial.print(q10(rel_time));
      Serial.print(",");
      Serial.print(PIN_NAMES[i]);
      Serial.print(",");
      Serial.print(cur);
      Serial.print(",");
      Serial.println(q10(duration));
    }
    
    lastPinStates[i] = cur;
    lastChangeTime[i] = change_time;
  }
}

// ==========================================
// 1.f Function to set t_zero via a command from the Bridge
// ==========================================
void setTriggerFromBridge() {
  if (esp_trigger_seen) return;  // Ignore any additional command
  
  unsigned long now = millis();
  esp_t_zero = now;
  esp_trigger_seen = true;
  
  // Set lastChangeTime for all pins to the trigger time
  // (same logic as HBW)
  for (int j = 0; j < NUM_TRACKED_PINS; j++) {
    lastChangeTime[j] = esp_t_zero;
    lastPinStates[j] = digitalRead(PIN_NUMBERS[j]);
    candidateState[j] = lastPinStates[j];
    candidateSince[j] = esp_t_zero;
  }
  
  // Print TRIGGER as a start marker (Pin = SYSTEM_TRIGGER, State = 1, Duration = 0)
  // Format: EVT,Station,RelativeTime,Pin,NewState,Duration
  Serial.print("EVT,");
  Serial.print(STATION_NAME);
  Serial.print(",0,SYSTEM_TRIGGER,1,0");
  Serial.println();
}

void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 1) verticalPulseCount++;
  else if (verticalMoveDirection == -1) verticalPulseCount--;
}

void IRAM_ATTR handleRotateEncoder() {
  static uint8_t lastState = 0;
  if (rotateMoveDirection == 0) return;
  uint8_t cur = (digitalRead(ENC_ROTATE_IMPULSE_1) << 1) | digitalRead(ENC_ROTATE_IMPULSE_2);
  rotatePulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  static uint8_t lastState = 0;
  if (horizontalMoveDirection == 0) return;
  uint8_t cur = (digitalRead(ENC_HORZ_AXIS_IMPULSE_1) << 1) | digitalRead(ENC_HORZ_AXIS_IMPULSE_2);
  horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

// ==========================================
// 2. Function to translate names into port numbers
// ==========================================
int getPinFromName(String pinName) {
  pinName.trim();
  if (pinName == "REF_SWITCH_VERTICAL_AXIS")      return 36;
  if (pinName == "REF_SWITCH_HORIZONTAL_AXIS")    return 39;
  if (pinName == "REF_SWITCH_ROTATE")             return 34;
  if (pinName == "MOTOR_VERT_AXIS_UP")            return 16;
  if (pinName == "MOTOR_VERT_AXIS_DOWN")          return 17;
  if (pinName == "MOTOR_HORZ_AXIS_BACKWARD")      return 4;
  if (pinName == "MOTOR_HORZ_AXIS_FORWARD")       return 18;
  if (pinName == "MOTOR_ROTATE_CLOCKWISE")        return 19;
  if (pinName == "MOTOR_ROTATE_COUNTERCLOCKWISE") return 21;
  if (pinName == "COMPRESSOR")                    return 22;
  if (pinName == "VALVE_VACUUM")                  return 23;
  
  return pinName.toInt(); 
}

// ==========================================
// 3. Setup
// ==========================================
void setupPins() {
  pinMode(REF_SWITCH_VERTICAL_AXIS,   INPUT_PULLUP);
  pinMode(REF_SWITCH_HORIZONTAL_AXIS, INPUT_PULLUP);
  pinMode(REF_SWITCH_ROTATE,          INPUT_PULLUP);

  pinMode(ENC_VERT_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_VERT_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_ROTATE_IMPULSE_1,    INPUT);
  pinMode(ENC_ROTATE_IMPULSE_2,    INPUT);

  pinMode(MOTOR_VERT_AXIS_UP,              OUTPUT);
  pinMode(MOTOR_VERT_AXIS_DOWN,            OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_BACKWARD,        OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_FORWARD,         OUTPUT);
  pinMode(MOTOR_ROTATE_CLOCKWISE,          OUTPUT);
  pinMode(MOTOR_ROTATE_COUNTERCLOCKWISE,   OUTPUT);
  pinMode(COMPRESSOR,                      OUTPUT);
  pinMode(VALVE_VACUUM,                    OUTPUT);

  digitalWrite(MOTOR_VERT_AXIS_UP,            LOW);
  digitalWrite(MOTOR_VERT_AXIS_DOWN,          LOW);
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD,      LOW);
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD,       LOW);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE,        LOW);
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW);
  digitalWrite(COMPRESSOR,                    LOW);
  digitalWrite(VALVE_VACUUM,                  LOW);

  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_1), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_2), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_1),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_2),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_2), handleHorizontalEncoder, CHANGE);
}

void setup() {
  Serial.setRxBufferSize(1024);
  Serial.begin(115200);
  setupPins();
  
  // Initialize the last known state for each pin + debouncing variables
  unsigned long now_init = millis();
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int initial_state = digitalRead(PIN_NUMBERS[i]);
    lastPinStates[i]  = initial_state;
    lastChangeTime[i] = now_init;
    candidateState[i] = initial_state;   // ⚠️ Important: initialize with the same known state
    candidateSince[i] = now_init;
  }
  
  // Print the Header once at startup
  // Format: Station,timestamp(ms),pin1,pin2,...
  delay(500);
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.println(
    "timestamp(ms),"
    "REF_SWITCH_VERTICAL_AXIS,REF_SWITCH_HORIZONTAL_AXIS,REF_SWITCH_ROTATE,"
    "MOTOR_VERT_AXIS_UP,MOTOR_VERT_AXIS_DOWN,"
    "MOTOR_HORZ_AXIS_BACKWARD,MOTOR_HORZ_AXIS_FORWARD,"
    "MOTOR_ROTATE_CLOCKWISE,MOTOR_ROTATE_COUNTERCLOCKWISE,"
    "COMPRESSOR,VALVE_VACUUM"
  );
}

// ==========================================
// 4. Forward declarations of functions
// ==========================================
void executeCommand(String command);
void executeSingleCommand(String command);
bool evaluateCondition(String condition);

// ==========================================
// 4.b Global variable for the Serial buffer (used in loop and inside while loops)
// ==========================================
String incomingCommand = "";

// ==========================================
// 5. Smart execution functions
// ==========================================
void executeCommand(String command) {
  command.trim();
  
  while (command.length() > 0) {
    if (command.startsWith("if") || command.startsWith("while")) {
      int closeBrace = command.indexOf('}'); 
      if (closeBrace != -1) {
        String block = command.substring(0, closeBrace + 1);
        executeSingleCommand(block); 
        command = command.substring(closeBrace + 1); 
      } else {
        executeSingleCommand(command);
        break;
      }
    } 
    else {
      int semicolonIndex = command.indexOf(';');
      if (semicolonIndex != -1) {
        String singleCmd = command.substring(0, semicolonIndex);
        executeSingleCommand(singleCmd); 
        command = command.substring(semicolonIndex + 1); 
      } else {
        executeSingleCommand(command);
        break;
      }
    }
    command.trim(); 
  }
}

void executeSingleCommand(String command) {
  command.trim();
  
  if (command.startsWith("if")) { 
    int conditionStart = command.indexOf('(') + 1; int conditionEnd = command.indexOf(')');
    String condition = command.substring(conditionStart, conditionEnd); condition.trim();
    int actionStart = command.indexOf('{') + 1; int actionEnd = command.lastIndexOf('}');
    String action = command.substring(actionStart, actionEnd); action.trim();
    if (evaluateCondition(condition)) { executeCommand(action); }
  }
  else if (command.startsWith("while")) { 
    int conditionStart = command.indexOf('(') + 1; 
    int conditionEnd = command.indexOf(')', conditionStart); 
    if(command.substring(conditionStart, conditionEnd).indexOf("digitalRead") != -1) {
        conditionEnd = command.indexOf(')', conditionEnd + 1);
    }
    String condition = command.substring(conditionStart, conditionEnd); condition.trim();
    int actionStart = command.indexOf('{') + 1; int actionEnd = command.lastIndexOf('}');
    String action = command.substring(actionStart, actionEnd); action.trim();
    
    while (evaluateCondition(condition)) { 
      executeCommand(action); 
      checkPinChanges();  // ← precise monitoring of pin changes
      printPinStates();   // ← the periodic print every 20ms
      
      // Check the serial for SET_T_ZERO during the while (avoid a timeout on the Bridge)
      while (Serial.available()) {
        char c = Serial.read();
        if (c == '\n') {
          incomingCommand.trim();
          if (incomingCommand == "SET_T_ZERO") {
            setTriggerFromBridge();
            Serial.println("DONE_SET_T_ZERO");
          }
          incomingCommand = "";
          break;
        } else {
          incomingCommand += c;
        }
      }
      
      delay(1); 
    }
  }
  else if (command.startsWith("digitalWrite")) { 
    int pinStart = command.indexOf('(') + 1; int pinEnd = command.indexOf(',');
    String pinString = command.substring(pinStart, pinEnd); pinString.trim();
    int pin = getPinFromName(pinString); 
    String stateStr = command.substring(pinEnd + 1, command.indexOf(')')); stateStr.trim();
    int state = (stateStr.equals("HIGH")) ? HIGH : LOW; 
    digitalWrite(pin, state);
    checkPinChanges();  // ← detect the change immediately
    printPinStates();   // ← the periodic print every 20ms
  }
  else if (command.startsWith("delay")) { 
    int delayStart = command.indexOf('(') + 1; int delayEnd = command.indexOf(')');
    String delayString = command.substring(delayStart, delayEnd); delayString.trim();
    
    // Split the delay into small chunks to monitor the pins during it
    int totalDelay = delayString.toInt();
    int elapsed = 0;
    while (elapsed < totalDelay) {
      int chunk = (totalDelay - elapsed > 5) ? 5 : (totalDelay - elapsed);
      delay(chunk);
      elapsed += chunk;
      checkPinChanges();
      printPinStates();
    }
  }
  else if (command.indexOf('=') > 0 && command.indexOf("==") == -1 && command.indexOf("!=") == -1) {
    String varName = command.substring(0, command.indexOf('=')); varName.trim();
    String valStr = command.substring(command.indexOf('=') + 1); valStr.trim();
    int val = valStr.toInt();
    
    if (varName == "horizontalMoveDirection")  horizontalMoveDirection = val;
    else if (varName == "verticalMoveDirection")  verticalMoveDirection = val;
    else if (varName == "rotateMoveDirection")    rotateMoveDirection = val;
    else if (varName == "horizontalPulseCount")   horizontalPulseCount = val;
    else if (varName == "verticalPulseCount")     verticalPulseCount = val;
    else if (varName == "rotatePulseCount")       rotatePulseCount = val;
  }
}

bool evaluateCondition(String condition) {
  condition.trim();

  if (condition.indexOf("digitalRead") != -1) {
    bool notEqual = (condition.indexOf("!=") != -1);
    int opPos = notEqual ? condition.indexOf("!=") : condition.indexOf("==");
    if (opPos == -1) return false;
    
    String leftPart = condition.substring(0, opPos);
    String rightPart = condition.substring(opPos + 2);
    int readStart = leftPart.indexOf("digitalRead(") + 12;
    int readEnd = leftPart.indexOf(')', readStart);
    String pinStr = leftPart.substring(readStart, readEnd);
    int pin = getPinFromName(pinStr); 
    
    rightPart.trim();
    int expectedState = (rightPart.equals("HIGH")) ? HIGH : LOW;
    int actualState = digitalRead(pin);
    
    if (notEqual) return (actualState != expectedState);
    else return (actualState == expectedState);
  }
  
  else if (condition.indexOf('<') != -1) {
    String varName = condition.substring(0, condition.indexOf('<')); varName.trim();
    int val = condition.substring(condition.indexOf('<') + 1).toInt();
    if (varName == "horizontalPulseCount") return (horizontalPulseCount < val);
    if (varName == "verticalPulseCount")   return (verticalPulseCount < val);
    if (varName == "rotatePulseCount")     return (rotatePulseCount < val);
  }
  
  else if (condition.indexOf('>') != -1) {
    String varName = condition.substring(0, condition.indexOf('>')); varName.trim();
    int val = condition.substring(condition.indexOf('>') + 1).toInt();
    if (varName == "horizontalPulseCount") return (horizontalPulseCount > val);
    if (varName == "verticalPulseCount")   return (verticalPulseCount > val);
    if (varName == "rotatePulseCount")     return (rotatePulseCount > val);
  }
  return false; 
}

// ==========================================
// 6. Main loop (Loop)
// ==========================================
// We use a fixed buffer to accumulate the incoming command char-by-char without blocking
// (incomingCommand defined in section 4.b)

void loop() { 
  // Monitor the pins the instant they actually change (runs on every loop iteration)
  checkPinChanges();
  
  // The periodic print every 20ms for the bridge and sender
  printPinStates();
  
  // Non-blocking serial read: read all available chars at once without waiting
  // This way, even if the command is long, we return to the loop quickly to run checkPinChanges
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      // Command complete
      String commandData = incomingCommand;
      incomingCommand = "";  // Reset the buffer for the next command
      commandData.trim();
      if (commandData.length() > 0) {
        // ============ Special command: SET_T_ZERO from the Bridge ============
        // Comes from the Bridge the moment MOTOR_HORZ_TO_RACK=HIGH is sent to HBW
        // -> sets t_zero for the station at the same moment counting starts on the other layers
        if (commandData == "SET_T_ZERO") {
          setTriggerFromBridge();
          Serial.println("DONE_SET_T_ZERO");
        } else {
          executeCommand(commandData);
          Serial.println("DONE"); // Acknowledgment for the second laptop
        }
      }
      break;  // Exit the while loop and return to loop so checkPinChanges runs
    } else {
      incomingCommand += c;
    }
  }
}
