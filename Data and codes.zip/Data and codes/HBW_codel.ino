#include <Arduino.h>

// ==========================================
// 0. Name of this station (appears in the Station column in the files)
// When we set up an ESP for a new station, we change only this line
// ==========================================
#define STATION_NAME "HBW"

// ==========================================
// 1. Extracted port and interrupt definitions
// ==========================================
#define REF_SWITCH_HORIZONTAL    36
#define LIGHT_BARRIER_INSIDE     39
#define LIGHT_BARRIER_OUTSIDE    34
#define REF_SWITCH_VERTICAL      35

#define ENCODER_HORZ_IMP1        32
#define ENCODER_HORZ_IMP2        33
#define ENCODER_VERT_IMP1        25
#define ENCODER_VERT_IMP2        26

#define REF_SWITCH_CANTILEVER_FRONT 27
#define REF_SWITCH_CANTILEVER_BACK  14

#define MOTOR_CONVEYOR_FWD     23
#define MOTOR_CONVEYOR_BWD     22
#define MOTOR_HORZ_TO_RACK     21
#define MOTOR_HORZ_TO_CONVEYOR 19
#define MOTOR_VERT_DOWN        18
#define MOTOR_VERT_UP          4
#define MOTOR_CANTILEVER_FWD   17
#define MOTOR_CANTILEVER_BWD   16

volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;


const int8_t encoder_table[16] = {
  0, -1,  1, 0,
  1,  0,  0, -1,
 -1,  0,  0,  1,
  0,  1, -1, 0
};

// ==========================================
// 1.b Periodic Logger variables (every 20ms)
// ==========================================
unsigned long lastLogTime = 0;
const unsigned long LOG_INTERVAL_MS = 20;

// ==========================================
// 1.c Event Logger variables (for precise measurement on the ESP32)
// ==========================================
const int NUM_TRACKED_PINS = 14;

// Pin names (same order as the periodic logger)
const char* PIN_NAMES[NUM_TRACKED_PINS] = {
  "REF_SWITCH_HORIZONTAL",
  "LIGHT_BARRIER_INSIDE",
  "LIGHT_BARRIER_OUTSIDE",
  "REF_SWITCH_VERTICAL",
  "REF_SWITCH_CANTILEVER_FRONT",
  "REF_SWITCH_CANTILEVER_BACK",
  "MOTOR_CONVEYOR_FWD",
  "MOTOR_CONVEYOR_BWD",
  "MOTOR_HORZ_TO_RACK",
  "MOTOR_HORZ_TO_CONVEYOR",
  "MOTOR_VERT_DOWN",
  "MOTOR_VERT_UP",
  "MOTOR_CANTILEVER_FWD",
  "MOTOR_CANTILEVER_BWD"
};

const int PIN_NUMBERS[NUM_TRACKED_PINS] = {
  REF_SWITCH_HORIZONTAL,
  LIGHT_BARRIER_INSIDE,
  LIGHT_BARRIER_OUTSIDE,
  REF_SWITCH_VERTICAL,
  REF_SWITCH_CANTILEVER_FRONT,
  REF_SWITCH_CANTILEVER_BACK,
  MOTOR_CONVEYOR_FWD,
  MOTOR_CONVEYOR_BWD,
  MOTOR_HORZ_TO_RACK,
  MOTOR_HORZ_TO_CONVEYOR,
  MOTOR_VERT_DOWN,
  MOTOR_VERT_UP,
  MOTOR_CANTILEVER_FWD,
  MOTOR_CANTILEVER_BWD
};

// Last known state for each pin
int lastPinStates[NUM_TRACKED_PINS];

// Last change time for each pin (in milliseconds)
unsigned long lastChangeTime[NUM_TRACKED_PINS];

// Debouncing variables: to ignore fast electrical fluctuations
int candidateState[NUM_TRACKED_PINS];        // The new candidate state
unsigned long candidateSince[NUM_TRACKED_PINS]; // When the candidate state started
const unsigned long DEBOUNCE_MS = 5;          // The state must stay stable for 5ms before being considered a change

// The trigger flag and t=0
bool esp_trigger_seen = false;
unsigned long esp_t_zero = 0;

const unsigned long EVT_MIN_DURATION_MS = 20;  // Ignore changes shorter than 20ms

// ==========================================
// 1.c.1 Rounding function to the nearest 10ms (same as q10 in Python)
// ==========================================
unsigned long q10(unsigned long x) {
  return ((x + 5) / 10) * 10;
}

// ==========================================
// 1.d Function to print periodic Pin states (every 20ms) for the bridge/sender
// ==========================================
void printPinStates() {
  unsigned long now = millis();
  if (now - lastLogTime < LOG_INTERVAL_MS) return;
  lastLogTime = now;
  
  // New format: Station,timestamp,p1,p2,... (to support multiple stations)
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.print(now);
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_HORIZONTAL));
  Serial.print(","); Serial.print(digitalRead(LIGHT_BARRIER_INSIDE));
  Serial.print(","); Serial.print(digitalRead(LIGHT_BARRIER_OUTSIDE));
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_VERTICAL));
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_CANTILEVER_FRONT));
  Serial.print(","); Serial.print(digitalRead(REF_SWITCH_CANTILEVER_BACK));
  Serial.print(","); Serial.print(digitalRead(MOTOR_CONVEYOR_FWD));
  Serial.print(","); Serial.print(digitalRead(MOTOR_CONVEYOR_BWD));
  Serial.print(","); Serial.print(digitalRead(MOTOR_HORZ_TO_RACK));
  Serial.print(","); Serial.print(digitalRead(MOTOR_HORZ_TO_CONVEYOR));
  Serial.print(","); Serial.print(digitalRead(MOTOR_VERT_DOWN));
  Serial.print(","); Serial.print(digitalRead(MOTOR_VERT_UP));
  Serial.print(","); Serial.print(digitalRead(MOTOR_CANTILEVER_FWD));
  Serial.print(","); Serial.println(digitalRead(MOTOR_CANTILEVER_BWD));
}

// ==========================================
// 1.e Function to check Pin changes and print EVT for precise measurement
// ==========================================
void checkPinChanges() {
  unsigned long now = millis();
  
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int cur = digitalRead(PIN_NUMBERS[i]);
    
    // If the current state == the last confirmed state -> no change, cancel any old candidate
    if (cur == lastPinStates[i]) {
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;
    }
    
    // The current state differs from lastPinStates[i]
    // -> we must confirm it lasted DEBOUNCE_MS before considering it a real change
    
    if (cur != candidateState[i]) {
      // The candidate state changed for the first time -> start counting from now
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;  // Not confirmed yet
    }
    
    // The candidate state is stable, confirm it has settled long enough
    if (now - candidateSince[i] < DEBOUNCE_MS) {
      continue;  // Not settled long enough yet
    }
    
    // ✅ Confirmed: a real change
    // The real change time = candidateSince[i] (the moment the new state began)
    unsigned long change_time = candidateSince[i];
    
    // Trigger check: the first time MOTOR_HORZ_TO_RACK = HIGH occurs
    if (!esp_trigger_seen && PIN_NUMBERS[i] == MOTOR_HORZ_TO_RACK && cur == HIGH) {
      esp_t_zero = change_time;
      esp_trigger_seen = true;
      
      // ⚠️ Important: set every lastChangeTime for all pins to the trigger time
      for (int j = 0; j < NUM_TRACKED_PINS; j++) {
        lastChangeTime[j] = esp_t_zero;
        lastPinStates[j] = digitalRead(PIN_NUMBERS[j]);
        candidateState[j] = lastPinStates[j];
        candidateSince[j] = esp_t_zero;
      }
      
      // Print TRIGGER as a start marker (without duration)
      // Format: EVT,Station,RelativeTime,Pin,NewState,Duration
      Serial.print("EVT,");
      Serial.print(STATION_NAME);
      Serial.print(",0,");
      Serial.print(PIN_NAMES[i]);
      Serial.println(",1,0");
      continue;
    }
    
    // Before the trigger: only update the state without printing
    if (!esp_trigger_seen) {
      lastPinStates[i] = cur;
      lastChangeTime[i] = change_time;
      continue;
    }
    
    // After the trigger: calculate the duration and print
    unsigned long duration = change_time - lastChangeTime[i];
    
    if (duration > EVT_MIN_DURATION_MS) {
      unsigned long rel_time = change_time - esp_t_zero;
      // Format: EVT,Station,RelativeTime,Pin,NewState,Duration
      // Rounded to the nearest 10ms (same as Python q10)
      Serial.print("EVT,");
      Serial.print(STATION_NAME);
      Serial.print(",");
      Serial.print(q10(rel_time));
      Serial.print(",");
      Serial.print(PIN_NAMES[i]);
      Serial.print(",");
      Serial.print(cur);
      Serial.print(",");
      Serial.println(q10(duration));
    }
    
    lastPinStates[i] = cur;
    lastChangeTime[i] = change_time;
  }
}

void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_VERT_IMP1) << 1) | digitalRead(ENCODER_VERT_IMP2);
  verticalPulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  if (horizontalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_HORZ_IMP1) << 1) | digitalRead(ENCODER_HORZ_IMP2);
  if (cur != lastState) {
    horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
    lastState = cur;
  }
}

// ==========================================
// 2. Function to translate names into port numbers
// ==========================================
int getPinFromName(String pinName) {
  pinName.trim();
  if (pinName == "REF_SWITCH_HORIZONTAL") return 36;
  if (pinName == "LIGHT_BARRIER_INSIDE") return 39;
  if (pinName == "LIGHT_BARRIER_OUTSIDE") return 34;
  if (pinName == "REF_SWITCH_VERTICAL") return 35;
  if (pinName == "REF_SWITCH_CANTILEVER_FRONT") return 27;
  if (pinName == "REF_SWITCH_CANTILEVER_BACK") return 14;
  if (pinName == "MOTOR_CONVEYOR_FWD") return 23;
  if (pinName == "MOTOR_CONVEYOR_BWD") return 22;
  if (pinName == "MOTOR_HORZ_TO_RACK") return 21;
  if (pinName == "MOTOR_HORZ_TO_CONVEYOR") return 19;
  if (pinName == "MOTOR_VERT_DOWN") return 18;
  if (pinName == "MOTOR_VERT_UP") return 4;
  if (pinName == "MOTOR_CANTILEVER_FWD") return 17;
  if (pinName == "MOTOR_CANTILEVER_BWD") return 16;
  
  return pinName.toInt(); 
}

// ==========================================
// 3. Setup
// ==========================================
void setupPins() {
  pinMode(REF_SWITCH_HORIZONTAL, INPUT); pinMode(LIGHT_BARRIER_INSIDE, INPUT);
  pinMode(LIGHT_BARRIER_OUTSIDE, INPUT); pinMode(REF_SWITCH_VERTICAL, INPUT);
  pinMode(ENCODER_HORZ_IMP1, INPUT); pinMode(ENCODER_HORZ_IMP2, INPUT);
  pinMode(ENCODER_VERT_IMP1, INPUT); pinMode(ENCODER_VERT_IMP2, INPUT);
  pinMode(REF_SWITCH_CANTILEVER_FRONT, INPUT); pinMode(REF_SWITCH_CANTILEVER_BACK, INPUT);

  pinMode(MOTOR_CONVEYOR_FWD, OUTPUT); pinMode(MOTOR_CONVEYOR_BWD, OUTPUT);
  pinMode(MOTOR_HORZ_TO_RACK, OUTPUT); pinMode(MOTOR_HORZ_TO_CONVEYOR, OUTPUT);
  pinMode(MOTOR_VERT_DOWN, OUTPUT); pinMode(MOTOR_VERT_UP, OUTPUT);
  pinMode(MOTOR_CANTILEVER_FWD, OUTPUT); pinMode(MOTOR_CANTILEVER_BWD, OUTPUT);

  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP1), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP2), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP2), handleHorizontalEncoder, CHANGE);
}

void setup() {
  Serial.setRxBufferSize(1024);
  Serial.begin(115200);
  setupPins();
  
  // Initialize the last known state for each pin + debouncing variables
  unsigned long now_init = millis();
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int initial_state = digitalRead(PIN_NUMBERS[i]);
    lastPinStates[i]  = initial_state;
    lastChangeTime[i] = now_init;
    candidateState[i] = initial_state;   // ⚠️ Important: initialize with the same known state
    candidateSince[i] = now_init;
  }
  
  // Print the Header once at startup
  // New format: Station,timestamp(ms),pin1,pin2,... (to support multiple stations)
  delay(500);
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.println(
    "timestamp(ms),"
    "REF_SWITCH_HORIZONTAL,LIGHT_BARRIER_INSIDE,LIGHT_BARRIER_OUTSIDE,REF_SWITCH_VERTICAL,"
    "REF_SWITCH_CANTILEVER_FRONT,REF_SWITCH_CANTILEVER_BACK,"
    "MOTOR_CONVEYOR_FWD,MOTOR_CONVEYOR_BWD,"
    "MOTOR_HORZ_TO_RACK,MOTOR_HORZ_TO_CONVEYOR,"
    "MOTOR_VERT_DOWN,MOTOR_VERT_UP,"
    "MOTOR_CANTILEVER_FWD,MOTOR_CANTILEVER_BWD"
  );
}

// ==========================================
// 4. Forward declarations of functions
// ==========================================
void executeCommand(String command);
void executeSingleCommand(String command);
bool evaluateCondition(String condition);

// ==========================================
// 5. Smart execution functions
// ==========================================
void executeCommand(String command) {
  command.trim();
  
  while (command.length() > 0) {
    if (command.startsWith("if") || command.startsWith("while")) {
      int closeBrace = command.indexOf('}'); 
      if (closeBrace != -1) {
        String block = command.substring(0, closeBrace + 1);
        executeSingleCommand(block); 
        command = command.substring(closeBrace + 1); 
      } else {
        executeSingleCommand(command);
        break;
      }
    } 
    else {
      int semicolonIndex = command.indexOf(';');
      if (semicolonIndex != -1) {
        String singleCmd = command.substring(0, semicolonIndex);
        executeSingleCommand(singleCmd); 
        command = command.substring(semicolonIndex + 1); 
      } else {
        executeSingleCommand(command);
        break;
      }
    }
    command.trim(); 
  }
}

void executeSingleCommand(String command) {
  command.trim();
  
  if (command.startsWith("if")) { 
    int conditionStart = command.indexOf('(') + 1; int conditionEnd = command.indexOf(')');
    String condition = command.substring(conditionStart, conditionEnd); condition.trim();
    int actionStart = command.indexOf('{') + 1; int actionEnd = command.lastIndexOf('}');
    String action = command.substring(actionStart, actionEnd); action.trim();
    if (evaluateCondition(condition)) { executeCommand(action); }
  }
  else if (command.startsWith("while")) { 
    int conditionStart = command.indexOf('(') + 1; 
    int conditionEnd = command.indexOf(')', conditionStart); 
    if(command.substring(conditionStart, conditionEnd).indexOf("digitalRead") != -1) {
        conditionEnd = command.indexOf(')', conditionEnd + 1);
    }
    String condition = command.substring(conditionStart, conditionEnd); condition.trim();
    int actionStart = command.indexOf('{') + 1; int actionEnd = command.lastIndexOf('}');
    String action = command.substring(actionStart, actionEnd); action.trim();
    
    while (evaluateCondition(condition)) { 
      executeCommand(action); 
      checkPinChanges();  // ← precise monitoring of pin changes
      printPinStates();   // ← the periodic print every 20ms
      delay(1); 
    }
  }
  else if (command.startsWith("digitalWrite")) { 
    int pinStart = command.indexOf('(') + 1; int pinEnd = command.indexOf(',');
    String pinString = command.substring(pinStart, pinEnd); pinString.trim();
    int pin = getPinFromName(pinString); 
    String stateStr = command.substring(pinEnd + 1, command.indexOf(')')); stateStr.trim();
    int state = (stateStr.equals("HIGH")) ? HIGH : LOW; 
    digitalWrite(pin, state);
    checkPinChanges();  // ← detect the change immediately
    printPinStates();   // ← the periodic print every 20ms
  }
  else if (command.startsWith("delay")) { 
    int delayStart = command.indexOf('(') + 1; int delayEnd = command.indexOf(')');
    String delayString = command.substring(delayStart, delayEnd); delayString.trim();
    
    // Split the delay into small chunks to monitor the pins during it
    int totalDelay = delayString.toInt();
    int elapsed = 0;
    while (elapsed < totalDelay) {
      int chunk = (totalDelay - elapsed > 5) ? 5 : (totalDelay - elapsed);
      delay(chunk);
      elapsed += chunk;
      checkPinChanges();
      printPinStates();
    }
  }
  else if (command.indexOf('=') > 0 && command.indexOf("==") == -1 && command.indexOf("!=") == -1) {
    String varName = command.substring(0, command.indexOf('=')); varName.trim();
    String valStr = command.substring(command.indexOf('=') + 1); valStr.trim();
    int val = valStr.toInt();
    
    if (varName == "horizontalMoveDirection") horizontalMoveDirection = val;
    else if (varName == "verticalMoveDirection") verticalMoveDirection = val;
    else if (varName == "horizontalPulseCount") horizontalPulseCount = val;
    else if (varName == "verticalPulseCount") verticalPulseCount = val;
  }
}

bool evaluateCondition(String condition) {
  condition.trim();

  if (condition.indexOf("digitalRead") != -1) {
    bool notEqual = (condition.indexOf("!=") != -1);
    int opPos = notEqual ? condition.indexOf("!=") : condition.indexOf("==");
    if (opPos == -1) return false;
    
    String leftPart = condition.substring(0, opPos);
    String rightPart = condition.substring(opPos + 2);
    int readStart = leftPart.indexOf("digitalRead(") + 12;
    int readEnd = leftPart.indexOf(')', readStart);
    String pinStr = leftPart.substring(readStart, readEnd);
    int pin = getPinFromName(pinStr); 
    
    rightPart.trim();
    int expectedState = (rightPart.equals("HIGH")) ? HIGH : LOW;
    int actualState = digitalRead(pin);
    
    if (notEqual) return (actualState != expectedState);
    else return (actualState == expectedState);
  }
  
  else if (condition.indexOf('<') != -1) {
    String varName = condition.substring(0, condition.indexOf('<')); varName.trim();
    int val = condition.substring(condition.indexOf('<') + 1).toInt();
    if (varName == "horizontalPulseCount") return (horizontalPulseCount < val);
    if (varName == "verticalPulseCount") return (verticalPulseCount < val);
  }
  
  else if (condition.indexOf('>') != -1) {
    String varName = condition.substring(0, condition.indexOf('>')); varName.trim();
    int val = condition.substring(condition.indexOf('>') + 1).toInt();
    if (varName == "horizontalPulseCount") return (horizontalPulseCount > val);
    if (varName == "verticalPulseCount") return (verticalPulseCount > val);
  }
  return false; 
}

// ==========================================
// 6. Main loop (Loop)
// ==========================================
// We use a fixed buffer to accumulate the incoming command char-by-char without blocking
String incomingCommand = "";

void loop() { 
  // Monitor the pins the instant they actually change (runs on every loop iteration)
  checkPinChanges();
  
  // The periodic print every 20ms for the bridge and sender
  printPinStates();
  
  // Non-blocking serial read: read all available chars at once without waiting
  // This way, even if the command is long, we return to the loop quickly to run checkPinChanges
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      // Command complete
      String commandData = incomingCommand;
      incomingCommand = "";  // Reset the buffer for the next command
      commandData.trim();
      if (commandData.length() > 0) {
        executeCommand(commandData);
        Serial.println("DONE"); // Acknowledgment for the second laptop
      }
      break;  // Exit the while loop and return to loop so checkPinChanges runs
    } else {
      incomingCommand += c;
    }
  }
}
