import argparse
import glob
import os
import numpy as np
import pandas as pd
from scipy import stats

EXCLUDED_PINS = {"SYSTEM_TRIGGER", "COLOR"}
MATCH_WINDOW_MS = 200.0
TRIM_FRACTION = 0.05
N_RUNS = 11


def resolve(data_dir, filename):
    """Locate a per-run CSV either directly in data_dir or in a per-run
    subfolder (e.g. Exp1/, Exp2/, ...), so the archive can be used as shipped."""
    direct = os.path.join(data_dir, filename)
    if os.path.exists(direct):
        return direct
    hits = sorted(glob.glob(os.path.join(data_dir, "*", filename)))
    if hits:
        return hits[0]
    raise FileNotFoundError(
        f"{filename} not found in {data_dir} or any of its subdirectories")


# ----------------------------------------------------------------------------- I/O
def load_pin_log(path):
    """Load a pin-state log, normalise columns, drop excluded pins, coerce types."""
    d = pd.read_csv(path)
    d.columns = [c.strip() for c in d.columns]
    d["Station"] = d["Station"].astype(str).str.strip()
    d["Pin"] = d["Pin"].astype(str).str.strip()
    d = d[~d["Pin"].isin(EXCLUDED_PINS)].reset_index(drop=True)
    d["RelativeTime(ms)"] = d["RelativeTime(ms)"].astype(float)
    # NewState may carry a logging artefact (e.g. "0HBW"); keep leading integer.
    d["NewState"] = (d["NewState"].astype(str)
                                  .str.extract(r"(-?\d+)")
                                  .astype(int))
    d["Duration(ms)"] = d["Duration(ms)"].astype(float)
    return d


# ------------------------------------------------------------------- offset / match
def estimate_run_offset(gt_groups, ds_groups):
    """
    Per-run constant timeline offset (downstream - ground truth), in ms.
    Estimated as the median of sequence-order-paired onset differences across
    every (Station, Pin, NewState) channel. Robust because missed/spurious
    events are rare (<2.2%), so same-index pairing is overwhelmingly correct.
    """
    diffs = []
    for key, g in gt_groups:
        if key not in ds_groups.groups:
            continue
        gt_t = g["RelativeTime(ms)"].values
        ds_t = ds_groups.get_group(key)["RelativeTime(ms)"].values
        n = min(len(gt_t), len(ds_t))
        diffs.extend(ds_t[:n] - gt_t[:n])
    return float(np.median(diffs)) if diffs else 0.0


def match_channel(gt_t, gt_dur, ds_t, ds_dur, window):
    """
    Greedy nearest-onset matching within one (Station,Pin,NewState) channel.
    `ds_t` must already have the per-run offset removed.
    Returns: list of (onset_residual, duration_diff), n_missed, n_spurious.
    """
    used = np.zeros(len(ds_t), dtype=bool)
    matches = []
    missed = 0
    for i in range(len(gt_t)):
        best_j, best_dt = -1, window + 1.0
        for j in range(len(ds_t)):
            if used[j]:
                continue
            dt = abs(ds_t[j] - gt_t[i])
            if dt < best_dt:
                best_dt, best_j = dt, j
        if best_j >= 0:
            used[best_j] = True
            matches.append((ds_t[best_j] - gt_t[i],          # onset residual
                            ds_dur[best_j] - gt_dur[i]))      # duration diff
        else:
            missed += 1
    spurious = int((~used).sum())
    return matches, missed, spurious


def analyse_vantage(data_dir, tag):
    """Full fidelity analysis of one downstream vantage ('bridge' or 'sender')."""
    dur_diffs, onset_resid = [], []
    tot_gt = tot_missed = tot_spur = tot_ds = 0
    per_run_offset = []

    for i in range(1, N_RUNS + 1):
        gt = load_pin_log(resolve(data_dir, f"esp32_pin_log_{i}.csv"))
        ds = load_pin_log(resolve(data_dir, f"{tag}_pin_log_{i}.csv"))
        gt_g = gt.groupby(["Station", "Pin", "NewState"])
        ds_g = ds.groupby(["Station", "Pin", "NewState"])

        offset = estimate_run_offset(gt_g, ds_g)
        per_run_offset.append(offset)
        tot_ds += len(ds)

        run_raw_onset_diffs = []
        for key, g in gt_g:
            gt_t = g["RelativeTime(ms)"].values
            gt_d = g["Duration(ms)"].values
            if key in ds_g.groups:
                d = ds_g.get_group(key)
                ds_t = d["RelativeTime(ms)"].values - offset   # offset removed
                ds_d = d["Duration(ms)"].values
            else:
                ds_t = np.array([]); ds_d = np.array([])
            m, miss, spur = match_channel(gt_t, gt_d, ds_t, ds_d, MATCH_WINDOW_MS)
            tot_gt += len(gt_t); tot_missed += miss; tot_spur += spur
            for onres, ddiff in m:
                onset_resid.append(onres)
                dur_diffs.append(ddiff)
                run_raw_onset_diffs.append(onres + offset)  # raw (offset back in)
        # store per-run raw-onset median for the offset statistic
        per_run_offset[-1] = float(np.median(run_raw_onset_diffs)) if run_raw_onset_diffs else offset

    captured = tot_gt - tot_missed
    adur = np.abs(np.array(dur_diffs))
    ares = np.abs(np.array(onset_resid))
    off = np.array(per_run_offset)

    return {
        "tag": tag,
        "gt": tot_gt,
        "captured_pct": 100 * captured / tot_gt,
        "missed_n": tot_missed,
        "missed_pct": 100 * tot_missed / tot_gt,
        "spurious_pct": 100 * tot_spur / tot_ds,
        "dur_median": float(np.median(adur)),
        "dur_trimmean": float(stats.trim_mean(adur, TRIM_FRACTION)),
        "within10": 100 * float((adur <= 10).mean()),
        "within20": 100 * float((adur <= 20).mean()),
        "within50": 100 * float((adur <= 50).mean()),
        "dur_p95": float(np.percentile(adur, 95)),
        "dur_over100": 100 * float((adur > 100).mean()),
        "onset_resid_median": float(np.median(ares)),
        "onset_resid_p95": float(np.percentile(ares, 95)),
        "offset_mean": float(off.mean()),
        "offset_sd": float(off.std(ddof=1)),
        "offset_min": float(off.min()),
        "offset_max": float(off.max()),
    }


# ----------------------------------------------------------------------- latency
def analyse_latency(data_dir):
    tot, br, net, per_run_net = [], [], [], []
    station_net = {}
    for i in range(1, N_RUNS + 1):
        d = pd.read_csv(resolve(data_dir, f"timing_log_{i}.csv"))
        d.columns = [c.strip() for c in d.columns]
        t = d["Total_ms"].astype(float).values
        b = d["Bridge_ms(serial+exec)"].astype(float).values
        n = d["Network_ms(RTT)"].astype(float).values
        tot += list(t); br += list(b); net += list(n); per_run_net.append(n.mean())
        for st, v in zip(d["Station"].astype(str).str.strip(), n):
            station_net.setdefault(st, []).append(v)
    net = np.array(net); tot = np.array(tot); br = np.array(br)
    pr = np.array(per_run_net)
    return {
        "n_cmd": len(net),
        "net_mean": net.mean(), "net_sd": net.std(ddof=1),
        "net_median": np.median(net),
        "net_p95": np.percentile(net, 95), "net_p99": np.percentile(net, 99),
        "net_min": net.min(), "net_max": net.max(),
        "mean_total": tot.mean(), "mean_onsite": br.mean(),
        "perrun_min": pr.min(), "perrun_max": pr.max(), "perrun_sd": pr.std(ddof=1),
        "station": {st: (np.mean(v), np.std(v, ddof=1)) for st, v in station_net.items()},
    }


def analyse_ping(data_dir):
    rtt, ipdv = [], []
    for i in range(1, N_RUNS + 1):
        d = pd.read_csv(resolve(data_dir, f"network_ping_log_{i}.csv"))
        d.columns = [c.strip() for c in d.columns]
        r = d["RTT_ms"].astype(float).values
        rtt += list(r); ipdv += list(np.abs(np.diff(r)))
    rtt = np.array(rtt); ipdv = np.array(ipdv)
    return {
        "n": len(rtt), "mean": rtt.mean(), "sd": rtt.std(ddof=1),
        "median": np.median(rtt), "p95": np.percentile(rtt, 95),
        "p99": np.percentile(rtt, 99), "max": rtt.max(),
        "ipdv_mean": ipdv.mean(), "ipdv_median": np.median(ipdv),
        "ipdv_p95": np.percentile(ipdv, 95),
    }


def analyse_throughput(data_dir):
    proc, colors = [], {"WHITE": 0, "RED": 0, "BLUE": 0}
    for i in range(1, N_RUNS + 1):
        d = pd.read_csv(resolve(data_dir, f"esp32_pin_log_{i}.csv"))
        d.columns = [c.strip() for c in d.columns]
        proc.append(d["RelativeTime(ms)"].astype(float).max() / 1000.0)
        c = d[d["Pin"].astype(str).str.strip() == "COLOR"]["NewState"].astype(str).str.strip()
        for k in colors:
            colors[k] += int((c == k).sum())
    proc = np.array(proc)
    return {
        "mean": proc.mean(), "sd": proc.std(ddof=1),
        "min": proc.min(), "max": proc.max(),
        "cv": 100 * proc.std(ddof=1) / proc.mean(),
        "colors": colors,
    }



# ------------------------------------------------- Section 4.7 process-time bounds
def analyse_process_bounds(data_dir):
    """
    Reproduces the two network-cost bounds of Section 4.7.

    (a) Structure-free upper bound: the network RTT of all 58 command blocks
        per run. No dependency chain can exceed this.
    (b) Structure-aware estimate: the 28 command blocks that lie on the
        orchestrator's blocking chain after the time origin -- the nine
        high-bay-warehouse blocks and eighteen gripper blocks of the main
        loop, plus the final homing block. Two readings of "the nine
        high-bay-warehouse blocks" are possible (the retrievals or the
        returns); both are printed so the chain actually used in the paper
        can be stated unambiguously.
    """
    import re
    upper, chain_retr, chain_ret = [], [], []
    for i in range(1, N_RUNS + 1):
        d = pd.read_csv(resolve(data_dir, f"timing_log_{i}.csv"))
        d.columns = [c.strip() for c in d.columns]
        d["Task"] = d["Task"].astype(str).str.strip()
        n = d["Network_ms(RTT)"].astype(float)
        grab = d["Task"].str.contains("PICK|PUT")
        final = d["Task"].eq("Final Homing")
        upper.append(n.sum() / 1000.0)
        chain_retr.append(n[d["Task"].str.contains("Retrieve") | grab | final].sum() / 1000.0)
        chain_ret.append(n[d["Task"].str.contains("Return") | grab | final].sum() / 1000.0)
    out = {}
    for k, v in [("upper58", upper), ("chain28_retrieve", chain_retr),
                 ("chain28_return", chain_ret)]:
        v = np.array(v)
        out[k] = (v.mean(), v.std(ddof=1), v.min(), v.max())
    return out

# ---------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    args = ap.parse_args()
    dd = args.data_dir

    print("=" * 78)
    print("TEMPORAL-OBSERVABILITY-FIDELITY  --  canonical results")
    print(f"  data-dir = {dd}")
    print(f"  MATCH_WINDOW_MS = {MATCH_WINDOW_MS:.0f}   EXCLUDED_PINS = {sorted(EXCLUDED_PINS)}")
    print("=" * 78)

    L = analyse_latency(dd)
    print("\n[Section 4.1 / Table 2] Command-path network RTT")
    print(f"  n_commands            = {L['n_cmd']}")
    print(f"  mean +/- SD           = {L['net_mean']:.2f} +/- {L['net_sd']:.2f} ms")
    print(f"  median                = {L['net_median']:.2f} ms")
    print(f"  p95 / p99             = {L['net_p95']:.2f} / {L['net_p99']:.2f} ms")
    print(f"  min / max             = {L['net_min']:.2f} / {L['net_max']:.2f} ms")
    print(f"  mean total / on-site  = {L['mean_total']:.0f} / {L['mean_onsite']:.0f} ms")
    print(f"  per-run mean range/SD = {L['perrun_min']:.2f}-{L['perrun_max']:.2f} / {L['perrun_sd']:.2f} ms")
    for st in ["ColorSorter", "Oven", "HBW", "Grabber"]:
        if st in L["station"]:
            m, s = L["station"][st]
            print(f"    {st:12s} = {m:.2f} +/- {s:.2f} ms")

    P = analyse_ping(dd)
    print("\n[Section 4.2-4.3 / Table 2] Pure-network ping RTT")
    print(f"  n                     = {P['n']}")
    print(f"  mean +/- SD           = {P['mean']:.2f} +/- {P['sd']:.2f} ms")
    print(f"  median / p95 / p99    = {P['median']:.2f} / {P['p95']:.2f} / {P['p99']:.2f} ms")
    print(f"  max                   = {P['max']:.2f} ms")
    print(f"  cross-val gap (mean)  = {L['net_mean'] - P['mean']:.2f} ms")
    print(f"  jitter IPDV mean/med/p95 = {P['ipdv_mean']:.2f} / {P['ipdv_median']:.2f} / {P['ipdv_p95']:.2f} ms")

    for tag in ["bridge", "sender"]:
        F = analyse_vantage(dd, tag)
        print(f"\n[Section 4.4-4.6 / Table 3] Fidelity @ {tag.upper()}  (GT transitions = {F['gt']})")
        print(f"  captured  = {F['captured_pct']:.2f}%")
        print(f"  missed    = {F['missed_pct']:.2f}%  ({F['missed_n']})")
        print(f"  spurious  = {F['spurious_pct']:.2f}%")
        print(f"  dur median / trimmean5% = {F['dur_median']:.1f} / {F['dur_trimmean']:.2f} ms")
        print(f"  within +/-10/20/50      = {F['within10']:.1f}% / {F['within20']:.1f}% / {F['within50']:.1f}%")
        print(f"  dur p95 / >100ms        = {F['dur_p95']:.1f} ms / {F['dur_over100']:.2f}%")
        print(f"  onset residual med/p95  = {F['onset_resid_median']:.1f} / {F['onset_resid_p95']:.1f} ms")
        print(f"  timeline offset         = {F['offset_mean']:.1f} +/- {F['offset_sd']:.1f} ms "
              f"(range {F['offset_min']:.0f}-{F['offset_max']:.0f})")

    T = analyse_throughput(dd)
    print("\n[Section 4.7] Throughput & functional correctness")
    print(f"  process time = {T['mean']:.2f} +/- {T['sd']:.2f} s "
          f"(range {T['min']:.2f}-{T['max']:.2f}, CV {T['cv']:.2f}%)")
    print(f"  colour classifications = {T['colors']} "
          f"(total {sum(T['colors'].values())})")

    B = analyse_process_bounds(dd)
    print("\n[Section 4.7] Network cost of remote operation (process-time bounds)")
    for k, lbl in [("upper58", "upper bound, all 58 blocks"),
                   ("chain28_retrieve", "28-block chain (HBW retrievals)"),
                   ("chain28_return", "28-block chain (HBW returns)  ")]:
        m, sd, lo, hi = B[k]
        print(f"  {lbl} = {m:.2f} +/- {sd:.2f} s "
              f"(range {lo:.2f}-{hi:.2f}; {100*m/T['mean']:.2f}% of process time)")
    print("\n" + "=" * 78)


if __name__ == "__main__":
    main()
