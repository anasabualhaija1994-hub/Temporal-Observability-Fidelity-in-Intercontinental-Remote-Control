import socket
import time
import threading
import queue
import csv
import os
import sys
sys.stdout.reconfigure(line_buffering=True)

# ==========================================
# VPN settings
# ==========================================
VPN_SERVER_IP = '26.54.20.166'  # Change this to the IP address of the second laptop on the VPN network
PORT = 65432                    # Port for sending commands to the bridge
PORT_PIN_STREAM = 65433         # Port for receiving pin states from the bridge (new)
PORT_PING       = 65434         # Port for measuring network RTT (lightweight ping/pong)

# ==========================================
# Pin Logger settings
# ==========================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_CSV = os.path.join(SCRIPT_DIR, 'sender_pin_log.csv')
TIMING_CSV = os.path.join(SCRIPT_DIR, 'timing_log.csv')        # Breakdown of each command's timing (total/serial+execution/network)
PING_CSV   = os.path.join(SCRIPT_DIR, 'network_ping_log.csv')  # Continuous pure network RTT
QUANTIZE_10MS = True
MIN_DURATION_MS = 20  # Ignore any duration less than or equal to 20ms

# Station names (appear in the Station column)
# The trigger is fixed at HBW: the counter doesn't start until MOTOR_HORZ_TO_RACK=HIGH is sent to HBW
STATION_HBW          = "HBW"
STATION_GRABBER      = "Grabber"
STATION_OVEN         = "Oven"
STATION_COLORSORTER  = "ColorSorter"

# Trigger: the moment the MOTOR_HORZ_TO_RACK=HIGH command is sent to the HBW station (unified for the whole factory)
TRIGGER_PIN     = "MOTOR_HORZ_TO_RACK"
TRIGGER_STATION = STATION_HBW

# Shared variables for the Pin Logger
_pin_stop_event = threading.Event()
_pin_csv_queue = queue.SimpleQueue()
_timing_csv_queue = queue.SimpleQueue()
_pin_t_zero_perf = None
_pin_t_zero_lock = threading.Lock()

# Previous pin states — separate for each station
# {station_name: {"header": [...], "prev_states": {...}, "prev_change_perf": {...}}}
_pin_stations = {}
_pin_stations_lock = threading.Lock()

# Have we seen the trigger pin = HIGH for the first time?
_pin_trigger_seen = False
_pin_trigger_lock = threading.Lock()

# ==========================================
# Flag for manual stop (Ctrl+C)
# ==========================================
_user_interrupted = threading.Event()


def _maybe_set_trigger(commands_text: str, target_station: str):
    """Checks if the block contains digitalWrite(MOTOR_HORZ_TO_RACK, HIGH) and is sent to the HBW station.
       If yes and it is the first time -> sets t_zero at the moment of the call (before s.sendall)."""
    global _pin_t_zero_perf, _pin_trigger_seen
    
    with _pin_trigger_lock:
        if _pin_trigger_seen:
            return
        # The trigger is only valid if the command is sent to the HBW station
        if target_station != TRIGGER_STATION:
            return
        if f"digitalWrite({TRIGGER_PIN}, HIGH)" not in commands_text:
            return
        
        with _pin_t_zero_lock:
            _pin_t_zero_perf = time.perf_counter()
        _pin_trigger_seen = True
        print(f"[Trigger] ✓ Command {TRIGGER_PIN}=HIGH sent to {TRIGGER_STATION} — counting has started now.")
        
        # Initialize all stations: set _pin_t_zero_perf as the last change time for each pin
        # (same logic as Bridge and ESP32)
        with _pin_stations_lock:
            for st_name, st_info in _pin_stations.items():
                for p in st_info["header"]:
                    if st_info["prev_states"].get(p) is not None:
                        st_info["prev_change_perf"][p] = _pin_t_zero_perf


def _q10(x_ms: float) -> int:
    if not QUANTIZE_10MS:
        return int(round(x_ms))
    return int(round(x_ms / 10.0) * 10)


class PinCSVWriterThread(threading.Thread):
    """Writes CSV lines immediately with a flush after each line"""
    def __init__(self, path):
        super().__init__(daemon=True)
        self.path = path

    def run(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
        except Exception:
            pass
        try:
            f = open(self.path, 'w', newline='', buffering=1, encoding='utf-8')
            writer = csv.writer(f)
            writer.writerow(['Station', 'RelativeTime(ms)', 'Pin', 'NewState', 'Duration(ms)'])
            f.flush()
        except Exception as e:
            print(f"[PinCSV] Failed to open file: {e}")
            return

        while not _pin_stop_event.is_set():
            try:
                row = _pin_csv_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                writer.writerow(row)
                f.flush()
            except Exception as e:
                print(f"[PinCSV] Write error: {e}")

        # Flush what remains
        while True:
            try:
                row = _pin_csv_queue.get_nowait()
                writer.writerow(row)
            except queue.Empty:
                break
        try:
            f.flush()
            f.close()
        except Exception:
            pass


class PinStreamClientThread(threading.Thread):
    """Connects to the bridge, receives pin state lines, and processes them to calculate durations locally"""
    def __init__(self, server_ip, server_port):
        super().__init__(daemon=True)
        self.server_ip = server_ip
        self.server_port = server_port

    def run(self):
        global _pin_t_zero_perf
        
        while not _pin_stop_event.is_set():
            sock = None
            try:
                print(f"[PinStream] Attempting to connect to {self.server_ip}:{self.server_port} ...")
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect((self.server_ip, self.server_port))
                sock.settimeout(1.0)
                print(f"[PinStream] ✓ Connected to the bridge to receive pin states.")
                
                buf = b''
                while not _pin_stop_event.is_set():
                    try:
                        chunk = sock.recv(4096)
                    except socket.timeout:
                        continue
                    except Exception:
                        break
                    
                    if not chunk:
                        print("[PinStream] Connection dropped from the bridge side.")
                        break
                    
                    buf += chunk
                    while b'\n' in buf:
                        line_b, buf = buf.split(b'\n', 1)
                        line = line_b.decode('utf-8', errors='ignore').strip()
                        if line:
                            self._handle_line(line)
            except Exception as e:
                if not _pin_stop_event.is_set():
                    print(f"[PinStream] Connection error: {e}")
            finally:
                try:
                    if sock:
                        sock.close()
                except Exception:
                    pass
            
            # Retry after two seconds (if the network came back)
            if not _pin_stop_event.is_set():
                print("[PinStream] Retrying connection in 2 seconds...")
                time.sleep(2)

    def _handle_line(self, line: str):
        global _pin_t_zero_perf, _pin_trigger_seen
        
        # EVT line from the ESP (broadcast via the bridge): EVT,Station,RelTime,Pin,NewState,Duration
        # Write it directly to the sender file (same as ColorSorter)
        if line.startswith("EVT,"):
            ev = [p.strip() for p in line.split(',')]
            if len(ev) >= 6:
                try:
                    _pin_csv_queue.put([ev[1], int(ev[2]), ev[3], ev[4], int(ev[5])])
                except ValueError:
                    pass
            return
        
        # New format: every line starts with the station name
        #   header: Station,timestamp,p1,p2,...
        #   data:   Station,12345,0,1,0,...
        parts = [p.strip() for p in line.split(',')]
        if len(parts) < 2:
            return
        
        station_name = parts[0]
        second_field = parts[1]
        
        # Initialize an entry for the station if it doesn't exist
        with _pin_stations_lock:
            if station_name not in _pin_stations:
                _pin_stations[station_name] = {
                    "header": [],
                    "prev_states": {},
                    "prev_change_perf": {},
                }
        
        # 1) Header line? (the second field starts with "timestamp")
        if second_field.lower().startswith("timestamp"):
            header_pins = parts[2:]
            with _pin_stations_lock:
                _pin_stations[station_name]["header"] = header_pins
                for p in header_pins:
                    _pin_stations[station_name]["prev_states"].setdefault(p, None)
                    _pin_stations[station_name]["prev_change_perf"].setdefault(p, None)
            print(f"[PinStream] Received header for {station_name}: {len(header_pins)} pins")
            return
        
        # 2) Normal pin states line
        try:
            int(second_field)  # Make sure the timestamp is a number
        except ValueError:
            return
        
        with _pin_stations_lock:
            st_info = _pin_stations.get(station_name)
            if not st_info or not st_info["header"]:
                return
            header_local = list(st_info["header"])
        
        # Prepare pin states
        states = parts[2:]
        if len(states) < len(header_local):
            states += [''] * (len(header_local) - len(states))
        elif len(states) > len(header_local):
            states = states[:len(header_local)]
        
        # ============ Trigger check ============
        # The trigger is set from send_commands_to_robot at the moment the first block is sent
        # containing digitalWrite(MOTOR_HORZ_TO_RACK, HIGH) for HBW.
        with _pin_trigger_lock:
            local_trigger_seen = _pin_trigger_seen
        
        if not local_trigger_seen:
            # Before the trigger: only update the last known state (without CSV)
            now_perf = time.perf_counter()
            with _pin_stations_lock:
                for p, s in zip(header_local, states):
                    _pin_stations[station_name]["prev_states"][p] = s
                    _pin_stations[station_name]["prev_change_perf"][p] = now_perf
            return  # ⛔ Do not log or calculate durations
        
        # ============ After the trigger: calculate durations normally ============
        now_perf = time.perf_counter()
        rel_time_ms = (now_perf - _pin_t_zero_perf) * 1000.0
        rel_time_q = _q10(rel_time_ms)
        
        with _pin_stations_lock:
            for pin, cur_state in zip(header_local, states):
                prev_s = _pin_stations[station_name]["prev_states"].get(pin)
                prev_t = _pin_stations[station_name]["prev_change_perf"].get(pin)
                
                if prev_s is None:
                    _pin_stations[station_name]["prev_states"][pin] = cur_state
                    _pin_stations[station_name]["prev_change_perf"][pin] = now_perf
                    continue
                
                if prev_s != cur_state:
                    duration_ms = (now_perf - prev_t) * 1000.0 if prev_t else 0.0
                    
                    # 20ms filter: ignore completely
                    if duration_ms <= MIN_DURATION_MS:
                        continue
                    
                    duration_q = _q10(duration_ms)
                    _pin_csv_queue.put([station_name, rel_time_q, pin, cur_state, duration_q])
                    
                    _pin_stations[station_name]["prev_states"][pin] = cur_state
                    _pin_stations[station_name]["prev_change_perf"][pin] = now_perf


class TimingCSVWriterThread(threading.Thread):
    """Writes the timing breakdown for each command: total (sender clock) / serial+execution (bridge clock) / network (the difference)."""
    def __init__(self, path):
        super().__init__(daemon=True)
        self.path = path

    def run(self):
        try:
            f = open(self.path, 'w', newline='', buffering=1, encoding='utf-8')
            writer = csv.writer(f)
            writer.writerow(['Station', 'Task', 'Total_ms', 'Bridge_ms(serial+exec)', 'Network_ms(RTT)'])
            f.flush()
        except Exception as e:
            print(f"[Timing] Failed to open file: {e}")
            return
        while not _pin_stop_event.is_set():
            try:
                row = _timing_csv_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                writer.writerow(row); f.flush()
            except Exception as e:
                print(f"[Timing] Write error: {e}")
        while True:
            try:
                row = _timing_csv_queue.get_nowait(); writer.writerow(row)
            except queue.Empty:
                break
        try:
            f.flush(); f.close()
        except Exception:
            pass


class PingClientThread(threading.Thread):
    """Connects to the ping server on the bridge with a permanent connection, and continuously measures the pure network RTT.
       It does not go through the serial or execution path — giving a baseline for the VPN time alone."""
    def __init__(self, server_ip, server_port, interval=0.5):
        super().__init__(daemon=True)
        self.server_ip = server_ip
        self.server_port = server_port
        self.interval = interval

    def run(self):
        try:
            f = open(PING_CSV, 'w', newline='', buffering=1, encoding='utf-8')
            writer = csv.writer(f)
            writer.writerow(['Seq', 'RTT_ms', 'OneWayEst_ms'])
            f.flush()
        except Exception as e:
            print(f"[Ping] Failed to open ping file: {e}")
            return

        seq = 0
        while not _pin_stop_event.is_set():
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect((self.server_ip, self.server_port))
                try:
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                except Exception:
                    pass
                sock.settimeout(2.0)
                print("[Ping] \u2713 Connected to the ping server on the bridge.")
                buf = b''
                while not _pin_stop_event.is_set():
                    seq += 1
                    t0 = time.perf_counter()
                    try:
                        sock.sendall(f"PING {seq} {t0}\n".encode('utf-8'))
                    except Exception:
                        break
                    got = False
                    while not _pin_stop_event.is_set():
                        try:
                            chunk = sock.recv(4096)
                        except socket.timeout:
                            break
                        except Exception:
                            chunk = b''
                        if not chunk:
                            break
                        buf += chunk
                        if b'\n' in buf:
                            _line, buf = buf.split(b'\n', 1)
                            rtt_ms = (time.perf_counter() - t0) * 1000.0
                            try:
                                writer.writerow([seq, round(rtt_ms, 3), round(rtt_ms / 2.0, 3)])
                                f.flush()
                            except Exception:
                                pass
                            got = True
                            break
                    if not got:
                        break  # Reconnect
                    if _pin_stop_event.wait(self.interval):
                        break
            except Exception as e:
                if not _pin_stop_event.is_set():
                    print(f"[Ping] Connection error: {e}")
            finally:
                try:
                    if sock:
                        sock.close()
                except Exception:
                    pass
            if not _pin_stop_event.is_set():
                time.sleep(2)
        try:
            f.flush(); f.close()
        except Exception:
            pass


def start_pin_logger():
    """Starts threads: writing CSV for pin states, receiving the stream, timing breakdown, and RTT measurement."""
    csv_writer = PinCSVWriterThread(OUTPUT_CSV)
    stream_client = PinStreamClientThread(VPN_SERVER_IP, PORT_PIN_STREAM)
    timing_writer = TimingCSVWriterThread(TIMING_CSV)
    ping_client = PingClientThread(VPN_SERVER_IP, PORT_PING)
    csv_writer.start()
    stream_client.start()
    timing_writer.start()
    ping_client.start()
    print(f"[PinLogger] Started — pin CSV: {OUTPUT_CSV}")
    print(f"[Timing]    Timing breakdown file: {TIMING_CSV}")
    print(f"[Ping]      Network RTT file: {PING_CSV}")
    return csv_writer, stream_client, timing_writer, ping_client

# ==========================================
# Operational commands (C++ code converted into Python strings)
# ==========================================

INITIAL_HOMING = """
  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
"""

POS_1_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 2900) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); } 
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW); 
"""

# ==========================================
# Commands to return the box empty to location 1
# ==========================================
POS_1_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1; 
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1; 
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1; 
  while(horizontalPulseCount < 2900) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""
# ==========================================
# POS 4 (H=5250, V_Ret=500, V_Store=0)
# ==========================================
POS_4_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 5250) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 500) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_4_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 5250) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 7 (H=7570, V_Ret=500, V_Store=0)
# ==========================================
POS_7_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 7570) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 500) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_7_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 7570) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 2 (H=2900, V_Ret=1850, V_Store=1500)
# ==========================================
POS_2_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 2900) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1850) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 1500) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_2_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 2900) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1850) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 5 (H=5250, V_Ret=1850, V_Store=1500)
# ==========================================
POS_5_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 5250) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1850) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 1500) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW); delay(1000);
"""

POS_5_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 5250) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1850) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 8 (H=7570, V_Ret=1850, V_Store=1500)
# ==========================================
POS_8_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 7570) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1850) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 1500) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_8_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 7570) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1500) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 1850) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 3 (H=2900, V_Ret=3450, V_Store=3000)
# ==========================================
POS_3_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 2900) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3450) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 3000) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 2800) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  if (verticalPulseCount > 2800) {
    digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
    while(verticalPulseCount > 2800) { delay(1); }
    digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);
  }

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_3_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 2900) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3000) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3450) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 6 (H=5250, V_Ret=3450, V_Store=3000)
# ==========================================
POS_6_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 5250) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3450) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 3000) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  if (verticalPulseCount > 2800) {
    digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
    while(verticalPulseCount > 2800) { delay(1); }
    digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);
  }

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_6_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 5250) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3000) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3450) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# POS 9 (H=7570, V_Ret=3450, V_Store=3000)
# ==========================================
POS_9_RETRIEVE = """
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 7570) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3450) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 3000) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > 60) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);

  if (verticalPulseCount > 2800) {
    digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
    while(verticalPulseCount > 2800) { delay(1); }
    digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);
  }

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
"""

POS_9_RETURN = """
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while(digitalRead(LIGHT_BARRIER_INSIDE) != LOW) { delay(1); }
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > 2400) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  while(horizontalPulseCount < 7570) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3000) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  while(verticalPulseCount < 3450) { delay(1); }
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
"""

# ==========================================
# FINAL HOMING 
# ==========================================
FINAL_HOMING = """
  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  while(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) { delay(1); }
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);

  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_VERTICAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  while(digitalRead(REF_SWITCH_HORIZONTAL) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
"""

# ==========================================
# Grabber station commands
# ==========================================

# Initial Homing for the Grabber (executed in parallel with HBW Initial Homing)
GRABBER_INITIAL_HOMING = """
  digitalWrite(MOTOR_VERT_AXIS_UP, HIGH); verticalMoveDirection = 1;
  while(digitalRead(REF_SWITCH_VERTICAL_AXIS) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH); horizontalMoveDirection = 1;
  while(digitalRead(REF_SWITCH_HORIZONTAL_AXIS) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  while(digitalRead(REF_SWITCH_ROTATE) == LOW) { delay(1); }
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotatePulseCount = 0; rotateMoveDirection = 0; delay(10);
"""

# Pick cycle from the rack and Put in the oven — without rotation homing at the end
# (for cycles 1, 2, 4, 5, 7, 8)
# ==========================================
# The Grabber cycle is split into two phases:
#   1) PICK from HBW: picks up the piece from the rack and returns to the safe point (Home V + H)
#   2) PUT to OVEN:   rotates to the oven and places the piece + vertical/horizontal homing
# The two phases are separate because HBW starts POS_X_RETURN in parallel with PUT
# ==========================================

# Phase 1: PICK from HBW (HBW waits for this entire phase)
GRABBER_PICK_FROM_HBW = """
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, HIGH); rotateMoveDirection = -1;
  while(rotatePulseCount > -5380) { delay(1); }
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW); rotateMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > -680) { delay(1); }
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_AXIS_DOWN, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > -1000) { delay(1); }
  digitalWrite(MOTOR_VERT_AXIS_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(COMPRESSOR, HIGH);
  digitalWrite(VALVE_VACUUM, HIGH);
  delay(100);

  digitalWrite(MOTOR_VERT_AXIS_UP, HIGH); verticalMoveDirection = 1;
  while(digitalRead(REF_SWITCH_VERTICAL_AXIS) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH); horizontalMoveDirection = 1;
  while(digitalRead(REF_SWITCH_HORIZONTAL_AXIS) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
"""

# Phase 2: PUT to OVEN (runs in parallel with HBW POS_X_RETURN)
GRABBER_PUT_TO_OVEN = """
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  while(rotatePulseCount < -3560) { delay(1); }
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotateMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, HIGH); horizontalMoveDirection = -1;
  while(horizontalPulseCount > -3380) { delay(1); }
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, LOW); horizontalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_VERT_AXIS_DOWN, HIGH); verticalMoveDirection = -1;
  while(verticalPulseCount > -3000) { delay(1); }
  digitalWrite(MOTOR_VERT_AXIS_DOWN, LOW); verticalMoveDirection = 0; delay(10);

  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_VACUUM, LOW);
  delay(100);

  digitalWrite(MOTOR_VERT_AXIS_UP, HIGH); verticalMoveDirection = 1;
  while(digitalRead(REF_SWITCH_VERTICAL_AXIS) == LOW) { delay(1); }
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);

  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH); horizontalMoveDirection = 1;
  while(digitalRead(REF_SWITCH_HORIZONTAL_AXIS) == LOW) { delay(1); }
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
"""

# Same as PUT but with rotation homing at the end (for cycles 3, 6, 9 — after every 3 pieces)
GRABBER_PUT_TO_OVEN_WITH_ROTATE_HOMING = GRABBER_PUT_TO_OVEN + """
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  while(digitalRead(REF_SWITCH_ROTATE) == LOW) { delay(1); }
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotatePulseCount = 0; rotateMoveDirection = 0; delay(10);
"""

# ==========================================
# Oven station commands
# ==========================================

# Initial Homing for the Oven (executed in parallel with HBW + Grabber)
# Before the trigger, its events are not logged
OVEN_HOMING = """
  digitalWrite(Move_Table_TO_Vacuum, HIGH);
  while(digitalRead(RS_Table_vacum_position) == LOW) { delay(1); }
  digitalWrite(Move_Table_TO_Vacuum, LOW);

  digitalWrite(Move_Vacuum_To_TablePin, HIGH);
  while(digitalRead(RS_Vacum_Table_position) == LOW) { delay(1); }
  digitalWrite(Move_Vacuum_To_TablePin, LOW);

  digitalWrite(Move_Oven_outside, HIGH);
  while(digitalRead(RS_Oven_Feed_Out) == LOW) { delay(1); }
  digitalWrite(Move_Oven_outside, LOW);
"""

# One complete Oven cycle (processing a single piece from receiving until ejecting it)
# Starts by waiting for a piece on Oven_Light_Bar then executes the original 10 steps
OVEN_CYCLE = """
  while(digitalRead(Oven_Light_Bar) == HIGH) { delay(1); }
  delay(2000);

  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  delay(1000);

  digitalWrite(Move_Oven_inside, HIGH);
  while(digitalRead(RS_Oven_Feed_In) == LOW) { delay(1); }
  digitalWrite(Move_Oven_inside, LOW);

  digitalWrite(Oven_DoorPin, LOW);

  digitalWrite(Oven_Light, HIGH);
  digitalWrite(Compressor, LOW);
  delay(3000);
  digitalWrite(Oven_Light, LOW);

  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  delay(1000);

  digitalWrite(Move_Oven_outside, HIGH);
  while(digitalRead(RS_Oven_Feed_Out) == LOW) { delay(1); }
  digitalWrite(Move_Oven_outside, LOW);

  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Compressor, LOW);

  digitalWrite(Move_Vacuum_To_OvenPin, HIGH);
  while(digitalRead(RS_Vacum_Oven_position) == LOW) { delay(1); }
  digitalWrite(Move_Vacuum_To_OvenPin, LOW);

  digitalWrite(Compressor, HIGH);
  digitalWrite(Gripper, LOW);
  digitalWrite(Vacuum_Valve, HIGH);
  delay(500);
  digitalWrite(Gripper, HIGH);
  delay(500);
  digitalWrite(Vacuum_Valve, LOW);

  digitalWrite(Move_Vacuum_To_TablePin, HIGH);
  while(digitalRead(RS_Vacum_Table_position) == LOW) { delay(1); }
  digitalWrite(Move_Vacuum_To_TablePin, LOW);

  digitalWrite(Vacuum_Valve, HIGH);
  delay(500);
  digitalWrite(Gripper, LOW);
  delay(500);
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Compressor, LOW);

  digitalWrite(Move_Table_TO_belt, HIGH);
  while(digitalRead(RS_Table_Saw_position) == LOW) { delay(1); }
  digitalWrite(Move_Table_TO_belt, LOW);

  digitalWrite(Saw_Motor, HIGH);
  delay(2000);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Saw_Motor, LOW);

  digitalWrite(Move_Table_TO_belt, HIGH);
  while(digitalRead(RS_Table_belt_position) == LOW) { delay(1); }
  digitalWrite(Move_Table_TO_belt, LOW);

  digitalWrite(Table_Valve, HIGH);
  delay(500);
  digitalWrite(Table_Valve, LOW);
  digitalWrite(Compressor, LOW);

  digitalWrite(Belt_Motor, HIGH);
  while(digitalRead(Belt_Light_Bar) == HIGH) { delay(1); }
  delay(2000);
  digitalWrite(Belt_Motor, LOW);

  digitalWrite(Move_Table_TO_Vacuum, HIGH);
  while(digitalRead(RS_Table_vacum_position) == LOW) { delay(1); }
  digitalWrite(Move_Table_TO_Vacuum, LOW);
"""

# ==========================================
# Color Sorter station commands
# ==========================================
# The ColorSorter has no Initial Homing — it starts directly by waiting for a piece
#
# This block is an exact copy of the original C++ code with only two modifications:
#   1) (3.3f / 4095.0f) -> VOLTAGE_FACTOR (a constant pre-computed in the ESP32)
#   2) Variables and constants are defined in the ESP32 with the same names:
#      voltage, pieceMinVoltage, sensorValue, targetPulse, targetValve, pulseCount
#      THRESHOLD_BLUE_RED, THRESHOLD_RED_WHITE, THRESHOLD_WHITE_MIN
#      VALVE_WHITE, VALVE_RED, VALVE_BLUE
#
# Logic:
# - Waits for a piece at SENSOR_BEFORE
# - Runs the belt and reads the color while passing through SENSOR_AFTER
# - Analyzes the color by comparing pieceMinVoltage against the thresholds
# - Moves the piece the required distance (targetPulse) then pushes it with the appropriate valve

COLOR_SORTER_CYCLE = """
  RUN_COLOR_CYCLE;
"""

def set_remote_port(station_name, port_name):
    """Sends to the bridge: SET_PORT:<Station>:<COMx>"""
    print(f"Telling the bridge to open port {port_name} for station {station_name}...")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5.0)
            s.connect((VPN_SERVER_IP, PORT))
            
            # Send the port command with the station name
            s.sendall(f"SET_PORT:{station_name}:{port_name}\n<<<EOM>>>\n".encode('utf-8'))
            
            # Wait for an interruptible response
            s.settimeout(0.5)
            data = b""
            deadline = time.time() + 15.0  # 15 seconds maximum
            while not _user_interrupted.is_set() and time.time() < deadline:
                try:
                    chunk = s.recv(1024)
                    if not chunk:
                        break
                    data += chunk
                    if b"PORT_OK" in data or b"PORT_ERROR" in data:
                        break
                except socket.timeout:
                    continue
            
            if _user_interrupted.is_set():
                raise KeyboardInterrupt()
            
            decoded = data.decode('utf-8', errors='ignore').strip()
            if decoded == "PORT_OK":
                print(f"[✓] The bridge successfully connected to {port_name} for station {station_name}.\n")
                return True
            else:
                print(f"[!] The bridge failed to connect to {port_name} for station {station_name}.\n")
                return False
    except KeyboardInterrupt:
        raise
    except Exception as e:
        print(f"[!] Failed to connect to the bridge: {e}")
        return False

# ==========================================
# Network sending function
# ==========================================
def send_commands_to_robot(commands_text, station_name, task_name="Task"):
    """Sends a command block to a specific station via the bridge.
       Format: STATION:<name>\\n<commands>"""
    print(f"Sending: [{station_name}] {task_name}...")
    start_time = time.time()
    
    # Prepend the STATION:<name> prefix to the start of the text
    payload = f"STATION:{station_name}\n{commands_text}\n<<<EOM>>>\n"
    
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5.0)  # timeout for the connection
            s.connect((VPN_SERVER_IP, PORT))
            try:
                s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except Exception:
                pass
            
            # Check the trigger right before sending
            # (sets t_zero if this block contains MOTOR_HORZ_TO_RACK=HIGH and is sent to HBW)
            _maybe_set_trigger(commands_text, station_name)
            
            # Send the text (with the Station prefix)
            start_perf = time.perf_counter()   # ⏱️ Start of the total measurement (after the handshake)
            s.sendall(payload.encode('utf-8'))
            
            # Wait for a "DONE" reply from the bridge — but in an interruptible way
            s.settimeout(0.5)  # Check every half second
            data = b""
            while not _user_interrupted.is_set():
                try:
                    chunk = s.recv(1024)
                    if not chunk:
                        break
                    data += chunk
                    if b"DONE" in data or b"NO_PORT" in data or b"BAD_FORMAT" in data:
                        break
                except socket.timeout:
                    continue  # Retry and check the flag
            
            # If Ctrl+C was pressed
            if _user_interrupted.is_set():
                print(f"[!] '[{station_name}] {task_name}' was cancelled due to Ctrl+C")
                raise KeyboardInterrupt()
            
            decoded = data.decode('utf-8', errors='ignore').strip()
            first_token = decoded.split(',', 1)[0].strip()
            if first_token == "DONE":
                end_perf = time.perf_counter()
                total_ms = (end_perf - start_perf) * 1000.0

                # The bridge attaches the (serial+execution) time in the format: DONE,<bridge_ms>
                bridge_ms = None
                rep_parts = decoded.split(',', 1)
                if len(rep_parts) == 2:
                    try:
                        bridge_ms = float(rep_parts[1].strip())
                    except ValueError:
                        bridge_ms = None

                # Network time (round trip) = total − (serial+execution on the bridge)
                network_ms = (total_ms - bridge_ms) if bridge_ms is not None else None

                _timing_csv_queue.put([
                    station_name,
                    task_name,
                    round(total_ms, 3),
                    round(bridge_ms, 3) if bridge_ms is not None else '',
                    round(network_ms, 3) if network_ms is not None else '',
                ])

                if network_ms is not None:
                    print(f"[✓] '[{station_name}] {task_name}' — "
                          f"total={total_ms:.1f}ms | serial+execution={bridge_ms:.1f}ms | network(RTT)={network_ms:.1f}ms\n")
                else:
                    end_time = time.time()
                    print(f"[✓] Completed '[{station_name}] {task_name}'. (took {end_time - start_time:.2f} seconds)\n")
                return True
    except KeyboardInterrupt:
        raise  # Re-raise it up to main
    except Exception as e:
        print(f"[!] Failed to connect to the bridge. Details: {e}")
        return False

# ==========================================
# 3. Operation cycle (Sequence Execution)
# ==========================================
if __name__ == "__main__":
    print("=== Starting Control System (HBW + Grabber + Oven + ColorSorter) ===")
    print("    (Press Ctrl+C at any time for a safe stop and to save the CSV file)")
    
    # 0. Start the Pin Logger first (connects to the bridge to receive pin states)
    pin_csv_thread, pin_stream_thread, timing_thread, ping_thread = start_pin_logger()
    time.sleep(1)  # Give time for the connection to the bridge
    
    try:
        # 1. Open the ports on the bridge (sequentially, a quick step)
        HBW_PORT          = "COM3"
        GRABBER_PORT      = "COM4"
        COLORSORTER_PORT  = "COM5"
        OVEN_PORT         = "COM7"
        
        hbw_ok          = set_remote_port(STATION_HBW,          HBW_PORT)
        grabber_ok      = set_remote_port(STATION_GRABBER,      GRABBER_PORT)
        colorsorter_ok  = set_remote_port(STATION_COLORSORTER,  COLORSORTER_PORT)
        oven_ok         = set_remote_port(STATION_OVEN,         OVEN_PORT)
        
        if not (hbw_ok and grabber_ok and colorsorter_ok and oven_ok):
            print("\n[!] Failed to open one of the ports. Stopping.")
            raise SystemExit(1)
        
        time.sleep(1)
        
        # ==========================================
        # 2. Initial Homing — for the three stations in parallel
        # (before the trigger, its events are not logged)
        # ==========================================
        print("\n=== Initial Homing in parallel (HBW + Grabber + Oven) ===")
        
        homing_results = {}
        def _run_homing(station, block, label):
            ok = send_commands_to_robot(block, station, label)
            homing_results[station] = ok
        
        th_hbw = threading.Thread(
            target=_run_homing,
            args=(STATION_HBW, FINAL_HOMING, "Initial Homing"),
            daemon=True,
        )
        th_grb = threading.Thread(
            target=_run_homing,
            args=(STATION_GRABBER, GRABBER_INITIAL_HOMING, "Initial Homing"),
            daemon=True,
        )
        th_ovn = threading.Thread(
            target=_run_homing,
            args=(STATION_OVEN, OVEN_HOMING, "Initial Homing"),
            daemon=True,
        )
        th_hbw.start()
        th_grb.start()
        th_ovn.start()
        th_hbw.join()
        th_grb.join()
        th_ovn.join()
        
        if not all(homing_results.values()):
            print("\n[!] Initial Homing failed for one of the stations. Stopping.")
            raise SystemExit(1)
        
        time.sleep(1)
        
        # ==========================================
        # 3. Loop over the 9 positions
        #    Sequence of each cycle:
        #      a) HBW POS_X_RETRIEVE                  (sequential — the Grabber is waiting)
        #      b) Grabber PICK_FROM_HBW              (sequential — HBW is waiting)
        #      c) HBW POS_X_RETURN  ‖  Grabber PUT_TO_OVEN  (in parallel)
        #         ⚠️ HBW alone determines when to move to the next cycle (we do not wait for the Grabber)
        #    The trigger sets t=0 at the moment the first POS_RETRIEVE (POS_1) is sent
        #
        #    ⚠️ In parallel with all of the above: a background thread sends OVEN_CYCLE x 9
        #       Each oven cycle waits for a piece on Oven_Light_Bar inside the ESP32 itself
        #       (no coordination needed from the Sender — the oven detects the piece itself)
        # ==========================================
        POS_SEQUENCE = [
            (1, POS_1_RETRIEVE, POS_1_RETURN),
            (4, POS_4_RETRIEVE, POS_4_RETURN),
            (7, POS_7_RETRIEVE, POS_7_RETURN),
            (2, POS_2_RETRIEVE, POS_2_RETURN),
            (5, POS_5_RETRIEVE, POS_5_RETURN),
            (8, POS_8_RETRIEVE, POS_8_RETURN),
            (3, POS_3_RETRIEVE, POS_3_RETURN),
            (6, POS_6_RETRIEVE, POS_6_RETURN),
            (9, POS_9_RETRIEVE, POS_9_RETURN),
        ]
        
        # ──────────────────────────────────────────────────
        # Background thread for the Oven: sends 9 consecutive cycles
        # Each cycle waits for a piece at Oven_Light_Bar inside the ESP32
        # ──────────────────────────────────────────────────
        def _run_oven_cycles(total_cycles=9):
            for i in range(1, total_cycles + 1):
                if _user_interrupted.is_set():
                    print(f"[Oven] Stopped after {i-1} cycles (Ctrl+C)")
                    return
                print(f"\n[Oven Thread] → Sending cycle {i}/{total_cycles}")
                ok = send_commands_to_robot(OVEN_CYCLE, STATION_OVEN, f"Oven Cycle {i}")
                if not ok:
                    print(f"[Oven Thread] Cycle {i} failed — stopping the thread")
                    return
            print(f"[Oven Thread] ✓ All {total_cycles} cycles completed.")
        
        oven_thread = threading.Thread(
            target=_run_oven_cycles,
            args=(9,),
            daemon=False,
        )
        oven_thread.start()
        
        # ──────────────────────────────────────────────────
        # Background thread for the ColorSorter: sends 9 consecutive cycles
        # Each cycle waits for a piece at SENSOR_BEFORE inside the ESP32
        # ──────────────────────────────────────────────────
        def _run_colorsorter_cycles(total_cycles=9):
            for i in range(1, total_cycles + 1):
                if _user_interrupted.is_set():
                    print(f"[ColorSorter] Stopped after {i-1} cycles (Ctrl+C)")
                    return
                print(f"\n[ColorSorter Thread] → Sending cycle {i}/{total_cycles}")
                ok = send_commands_to_robot(COLOR_SORTER_CYCLE, STATION_COLORSORTER, f"ColorSorter Cycle {i}")
                if not ok:
                    print(f"[ColorSorter Thread] Cycle {i} failed — stopping the thread")
                    return
            print(f"[ColorSorter Thread] ✓ All {total_cycles} cycles completed.")
        
        colorsorter_thread = threading.Thread(
            target=_run_colorsorter_cycles,
            args=(9,),
            daemon=False,
        )
        colorsorter_thread.start()
        
        # Track the last Grabber PUT thread to ensure it finishes before the program ends
        last_grabber_put_thread = None
        
        def _run_send(block, station, label):
            """Helper function to run send_commands_to_robot inside a thread"""
            send_commands_to_robot(block, station, label)
        
        for cycle_index, (pos_num, retrieve_block, return_block) in enumerate(POS_SEQUENCE, start=1):
            # Every 3 pieces we use PUT with rotation homing
            if cycle_index % 3 == 0:
                put_block = GRABBER_PUT_TO_OVEN_WITH_ROTATE_HOMING
                put_label = f"Cycle {cycle_index} PUT (with rotate homing)"
            else:
                put_block = GRABBER_PUT_TO_OVEN
                put_label = f"Cycle {cycle_index} PUT"
            
            # ───── Phase (a): HBW RETRIEVE — sequential ─────
            print(f"\n=== POS {pos_num} — HBW Retrieve ===")
            send_commands_to_robot(retrieve_block, STATION_HBW, f"POS {pos_num} Retrieve")
            #time.sleep(1)
            
            # ───── Phase (b): Grabber PICK_FROM_HBW — sequential ─────
            print(f"\n=== Grabber Cycle {cycle_index} — PICK FROM HBW ===")
            send_commands_to_robot(GRABBER_PICK_FROM_HBW, STATION_GRABBER, f"Cycle {cycle_index} PICK")
            time.sleep(1)
            
            # ───── Phase (c): HBW RETURN ‖ Grabber PUT_TO_OVEN — parallel ─────
            # Make sure the previous PUT finished (theoretically we shouldn't need to wait since HBW Retrieve+Grabber Pick is longer
            #  than Grabber PUT, but we confirm for safety)
            if last_grabber_put_thread is not None and last_grabber_put_thread.is_alive():
                print(f"   [Waiting] Previous Grabber PUT is still running — waiting for it...")
                last_grabber_put_thread.join()
            
            print(f"\n=== HBW POS {pos_num} Return  ‖  Grabber {put_label} ===")
            
            # Run the Grabber PUT in a separate thread (do not wait for it)
            grabber_put_thread = threading.Thread(
                target=_run_send,
                args=(put_block, STATION_GRABBER, put_label),
                daemon=False,  # ⚠️ not a daemon: we want it to finish even if main proceeds
            )
            grabber_put_thread.start()
            last_grabber_put_thread = grabber_put_thread
            
            # HBW Return — in the main thread (sequential and controlled)
            # Once it finishes, move directly to the next POS (the Grabber may not have finished PUT yet)
            send_commands_to_robot(return_block, STATION_HBW, f"POS {pos_num} Return")
            #time.sleep(1)
        
        # ==========================================
        # 4. Wait for the last Grabber PUT + all Oven cycles + all ColorSorter cycles (before Final Homing)
        # ==========================================
        if last_grabber_put_thread is not None and last_grabber_put_thread.is_alive():
            print("\n=== Waiting for the last Grabber PUT to finish ===")
            last_grabber_put_thread.join()
        
        if oven_thread.is_alive():
            print("\n=== Waiting for all Oven cycles to finish ===")
            oven_thread.join()
        
        if colorsorter_thread.is_alive():
            print("\n=== Waiting for all ColorSorter cycles to finish ===")
            colorsorter_thread.join()
        
        # ==========================================
        # 5. Final Homing — for HBW only (Grabber/Oven/ColorSorter returned automatically to the starting point)
        # ==========================================
        print("\n=== Final Homing (HBW) ===")
        send_commands_to_robot(FINAL_HOMING, STATION_HBW, "Final Homing")
        
        print("\n[V] All factory simulation operations completed successfully!")
    
    except SystemExit:
        pass
    except KeyboardInterrupt:
        _user_interrupted.set()  # Set the flag even if a socket is stuck
        print("\n\n[!] Manual stop (Ctrl+C) — performing a safe shutdown...")
    
    finally:
        # Make sure the flag is set (even if for some reason we reached finally without except)
        _user_interrupted.set()
        
        # Stop the Pin Logger and close the CSV file safely (always executed)
        print("\n[PinLogger] Stopping and saving the file...")
        _pin_stop_event.set()
        pin_csv_thread.join(timeout=3.0)
        timing_thread.join(timeout=3.0)
        ping_thread.join(timeout=3.0)
        print(f"[PinLogger] ✓ Files saved: {OUTPUT_CSV} | {TIMING_CSV} | {PING_CSV}")
        print("Shutdown complete. Goodbye!")
