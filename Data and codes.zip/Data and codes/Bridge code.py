import socket
import serial
import time
import re
import threading
import queue
import csv
import os
from datetime import datetime

# ==========================================
# Settings
# ==========================================
BAUD_RATE = 115200
HOST = '0.0.0.0'
PORT_COMMANDS = 65432       # Port for receiving commands from the sender
PORT_PIN_STREAM = 65433     # Port for streaming pin states to the sender
PORT_PING       = 65434     # Port for measuring network RTT (lightweight ping/pong)

# Path to the CSV files (in the same folder as the code)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_CSV = os.path.join(SCRIPT_DIR, 'bridge_pin_log.csv')
ESP32_CSV  = os.path.join(SCRIPT_DIR, 'esp32_pin_log.csv')

# Fallback station name if the ESP32 didn't send a name in the EVT line
STATION_NAME_ESP32_FALLBACK = "UNKNOWN"

# Round to the nearest 10ms
QUANTIZE_10MS = True
# Ignore any duration less than or equal to 20ms
MIN_DURATION_MS = 20

# Trigger Pin: the counter doesn't start until this pin becomes HIGH for the first time
# This trigger belongs to HBW (the whole factory uses the same t_zero)
TRIGGER_PIN = "MOTOR_HORZ_TO_RACK"
TRIGGER_STATION = "HBW"   # The station from which the first trigger comes

# ==========================================
# Shared global variables
# ==========================================
# Dictionary: station_name -> SerialConnection
serial_conns = {}              # {"HBW": {"ser": Serial, "lock": Lock, "done": Event, "port": "COM3"}, ...}
serial_conns_lock = threading.Lock()

stop_event = threading.Event()

# Unified local time reference for all stations (for calculating RelativeTime)
# ⚠️ Important: one t_zero for the whole factory — all stations use it
t_zero_perf = None
t_zero_lock = threading.Lock()

# Queue for writing to CSV (shared across all stations)
csv_queue = queue.SimpleQueue()
esp32_csv_queue = queue.SimpleQueue()

# Queue for streaming the raw lines to the sender
pin_stream_queue = queue.Queue(maxsize=10000)
sender_clients = []
sender_clients_lock = threading.Lock()

# Previous pin states — separate for each station
# {station_name: {"header_pins": [...], "header_line": "...", "prev_states": {...}, "prev_change_perf": {...}}}
stations_state = {}
stations_state_lock = threading.Lock()

# Have we seen the trigger pin = HIGH for the first time? (unified for the factory)
trigger_seen = False
trigger_lock = threading.Lock()

# ==========================================
# Helper functions
# ==========================================
def q10(x_ms: float) -> int:
    """Round to the nearest 10ms"""
    if not QUANTIZE_10MS:
        return int(round(x_ms))
    return int(round(x_ms / 10.0) * 10)

def ensure_station(station_name: str):
    """Initializes a state dict for a station if it doesn't exist"""
    with stations_state_lock:
        if station_name not in stations_state:
            stations_state[station_name] = {
                "header_pins": [],
                "header_line": None,
                "prev_states": {},
                "prev_change_perf": {},
            }

# ==========================================
# CSV writing thread (real-time with flush)
# ==========================================
class CSVWriterThread(threading.Thread):
    def __init__(self, path, src_queue):
        super().__init__(daemon=True)
        self.path = path
        self.src_queue = src_queue
        self.f = None
        self.writer = None

    def run(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
        except Exception:
            pass
        
        try:
            self.f = open(self.path, 'w', newline='', buffering=1, encoding='utf-8')
            self.writer = csv.writer(self.f)
            self.writer.writerow(['Station', 'RelativeTime(ms)', 'Pin', 'NewState', 'Duration(ms)'])
            self.f.flush()
        except Exception as e:
            print(f"[CSV] Failed to open file {self.path}: {e}")
            return

        while not stop_event.is_set():
            try:
                row = self.src_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                self.writer.writerow(row)
                self.f.flush()
            except Exception as e:
                print(f"[CSV] Write error for {self.path}: {e}")

        # Flush what remains before closing
        while True:
            try:
                row = self.src_queue.get_nowait()
                self.writer.writerow(row)
            except queue.Empty:
                break
        try:
            self.f.flush()
            self.f.close()
        except Exception:
            pass

# ==========================================
# Thread streaming pin states to the connected sender(s)
# ==========================================
class PinStreamServerThread(threading.Thread):
    """Opens a TCP server and accepts the Sender as a client, then sends it pin state lines"""
    def __init__(self, port):
        super().__init__(daemon=True)
        self.port = port

    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, self.port))
        srv.listen(5)
        srv.settimeout(1.0)
        print(f"[PinStream] Server listening on {HOST}:{self.port} to stream pin states")
        
        while not stop_event.is_set():
            try:
                client_conn, client_addr = srv.accept()
                print(f"[PinStream] New connection from the sender: {client_addr}")
                
                # Immediately send headers for all available stations to the new client
                with stations_state_lock:
                    snapshot_headers = [(st, info["header_line"]) 
                                        for st, info in stations_state.items() 
                                        if info["header_line"]]
                
                if snapshot_headers:
                    try:
                        for st, hdr in snapshot_headers:
                            client_conn.sendall((hdr + '\n').encode('utf-8'))
                        print(f"[PinStream] Sent {len(snapshot_headers)} header(s) to the new client.")
                    except Exception as e:
                        print(f"[PinStream] Failed to send the headers: {e}")
                        try:
                            client_conn.close()
                        except Exception:
                            pass
                        continue
                else:
                    print(f"[PinStream] ⚠ No headers yet — the sender will wait.")
                
                with sender_clients_lock:
                    sender_clients.append(client_conn)
            except socket.timeout:
                continue
            except Exception as e:
                if not stop_event.is_set():
                    print(f"[PinStream] Accept error: {e}")
                break
        try:
            srv.close()
        except Exception:
            pass


class PinStreamBroadcastThread(threading.Thread):
    """Takes lines from the queue and sends them to all connected clients"""
    def __init__(self):
        super().__init__(daemon=True)

    def run(self):
        while not stop_event.is_set():
            try:
                line = pin_stream_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            
            data = (line + '\n').encode('utf-8', errors='ignore')
            dead = []
            with sender_clients_lock:
                clients_snapshot = list(sender_clients)
            
            for c in clients_snapshot:
                try:
                    c.sendall(data)
                except Exception:
                    dead.append(c)
            
            if dead:
                with sender_clients_lock:
                    for c in dead:
                        if c in sender_clients:
                            sender_clients.remove(c)
                        try:
                            c.close()
                        except Exception:
                            pass

# ==========================================
# Thread reading from the serial port for a single station (pin states + EVT + DONE)
# ==========================================
class SerialReaderThread(threading.Thread):
    def __init__(self, station_name):
        super().__init__(daemon=True)
        self.station_name = station_name
        self.name = f"SerialReader-{station_name}"

    def run(self):
        global t_zero_perf
        
        while not stop_event.is_set():
            # Get the serial connection for the station
            with serial_conns_lock:
                conn_info = serial_conns.get(self.station_name)
            
            if conn_info is None or conn_info["ser"] is None or not conn_info["ser"].is_open:
                time.sleep(0.1)
                continue
            
            ser = conn_info["ser"]
            lock = conn_info["lock"]
            done_event = conn_info["done"]
            
            try:
                with lock:
                    if ser.in_waiting > 0:
                        raw = ser.readline()
                    else:
                        raw = b''
            except Exception as e:
                print(f"[SerialReader-{self.station_name}] Read error: {e}")
                time.sleep(0.05)
                continue
            
            if not raw:
                time.sleep(0.005)
                continue
            
            line = raw.decode('utf-8', errors='ignore').strip()
            if not line:
                continue
            
            # 1) If "DONE" -> signal that a normal command has finished
            #    "DONE_SET_T_ZERO" -> signal that SET_T_ZERO was received (a separate event to avoid a race condition)
            if line == "DONE_SET_T_ZERO":
                conn_info["done_set_t_zero"].set()
                continue
            if line == "DONE":
                done_event.set()
                continue
            
            # 2) If an EVT line (a measurement from the ESP32 itself) -> save it to the ESP32 file
            #    Format: EVT,Station,RelativeTime,Pin,NewState,Duration
            if line.startswith("EVT,"):
                ev_parts = line.split(',')
                if len(ev_parts) >= 6:
                    try:
                        ev_station  = ev_parts[1].strip()
                        ev_rel_time = int(ev_parts[2].strip())
                        ev_pin      = ev_parts[3].strip()
                        ev_state    = ev_parts[4].strip()
                        ev_duration = int(ev_parts[5].strip())
                        if not ev_station:
                            ev_station = STATION_NAME_ESP32_FALLBACK
                        esp32_csv_queue.put([ev_station, ev_rel_time, ev_pin, ev_state, ev_duration])
                        # Only non-numeric events (like COLOR) are forwarded to the bridge and sender.
                        # The numeric pins (valves, etc.) already come through the periodic state stream — avoiding duplication.
                        if ev_pin == "COLOR":
                            csv_queue.put([ev_station, ev_rel_time, ev_pin, ev_state, ev_duration])
                            try:
                                pin_stream_queue.put_nowait(line)
                            except queue.Full:
                                pass
                    except ValueError:
                        pass
                continue
            
            # 3) All other lines must start with the station name (Station,...)
            #    Either header: Station,timestamp,p1,p2,...
            #    or data:   Station,12345,0,1,0,...
            parts = [p.strip() for p in line.split(',')]
            if len(parts) < 2:
                continue
            
            station_from_line = parts[0]
            second_field = parts[1]
            
            # Make sure the station is initialized (usually already is)
            ensure_station(station_from_line)
            
            # 3a) Header? (the second field starts with "timestamp")
            if second_field.lower().startswith("timestamp"):
                with stations_state_lock:
                    first_time_header = (stations_state[station_from_line]["header_line"] is None)
                    stations_state[station_from_line]["header_line"] = line
                    # header pins = all fields after Station and timestamp
                    stations_state[station_from_line]["header_pins"] = parts[2:]
                    for p in parts[2:]:
                        stations_state[station_from_line]["prev_states"][p] = None
                        stations_state[station_from_line]["prev_change_perf"][p] = None
                
                print(f"[SerialReader-{self.station_name}] Received header for {station_from_line}: {len(parts)-2} pins")
                
                # Send the header to all currently connected clients
                if first_time_header:
                    with sender_clients_lock:
                        clients_snapshot = list(sender_clients)
                    data = (line + '\n').encode('utf-8')
                    for c in clients_snapshot:
                        try:
                            c.sendall(data)
                        except Exception:
                            pass
                continue
            
            # 3b) Normal pin states line: Station,timestamp,p1,p2,...
            try:
                int(second_field)  # Make sure the timestamp is a number
            except ValueError:
                continue
            
            with stations_state_lock:
                station_info = stations_state.get(station_from_line)
                if not station_info or not station_info["header_pins"]:
                    continue
                header_pins_local = list(station_info["header_pins"])
            
            # Stream the raw line to the sender
            try:
                pin_stream_queue.put_nowait(line)
            except queue.Full:
                pass
            
            # Prepare the current pin states (ignore the first two fields: Station, timestamp)
            states = parts[2:]
            if len(states) < len(header_pins_local):
                states += [''] * (len(header_pins_local) - len(states))
            elif len(states) > len(header_pins_local):
                states = states[:len(header_pins_local)]
            
            # ============ Trigger check ============
            with trigger_lock:
                local_trigger_seen = trigger_seen
            
            if not local_trigger_seen:
                # Before the trigger: only update the last known state (without CSV)
                now_perf_local = time.perf_counter()
                with stations_state_lock:
                    for p, s in zip(header_pins_local, states):
                        stations_state[station_from_line]["prev_states"][p] = s
                        stations_state[station_from_line]["prev_change_perf"][p] = now_perf_local
                continue
            
            # ============ After the trigger: calculate durations normally ============
            now_perf = time.perf_counter()
            rel_time_ms = (now_perf - t_zero_perf) * 1000.0
            rel_time_q = q10(rel_time_ms)
            
            with stations_state_lock:
                for pin, cur_state in zip(header_pins_local, states):
                    prev_s = stations_state[station_from_line]["prev_states"].get(pin)
                    prev_t = stations_state[station_from_line]["prev_change_perf"].get(pin)
                    
                    if prev_s is None:
                        stations_state[station_from_line]["prev_states"][pin] = cur_state
                        stations_state[station_from_line]["prev_change_perf"][pin] = now_perf
                        continue
                    
                    if prev_s != cur_state:
                        duration_ms = (now_perf - prev_t) * 1000.0 if prev_t else 0.0
                        
                        # 20ms filter: ignore completely
                        if duration_ms <= MIN_DURATION_MS:
                            continue
                        
                        duration_q = q10(duration_ms)
                        csv_queue.put([station_from_line, rel_time_q, pin, cur_state, duration_q])
                        
                        stations_state[station_from_line]["prev_states"][pin] = cur_state
                        stations_state[station_from_line]["prev_change_perf"][pin] = now_perf

# ==========================================
# Commands server thread
# ==========================================
class CommandServerThread(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)

    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, PORT_COMMANDS))
        srv.listen(5)
        srv.settimeout(1.0)
        print(f"[Commands] Server listening on {HOST}:{PORT_COMMANDS} to receive commands")
        
        while not stop_event.is_set():
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            except Exception as e:
                if not stop_event.is_set():
                    print(f"[Commands] accept error: {e}")
                break
            
            # Handle each connection in a separate thread (to support parallel Initial Homing)
            threading.Thread(
                target=self._handle_client,
                args=(conn, addr),
                daemon=True
            ).start()
        
        try:
            srv.close()
        except Exception:
            pass

    def _handle_client(self, conn, addr):
        global trigger_seen, t_zero_perf
        
        with conn:
            try:
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except Exception:
                pass
            data = b''
            conn.settimeout(15.0)        # We rely on the terminator, not a short timeout
            TERM = b"<<<EOM>>>"
            try:
                while True:
                    chunk = conn.recv(65536)
                    if not chunk:
                        break
                    data += chunk
                    if TERM in data:        # ✅ Stop once the full message has arrived
                        break
            except socket.timeout:
                pass
            except Exception as e:
                print(f"[Commands] recv error: {e}")
                return

            if not data:
                return

            text_block = data.decode('utf-8', errors='ignore')
            idx = text_block.find("<<<EOM>>>")
            if idx != -1:
                text_block = text_block[:idx]   # Remove the marker and anything after it
            text_block = text_block.strip()
            
            # ============ SET_PORT:Station:COMx ============
            if text_block.startswith("SET_PORT:"):
                # Format: SET_PORT:HBW:COM3 or SET_PORT:Grabber:COM4
                try:
                    _, station_name, port_name = text_block.split(":", 2)
                    station_name = station_name.strip()
                    port_name = port_name.strip()
                except ValueError:
                    print(f"[Commands] Invalid SET_PORT format: {text_block}")
                    try:
                        conn.sendall(b"PORT_ERROR")
                    except Exception:
                        pass
                    return
                
                print(f"\n[+] Connection request for station {station_name} on port: {port_name}")
                try:
                    # Initialize an entry for the station if it doesn't exist
                    with serial_conns_lock:
                        if station_name in serial_conns:
                            old_ser = serial_conns[station_name]["ser"]
                            if old_ser and old_ser.is_open:
                                try:
                                    old_ser.close()
                                except Exception:
                                    pass
                        else:
                            serial_conns[station_name] = {
                                "ser": None,
                                "lock": threading.Lock(),
                                "done": threading.Event(),
                                "done_set_t_zero": threading.Event(),  # separate event for SET_T_ZERO
                                "port": None,
                            }
                        
                        new_ser = serial.Serial(port_name, BAUD_RATE, timeout=1)
                        serial_conns[station_name]["ser"] = new_ser
                        serial_conns[station_name]["port"] = port_name
                    
                    # Initialize the state dict for the station
                    ensure_station(station_name)
                    
                    # Start the SerialReaderThread for this station (if not already running)
                    reader_attr = f"_reader_thread_{station_name}"
                    if not hasattr(self, reader_attr) or not getattr(self, reader_attr).is_alive():
                        rt = SerialReaderThread(station_name)
                        rt.start()
                        setattr(self, reader_attr, rt)
                    
                    time.sleep(2)
                    print(f"   [✓] Connected on {port_name} for station {station_name}")
                    conn.sendall(b"PORT_OK")
                except Exception as e:
                    print(f"   [!] Failed: {e}")
                    try:
                        conn.sendall(b"PORT_ERROR")
                    except Exception:
                        pass
                return
            
            # ============ STATION:<name>\n<commands> ============
            # New format: first line STATION:HBW or STATION:Grabber
            #                rest of the text = the commands
            if not text_block.startswith("STATION:"):
                print(f"[Commands] Unknown format, must start with STATION: or SET_PORT:")
                try:
                    conn.sendall(b"BAD_FORMAT")
                except Exception:
                    pass
                return
            
            # Extract the station name from the first line
            first_newline = text_block.find('\n')
            if first_newline == -1:
                print(f"[Commands] STATION: with no commands after it")
                try:
                    conn.sendall(b"BAD_FORMAT")
                except Exception:
                    pass
                return
            
            station_line = text_block[:first_newline].strip()
            commands_text = text_block[first_newline+1:].strip()
            target_station = station_line.split(":", 1)[1].strip()
            
            # Verify the station has an open serial port
            with serial_conns_lock:
                conn_info = serial_conns.get(target_station)
            
            if conn_info is None or conn_info["ser"] is None or not conn_info["ser"].is_open:
                print(f"\n[!] Command for station {target_station} with no open port!")
                try:
                    conn.sendall(b"NO_PORT")
                except Exception:
                    pass
                return
            
            ser = conn_info["ser"]
            ser_lock = conn_info["lock"]
            done_event = conn_info["done"]
            
            print(f"\n[+] Received command batch for station {target_station} from: {addr}")
            # ⏱️ Start of leg measurement (serial + execution) — on the bridge's clock
            bridge_t0 = time.perf_counter()
            
            # ============ Smart block splitting that respects braces ============
            # We split on an empty line, but only if the brace depth = 0
            # This keeps blocks like `if (...) {  ...  ... }` intact
            # even if they contain an internal empty line
            def split_blocks_respecting_braces(text):
                result = []
                lines = text.split('\n')
                current = []
                depth = 0
                
                def update_depth(line, d):
                    # We ignore { and } inside strings/comments (not relevant here, the commands don't have any)
                    for ch in line:
                        if ch == '{': d += 1
                        elif ch == '}': d -= 1
                    return d
                
                for line in lines:
                    stripped = line.strip()
                    # Empty line + outside all blocks -> end of block
                    if not stripped and depth <= 0:
                        if current:
                            result.append('\n'.join(current))
                            current = []
                        continue
                    current.append(line)
                    depth = update_depth(line, depth)
                
                if current:
                    result.append('\n'.join(current))
                return result
            
            blocks = split_blocks_respecting_braces(commands_text)
            for block in blocks:
                single_line_cmd = block.replace('\n', ' ').strip()
                if not single_line_cmd or single_line_cmd.startswith("//"):
                    continue
                
                #print(f"   -> [{target_station}] {single_line_cmd[:60]}...")
                
                # Reset done_event before sending
                done_event.clear()
                
                # ============ Trigger check ============
                # If this line contains digitalWrite(MOTOR_HORZ_TO_RACK, HIGH) at HBW
                # and it's the first time -> set t_zero at the moment of sending + notify the other stations
                with trigger_lock:
                    is_trigger_now = (not trigger_seen 
                                      and target_station == TRIGGER_STATION
                                      and f"digitalWrite({TRIGGER_PIN}, HIGH)" in single_line_cmd)
                    if is_trigger_now:
                        with t_zero_lock:
                            t_zero_perf = time.perf_counter()
                        trigger_seen = True
                        print(f"   [Trigger] ✓ MOTOR_HORZ_TO_RACK=HIGH — counting has started now.")
                
                try:
                    with ser_lock:
                        ser.write((single_line_cmd + '\n').encode('utf-8'))
                except Exception as e:
                    print(f"   [!] Write error: {e}")
                    break
                
                # ⚠️ Important: if this is the first trigger, send SET_T_ZERO to all other stations
                # (sent right after writing the original command to HBW to minimize the gap)
                if is_trigger_now:
                    with serial_conns_lock:
                        other_stations = [(name, info) for name, info in serial_conns.items() 
                                          if name != TRIGGER_STATION
                                          and info["ser"] is not None
                                          and info["ser"].is_open]
                    
                    for other_name, other_info in other_stations:
                        try:
                            with other_info["lock"]:
                                # Clear the done_set_t_zero event for the station (not the regular done!)
                                # so we don't confuse block-level DONE with SET_T_ZERO DONE
                                other_info["done_set_t_zero"].clear()
                                other_info["ser"].write(b"SET_T_ZERO\n")
                            print(f"   [Trigger] → SET_T_ZERO sent to {other_name}")
                        except Exception as e:
                            print(f"   [!] Failed to send SET_T_ZERO to {other_name}: {e}")
                
                # Wait for DONE from the SerialReaderThread for the target station
                if done_event.wait(timeout=120.0):
                    print(f"   [✓] DONE from {target_station}.")
                else:
                    print(f"   [!] Waiting for DONE from {target_station} timed out.")
                    break
                
                # If we sent SET_T_ZERO, wait for DONE_SET_T_ZERO from the other stations
                # (an event independent from the regular done — does not interfere with the running OVEN_CYCLE/COLOR_SORTER_CYCLE)
                if is_trigger_now:
                    for other_name, other_info in other_stations:
                        if other_info["done_set_t_zero"].wait(timeout=5.0):
                            print(f"   [✓] DONE_SET_T_ZERO from {other_name}.")
                        else:
                            print(f"   [!] Waiting for DONE_SET_T_ZERO from {other_name} timed out.")
            
            # ⏱️ End of leg (serial + execution) — attached to DONE so the sender can compute network time
            bridge_ms = (time.perf_counter() - bridge_t0) * 1000.0
            print(f"[✓] Batch finished for station {target_station}. (serial+execution={bridge_ms:.1f}ms)")
            try:
                conn.sendall(f"DONE,{bridge_ms:.3f}".encode('utf-8'))
            except Exception:
                pass

# ==========================================
# Ping server thread (pure network RTT measurement)
# ==========================================
class PingServerThread(threading.Thread):
    """Replies immediately to every PING line with the same content (echo), with no execution or serial involved.
       Goal: measure the pure VPN RTT isolated from the serial and execution on the factory."""
    def __init__(self, port):
        super().__init__(daemon=True)
        self.port = port

    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, self.port))
        srv.listen(5)
        srv.settimeout(1.0)
        print(f"[Ping] Server listening on {HOST}:{self.port} to measure network RTT")

        while not stop_event.is_set():
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            except Exception as e:
                if not stop_event.is_set():
                    print(f"[Ping] accept error: {e}")
                break
            threading.Thread(target=self._handle, args=(conn, addr), daemon=True).start()
        try:
            srv.close()
        except Exception:
            pass

    def _handle(self, conn, addr):
        print(f"[Ping] New ping connection from {addr}")
        with conn:
            try:
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except Exception:
                pass
            conn.settimeout(1.0)
            buf = b''
            while not stop_event.is_set():
                try:
                    chunk = conn.recv(4096)
                except socket.timeout:
                    continue
                except Exception:
                    break
                if not chunk:
                    break
                buf += chunk
                # Immediate echo for each complete line (with minimal possible delay)
                while b'\n' in buf:
                    line_b, buf = buf.split(b'\n', 1)
                    try:
                        conn.sendall(line_b + b'\n')
                    except Exception:
                        return


# ==========================================
# Main
# ==========================================
def main():
    print("=" * 60)
    print("Bridge.py — Pin Logger + Multi-Station Command Relay")
    print(f"Bridge CSV: {OUTPUT_CSV}")
    print(f"ESP32 CSV : {ESP32_CSV}")
    print(f"  Trigger: moment '{TRIGGER_PIN}=HIGH' is sent to {TRIGGER_STATION}")
    print(f"  Min duration filter: > {MIN_DURATION_MS} ms")
    print(f"  Quantize to 10ms: {QUANTIZE_10MS}")
    print("=" * 60)
    
    csv_writer       = CSVWriterThread(OUTPUT_CSV, csv_queue)
    esp32_csv_writer = CSVWriterThread(ESP32_CSV,  esp32_csv_queue)
    pin_server       = PinStreamServerThread(PORT_PIN_STREAM)
    pin_broadcast    = PinStreamBroadcastThread()
    cmd_server       = CommandServerThread()
    ping_server      = PingServerThread(PORT_PING)
    
    csv_writer.start()
    esp32_csv_writer.start()
    pin_server.start()
    pin_broadcast.start()
    cmd_server.start()
    ping_server.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[!] Manual stop…")
        stop_event.set()
    
    # Cleanup
    with serial_conns_lock:
        for st, info in serial_conns.items():
            ser = info.get("ser")
            if ser and ser.is_open:
                try:
                    ser.close()
                except Exception:
                    pass
    
    with sender_clients_lock:
        for c in sender_clients:
            try:
                c.close()
            except Exception:
                pass
    
    csv_writer.join(timeout=3.0)
    esp32_csv_writer.join(timeout=3.0)
    print("Shutdown complete.")

if __name__ == "__main__":
    main()
