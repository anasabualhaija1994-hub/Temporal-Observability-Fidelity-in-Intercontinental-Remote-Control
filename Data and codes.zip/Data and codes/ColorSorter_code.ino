#include <Arduino.h>

// ==========================================
// 0. Name of this station
// ==========================================
#define STATION_NAME "ColorSorter"

// ==========================================
// 1. Pin Definitions
// ==========================================
#define BELT_MOTOR     13
#define COMPRESSOR     12
#define VALVE_WHITE    14
#define VALVE_RED      27
#define VALVE_BLUE     26

#define PULSE_COUNTER  36
#define SENSOR_BEFORE  39
#define SENSOR_AFTER   34
//#define SENSOR_Q1      35
//#define SENSOR_Q2      32
//#define SENSOR_Q3      33
#define COLOR_SENSOR   25

// ==========================================
// 1.a Color calibration constants (Color Thresholds)
// Used as known names in the interpreter
// ==========================================
const float WHITE_MIN_V = 0.8002f;
const float RED_MIN_V   = 1.6222f;
const float BLUE_MIN_V  = 2.0000f;

const float THRESHOLD_RED_WHITE = (RED_MIN_V + WHITE_MIN_V) / 2.0f;  // 1.2112
const float THRESHOLD_BLUE_RED  = (BLUE_MIN_V + RED_MIN_V) / 2.0f;   // 1.8111
const float THRESHOLD_WHITE_MIN = 0.4500f;

// A pre-computed constant to convert analogRead -> voltage
// Used to be (3.3f / 4095.0f) in the original code
const float VOLTAGE_FACTOR = 0.000805861f;

// ==========================================
// 1.b Global variables (used by the interpreter)
// All floats so we handle the voltage precisely (exact copy of the C++ code)
// ==========================================
volatile unsigned int pulseCount = 0;

int   sensorValue     = 0;
float voltage         = 0.0f;
float pieceMinVoltage = 3.3f;
int   targetPulse     = 0;
int   targetValve     = -1;  // -1 = no valve specified (exact copy of the original code)
unsigned long colorMeasDur = 0;  // Duration of the color measurement window (ms) — written to the Duration column

// ⚠️ DEBUG TEMPORARY: set to 0 to turn off all diagnostic messages
// Once everything works correctly, change this to 0 and re-upload the code
#define DEBUG_INTERPRETER 1

// Interrupt (ISR) to count belt pulses
void IRAM_ATTR countPulse() {
  pulseCount++;
}

// ==========================================
// 1.c Periodic Logger variables (every 20ms)
// ==========================================
unsigned long lastLogTime = 0;
const unsigned long LOG_INTERVAL_MS = 20;

// ==========================================
// 1.d Event Logger variables
// ==========================================
const int NUM_TRACKED_PINS = 10;

const char* PIN_NAMES[NUM_TRACKED_PINS] = {
  "SENSOR_BEFORE",
  "SENSOR_AFTER",
  //"SENSOR_Q1",
  //"SENSOR_Q2",
  //"SENSOR_Q3",
  "BELT_MOTOR",
  "COMPRESSOR",
  "VALVE_WHITE",
  "VALVE_RED",
  "VALVE_BLUE"
};

const int PIN_NUMBERS[NUM_TRACKED_PINS] = {
  SENSOR_BEFORE,
  SENSOR_AFTER,
  //SENSOR_Q1,
  //SENSOR_Q2,
 // SENSOR_Q3,
  BELT_MOTOR,
  COMPRESSOR,
  VALVE_WHITE,
  VALVE_RED,
  VALVE_BLUE
};

int lastPinStates[NUM_TRACKED_PINS];
unsigned long lastChangeTime[NUM_TRACKED_PINS];
int candidateState[NUM_TRACKED_PINS];
unsigned long candidateSince[NUM_TRACKED_PINS];
const unsigned long DEBOUNCE_MS = 5;

bool esp_trigger_seen = false;
unsigned long esp_t_zero = 0;

const unsigned long EVT_MIN_DURATION_MS = 20;

// ==========================================
// 1.e Function to round to the nearest 10ms
// ==========================================
unsigned long q10(unsigned long x) {
  return ((x + 5) / 10) * 10;
}

// ==========================================
// 1.f Function to print periodic Pin states
// ==========================================
void printPinStates() {
  unsigned long now = millis();
  if (now - lastLogTime < LOG_INTERVAL_MS) return;
  lastLogTime = now;
  
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.print(now);
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    Serial.print(","); Serial.print(digitalRead(PIN_NUMBERS[i]));
  }
  Serial.println();
}

// ==========================================
// 1.g Check Pin changes (EVT)
// ==========================================
void checkPinChanges() {
  unsigned long now = millis();
  
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int cur = digitalRead(PIN_NUMBERS[i]);
    
    if (cur == lastPinStates[i]) {
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;
    }
    
    if (cur != candidateState[i]) {
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;
    }
    
    if (now - candidateSince[i] < DEBOUNCE_MS) continue;
    
    unsigned long change_time = candidateSince[i];
    
    if (!esp_trigger_seen) {
      lastPinStates[i] = cur;
      lastChangeTime[i] = change_time;
      continue;
    }
    
    unsigned long duration = change_time - lastChangeTime[i];
    
    if (duration > EVT_MIN_DURATION_MS) {
      unsigned long rel_time = change_time - esp_t_zero;
      Serial.print("EVT,");
      Serial.print(STATION_NAME);
      Serial.print(",");
      Serial.print(q10(rel_time));
      Serial.print(",");
      Serial.print(PIN_NAMES[i]);
      Serial.print(",");
      Serial.print(cur);
      Serial.print(",");
      Serial.println(q10(duration));
    }
    
    lastPinStates[i] = cur;
    lastChangeTime[i] = change_time;
  }
}

// ==========================================
// 1.h Set t_zero via a command from the Bridge
// ==========================================
void setTriggerFromBridge() {
  if (esp_trigger_seen) return;
  
  unsigned long now = millis();
  esp_t_zero = now;
  esp_trigger_seen = true;
  
  for (int j = 0; j < NUM_TRACKED_PINS; j++) {
    lastChangeTime[j] = esp_t_zero;
    lastPinStates[j] = digitalRead(PIN_NUMBERS[j]);
    candidateState[j] = lastPinStates[j];
    candidateSince[j] = esp_t_zero;
  }
  
  Serial.print("EVT,");
  Serial.print(STATION_NAME);
  Serial.print(",0,SYSTEM_TRIGGER,1,0");
  Serial.println();
}

// ==========================================
// 2. Translate names into port numbers
// ==========================================
int getPinFromName(String pinName) {
  pinName.trim();
  if (pinName == "BELT_MOTOR")    return 13;
  if (pinName == "COMPRESSOR")    return 12;
  if (pinName == "VALVE_WHITE")   return 14;
  if (pinName == "VALVE_RED")     return 27;
  if (pinName == "VALVE_BLUE")    return 26;
  if (pinName == "PULSE_COUNTER") return 36;
  if (pinName == "SENSOR_BEFORE") return 39;
  if (pinName == "SENSOR_AFTER")  return 34;
  //if (pinName == "SENSOR_Q1")     return 35;
 // if (pinName == "SENSOR_Q2")     return 32;
 // if (pinName == "SENSOR_Q3")     return 33;
  if (pinName == "COLOR_SENSOR")  return 25;
  
  return pinName.toInt();
}

// ==========================================
// 3. Read the value of a "name" as a float
// Can be: a variable, a constant, a direct number, a pin name, HIGH/LOW
// This is the core that solves the previous problem
// ==========================================
float getValueAsFloat(String token) {
  token.trim();
  
  // ============ Variables ============
  if (token == "voltage")          return voltage;
  if (token == "pieceMinVoltage")  return pieceMinVoltage;
  if (token == "sensorValue")      return (float)sensorValue;
  if (token == "targetPulse")      return (float)targetPulse;
  if (token == "targetValve")      return (float)targetValve;
  if (token == "pulseCount")       return (float)pulseCount;
  
  // ============ Calibration constants ============
  if (token == "THRESHOLD_RED_WHITE") return THRESHOLD_RED_WHITE;
  if (token == "THRESHOLD_BLUE_RED")  return THRESHOLD_BLUE_RED;
  if (token == "THRESHOLD_WHITE_MIN") return THRESHOLD_WHITE_MIN;
  if (token == "WHITE_MIN_V")         return WHITE_MIN_V;
  if (token == "RED_MIN_V")           return RED_MIN_V;
  if (token == "BLUE_MIN_V")          return BLUE_MIN_V;
  if (token == "VOLTAGE_FACTOR")      return VOLTAGE_FACTOR;
  
  // ============ Valve constants (as pin numbers) ============
  if (token == "VALVE_WHITE") return 14.0f;
  if (token == "VALVE_RED")   return 27.0f;
  if (token == "VALVE_BLUE")  return 26.0f;
  
  // ============ HIGH/LOW ============
  if (token == "HIGH") return 1.0f;
  if (token == "LOW")  return 0.0f;
  
  // ============ Direct number (supports int and float and sign) ============
  return token.toFloat();
}

// ==========================================
// 4. Write a value to a variable by name
// We handle each variable's type according to its definition
// ==========================================
void setVariableValue(String varName, float value) {
  varName.trim();
  if      (varName == "voltage")          voltage = value;
  else if (varName == "pieceMinVoltage")  pieceMinVoltage = value;
  else if (varName == "sensorValue")      sensorValue = (int)value;
  else if (varName == "targetPulse")      targetPulse = (int)value;
  else if (varName == "targetValve")      targetValve = (int)value;
  else if (varName == "pulseCount")       pulseCount = (unsigned int)value;
}

// ==========================================
// 5. Setup
// ==========================================
void setupPins() {
  pinMode(BELT_MOTOR, OUTPUT);
  pinMode(COMPRESSOR, OUTPUT);
  pinMode(VALVE_WHITE, OUTPUT);
  pinMode(VALVE_RED, OUTPUT);
  pinMode(VALVE_BLUE, OUTPUT);
  
  pinMode(PULSE_COUNTER, INPUT);
  pinMode(SENSOR_BEFORE, INPUT);
  pinMode(SENSOR_AFTER, INPUT);
 // pinMode(SENSOR_Q1, INPUT);
 // pinMode(SENSOR_Q2, INPUT);
 // pinMode(SENSOR_Q3, INPUT);
  pinMode(COLOR_SENSOR, INPUT);
  
  digitalWrite(BELT_MOTOR, LOW);
  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_WHITE, LOW);
  digitalWrite(VALVE_RED, LOW);
  digitalWrite(VALVE_BLUE, LOW);
  
  attachInterrupt(digitalPinToInterrupt(PULSE_COUNTER), countPulse, CHANGE);
}

void setup() {
  Serial.setRxBufferSize(1024);
  Serial.begin(115200);
  setupPins();
  
  unsigned long now_init = millis();
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int initial_state = digitalRead(PIN_NUMBERS[i]);
    lastPinStates[i]  = initial_state;
    lastChangeTime[i] = now_init;
    candidateState[i] = initial_state;
    candidateSince[i] = now_init;
  }
  
  delay(500);
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.print("timestamp(ms)");
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    Serial.print(",");
    Serial.print(PIN_NAMES[i]);
  }
  Serial.println();
}

// ==========================================
// 6. Forward declarations of functions
// ==========================================
void executeCommand(String command);
void executeSingleCommand(String command);
void executeIfElseChain(String command);
void runColorSorterCycle();
void csHousekeeping();
void logDetectedColor();
void csDelay(unsigned long ms);
bool evaluateCondition(String condition);
bool evaluateSingleCondition(String condition);

// ==========================================
// 6.b Global variable for the Serial buffer (used in loop and inside while loops)
// ==========================================
String incomingCommand = "";

// ==========================================
// 7. Evaluate the rhs expression
// Supports: number/variable, analogRead(PIN), A * B
// Returns a float
// ==========================================
float evaluateRhs(String rhs) {
  rhs.trim();
  
  // ============ analogRead(PIN) ============
  if (rhs.startsWith("analogRead")) {
    int s = rhs.indexOf('(') + 1;
    int e = rhs.indexOf(')');
    String pinStr = rhs.substring(s, e);
    pinStr.trim();
    int pin = getPinFromName(pinStr);
    
    // oversampling: average of 16 readings to reduce ADC noise
    long adcAcc = 0;
    const int adcSamples = 16;
    for (int adcK = 0; adcK < adcSamples; adcK++) { adcAcc += analogRead(pin); }
    int raw = (int)(adcAcc / adcSamples);
    
    // There may be something after ) — for example " * VOLTAGE_FACTOR"
    String tail = rhs.substring(e + 1);
    tail.trim();
    if (tail.length() == 0) return (float)raw;
    
    if (tail.startsWith("*")) {
      String rest = tail.substring(1);
      rest.trim();
      float factor = getValueAsFloat(rest);
      return (float)raw * factor;
    }
    
    return (float)raw;
  }
  
  // ============ Multiplication expression: A * B ============
  // We ignore * if it's inside parentheses (but we don't handle that case here)
  int starPos = rhs.indexOf('*');
  if (starPos != -1) {
    String leftTok = rhs.substring(0, starPos);
    String rightTok = rhs.substring(starPos + 1);
    leftTok.trim(); rightTok.trim();
    return getValueAsFloat(leftTok) * getValueAsFloat(rightTok);
  }
  
  // ============ Simple value (variable/constant/number) ============
  return getValueAsFloat(rhs);
}

// ==========================================
// 8. The Interpreter
// ==========================================
void executeCommand(String command) {
  command.trim();
  
  while (command.length() > 0) {
    if (command.startsWith("if") || command.startsWith("while")) {
      int braceOpen = command.indexOf('{');
      if (braceOpen == -1) {
        executeSingleCommand(command);
        break;
      }
      
      int depth = 1;
      int braceClose = -1;
      for (int i = braceOpen + 1; i < (int)command.length(); i++) {
        if (command.charAt(i) == '{') depth++;
        else if (command.charAt(i) == '}') {
          depth--;
          if (depth == 0) { braceClose = i; break; }
        }
      }
      if (braceClose == -1) {
        executeSingleCommand(command);
        break;
      }
      
      // Check if there is an else after }
      int afterClose = braceClose + 1;
      while (afterClose < (int)command.length() && 
             (command.charAt(afterClose) == ' ' || command.charAt(afterClose) == '\t' ||
              command.charAt(afterClose) == '\n' || command.charAt(afterClose) == '\r')) {
        afterClose++;
      }
      
      if (afterClose + 4 <= (int)command.length() && 
          command.substring(afterClose, afterClose + 4) == "else") {
        int elseBraceOpen = command.indexOf('{', afterClose);
        if (elseBraceOpen != -1) {
          int d = 1, elseBraceClose = -1;
          for (int i = elseBraceOpen + 1; i < (int)command.length(); i++) {
            if (command.charAt(i) == '{') d++;
            else if (command.charAt(i) == '}') {
              d--;
              if (d == 0) { elseBraceClose = i; break; }
            }
          }
          if (elseBraceClose != -1) {
            // Continue searching for a chained else
            int nextAfter = elseBraceClose + 1;
            while (nextAfter < (int)command.length() && 
                   (command.charAt(nextAfter) == ' ' || command.charAt(nextAfter) == '\t' ||
                    command.charAt(nextAfter) == '\n' || command.charAt(nextAfter) == '\r')) {
              nextAfter++;
            }
            
            while (nextAfter + 4 <= (int)command.length() && 
                   command.substring(nextAfter, nextAfter + 4) == "else") {
              int nextBraceOpen = command.indexOf('{', nextAfter);
              if (nextBraceOpen == -1) break;
              int dd = 1, nextBraceClose = -1;
              for (int i = nextBraceOpen + 1; i < (int)command.length(); i++) {
                if (command.charAt(i) == '{') dd++;
                else if (command.charAt(i) == '}') {
                  dd--;
                  if (dd == 0) { nextBraceClose = i; break; }
                }
              }
              if (nextBraceClose == -1) break;
              elseBraceClose = nextBraceClose;
              nextAfter = elseBraceClose + 1;
              while (nextAfter < (int)command.length() && 
                     (command.charAt(nextAfter) == ' ' || command.charAt(nextAfter) == '\t' ||
                      command.charAt(nextAfter) == '\n' || command.charAt(nextAfter) == '\r')) {
                nextAfter++;
              }
            }
            braceClose = elseBraceClose;
          }
        }
      }
      
      String block = command.substring(0, braceClose + 1);
      executeSingleCommand(block);
      command = command.substring(braceClose + 1);
    }
    else {
      int semicolonIndex = command.indexOf(';');
      if (semicolonIndex != -1) {
        String singleCmd = command.substring(0, semicolonIndex);
        executeSingleCommand(singleCmd);
        command = command.substring(semicolonIndex + 1);
      } else {
        executeSingleCommand(command);
        break;
      }
    }
    command.trim();
  }
}

// Execute if / else if / else
void executeIfElseChain(String command) {
  command.trim();
  
  while (command.length() > 0) {
    bool isElse = false;
    bool isIf = false;
    
    if (command.startsWith("if")) {
      isIf = true;
    } else if (command.startsWith("else if")) {
      isIf = true;
    } else if (command.startsWith("else")) {
      isElse = true;
    } else {
      break;
    }
    
    if (isElse && !isIf) {
      int braceOpen = command.indexOf('{');
      if (braceOpen == -1) return;
      int depth = 1, braceClose = -1;
      for (int i = braceOpen + 1; i < (int)command.length(); i++) {
        if (command.charAt(i) == '{') depth++;
        else if (command.charAt(i) == '}') { depth--; if (depth == 0) { braceClose = i; break; } }
      }
      if (braceClose == -1) return;
      String action = command.substring(braceOpen + 1, braceClose);
      executeCommand(action);
      return;
    }
    
    int condStart = command.indexOf('(') + 1;
    int condEnd = -1;
    int pdepth = 1;
    for (int i = condStart; i < (int)command.length(); i++) {
      if (command.charAt(i) == '(') pdepth++;
      else if (command.charAt(i) == ')') { pdepth--; if (pdepth == 0) { condEnd = i; break; } }
    }
    if (condEnd == -1) return;
    String condition = command.substring(condStart, condEnd);
    
    int braceOpen = command.indexOf('{', condEnd);
    if (braceOpen == -1) return;
    int depth = 1, braceClose = -1;
    for (int i = braceOpen + 1; i < (int)command.length(); i++) {
      if (command.charAt(i) == '{') depth++;
      else if (command.charAt(i) == '}') { depth--; if (depth == 0) { braceClose = i; break; } }
    }
    if (braceClose == -1) return;
    
    if (evaluateCondition(condition)) {
      String action = command.substring(braceOpen + 1, braceClose);
      executeCommand(action);
      return;
    }
    
    command = command.substring(braceClose + 1);
    command.trim();
  }
}

void executeSingleCommand(String command) {
  command.trim();
  if (command.length() == 0) return;
  
  // ============ if / else if / else chain ============
  if (command.startsWith("if")) {
    executeIfElseChain(command);
  }
  // ============ while ============
  else if (command.startsWith("while")) {
    int condStart = command.indexOf('(') + 1;
    int condEnd = -1;
    int pdepth = 1;
    for (int i = condStart; i < (int)command.length(); i++) {
      if (command.charAt(i) == '(') pdepth++;
      else if (command.charAt(i) == ')') { pdepth--; if (pdepth == 0) { condEnd = i; break; } }
    }
    if (condEnd == -1) return;
    String condition = command.substring(condStart, condEnd);
    
    int braceOpen = command.indexOf('{', condEnd);
    if (braceOpen == -1) return;
    int depth = 1, braceClose = -1;
    for (int i = braceOpen + 1; i < (int)command.length(); i++) {
      if (command.charAt(i) == '{') depth++;
      else if (command.charAt(i) == '}') { depth--; if (depth == 0) { braceClose = i; break; } }
    }
    if (braceClose == -1) return;
    String action = command.substring(braceOpen + 1, braceClose);
    
    while (evaluateCondition(condition)) {
      executeCommand(action);
      checkPinChanges();
      printPinStates();
      
      // Check the serial for SET_T_ZERO during the while (avoid a timeout on the Bridge)
      while (Serial.available()) {
        char c = Serial.read();
        if (c == '\n') {
          incomingCommand.trim();
          if (incomingCommand == "SET_T_ZERO") {
            setTriggerFromBridge();
            Serial.println("DONE_SET_T_ZERO");
          }
          incomingCommand = "";
          break;
        } else {
          incomingCommand += c;
        }
      }
      
      delay(1);
    }
  }
  // ============ digitalWrite(PIN_OR_VAR, HIGH/LOW) ============
  else if (command.startsWith("digitalWrite")) {
    int pinStart = command.indexOf('(') + 1;
    int pinEnd = command.indexOf(',');
    String pinString = command.substring(pinStart, pinEnd);
    pinString.trim();
    
    int pin;
    // If it's a known variable, take its value as a pin number
    if (pinString == "targetValve" || pinString == "targetPulse" ||
        pinString == "voltage" || pinString == "pieceMinVoltage" ||
        pinString == "sensorValue" || pinString == "pulseCount") {
      pin = (int)getValueAsFloat(pinString);
    } else {
      pin = getPinFromName(pinString);
    }
    
    String stateStr = command.substring(pinEnd + 1, command.indexOf(')'));
    stateStr.trim();
    int state = (stateStr.equals("HIGH")) ? HIGH : LOW;
    digitalWrite(pin, state);
    checkPinChanges();
    printPinStates();
  }
  // ============ delay(N) ============
  else if (command.startsWith("delay")) {
    int delayStart = command.indexOf('(') + 1;
    int delayEnd = command.indexOf(')');
    String delayString = command.substring(delayStart, delayEnd);
    delayString.trim();
    
    int totalDelay = (int)getValueAsFloat(delayString);
    int elapsed = 0;
    while (elapsed < totalDelay) {
      int chunk = (totalDelay - elapsed > 5) ? 5 : (totalDelay - elapsed);
      delay(chunk);
      elapsed += chunk;
      checkPinChanges();
      printPinStates();
    }
  }
  // ============ LOG_COLOR (log the detected color to the sheet) ============
  else if (command == "LOG_COLOR") {
    const char* cname = "NONE";
    if      (targetValve == VALVE_WHITE) cname = "WHITE";
    else if (targetValve == VALVE_RED)   cname = "RED";
    else if (targetValve == VALVE_BLUE)  cname = "BLUE";
    unsigned long rel = esp_trigger_seen ? q10(millis() - esp_t_zero) : 0;
    int mv = (int)(pieceMinVoltage * 1000.0f);   // Voltage in mV
    Serial.print("EVT,"); Serial.print(STATION_NAME);
    Serial.print(","); Serial.print(rel);
    Serial.print(",COLOR,"); Serial.print(cname);
    Serial.print(","); Serial.println(mv);
  }
  // ============ RUN_COLOR_CYCLE (reliable native color detection cycle) ============
  else if (command == "RUN_COLOR_CYCLE") {
    runColorSorterCycle();
  }
  // ============ varName = expression ============
  else if (command.indexOf('=') > 0 &&
           command.indexOf("==") == -1 &&
           command.indexOf("!=") == -1 &&
           command.indexOf("<=") == -1 &&
           command.indexOf(">=") == -1) {
    int eqPos = command.indexOf('=');
    String varName = command.substring(0, eqPos);
    String rhs = command.substring(eqPos + 1);
    varName.trim();
    rhs.trim();
    
    float value = evaluateRhs(rhs);
    setVariableValue(varName, value);
  }
}

// ==========================================
// 9. Evaluate conditions
// ==========================================
bool evaluateSingleCondition(String condition) {
  condition.trim();
  
  // ============ digitalRead(PIN) ==/!= HIGH/LOW ============
  if (condition.indexOf("digitalRead") != -1) {
    bool notEqual = (condition.indexOf("!=") != -1);
    int opPos = notEqual ? condition.indexOf("!=") : condition.indexOf("==");
    if (opPos == -1) return false;
    
    String leftPart = condition.substring(0, opPos);
    String rightPart = condition.substring(opPos + 2);
    int readStart = leftPart.indexOf("digitalRead(") + 12;
    int readEnd = leftPart.indexOf(')', readStart);
    String pinStr = leftPart.substring(readStart, readEnd);
    int pin = getPinFromName(pinStr);
    
    rightPart.trim();
    int expectedState = (rightPart.equals("HIGH")) ? HIGH : LOW;
    int actualState = digitalRead(pin);
    
    return notEqual ? (actualState != expectedState) : (actualState == expectedState);
  }
  
  // ============ Comparisons on variables/constants/numbers ============
  // We use an enum instead of String to avoid any String comparison issues
  enum CompOp { OP_LE, OP_GE, OP_EQ, OP_NE, OP_LT, OP_GT, OP_NONE };
  
  CompOp op = OP_NONE;
  int pos = -1;
  int opLen = 0;
  
  // Order matters: we check <= and >= before < and > and == and !=
  pos = condition.indexOf("<=");
  if (pos != -1) { op = OP_LE; opLen = 2; }
  else {
    pos = condition.indexOf(">=");
    if (pos != -1) { op = OP_GE; opLen = 2; }
    else {
      pos = condition.indexOf("==");
      if (pos != -1) { op = OP_EQ; opLen = 2; }
      else {
        pos = condition.indexOf("!=");
        if (pos != -1) { op = OP_NE; opLen = 2; }
        else {
          pos = condition.indexOf('<');
          if (pos != -1) { op = OP_LT; opLen = 1; }
          else {
            pos = condition.indexOf('>');
            if (pos != -1) { op = OP_GT; opLen = 1; }
          }
        }
      }
    }
  }
  
  if (op == OP_NONE) return false;
  
  String lhs = condition.substring(0, pos);
  String rhs = condition.substring(pos + opLen);
  lhs.trim();
  rhs.trim();
  
  float lhsVal = getValueAsFloat(lhs);
  float rhsVal = getValueAsFloat(rhs);
  
  switch (op) {
    case OP_LE: return (lhsVal <= rhsVal);
    case OP_GE: return (lhsVal >= rhsVal);
    case OP_EQ: return (lhsVal == rhsVal);
    case OP_NE: return (lhsVal != rhsVal);
    case OP_LT: return (lhsVal <  rhsVal);
    case OP_GT: return (lhsVal >  rhsVal);
    default:    return false;
  }
}

// Evaluate a full condition (supports &&)
bool evaluateCondition(String condition) {
  condition.trim();
  
  // Remove the outer parentheses if they wrap the entire expression
  while (condition.startsWith("(") && condition.endsWith(")")) {
    int d = 0;
    bool wraps = true;
    for (int i = 0; i < (int)condition.length(); i++) {
      if (condition.charAt(i) == '(') d++;
      else if (condition.charAt(i) == ')') {
        d--;
        if (d == 0 && i < (int)condition.length() - 1) { wraps = false; break; }
      }
    }
    if (!wraps) break;
    condition = condition.substring(1, condition.length() - 1);
    condition.trim();
  }
  
  // && (Short-circuit: evaluate the left side first, if false don't evaluate the right side)
  int andPos = condition.indexOf("&&");
  if (andPos != -1) {
    String left = condition.substring(0, andPos);
    String right = condition.substring(andPos + 2);
    if (!evaluateCondition(left)) return false;
    return evaluateCondition(right);
  }
  
  return evaluateSingleCondition(condition);
}

// ==========================================
// 10. Main loop (Loop)
// ==========================================
// (incomingCommand defined in section 6.b)

void loop() {
  checkPinChanges();
  printPinStates();
  
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      String commandData = incomingCommand;
      incomingCommand = "";
      commandData.trim();
      if (commandData.length() > 0) {
        if (commandData == "SET_T_ZERO") {
          setTriggerFromBridge();
          Serial.println("DONE_SET_T_ZERO");
        } else {
          executeCommand(commandData);
          Serial.println("DONE");
        }
      }
      break;
    } else {
      incomingCommand += c;
    }
  }
}

// ==========================================
// Native color detection cycle — copied verbatim from the separate code that works accurately
// Runs without the interpreter to ensure many clean samples -> a reliable color
// ==========================================

// delay while pumping the logger (debounce + periodic update) — so short pulses get logged
void csDelay(unsigned long ms) {
  unsigned long start = millis();
  while (millis() - start < ms) {
    checkPinChanges();
    printPinStates();
    delay(1);
  }
}

// housekeeping during wait loops: logging the pins + responding to SET_T_ZERO
void csHousekeeping() {
  checkPinChanges();
  printPinStates();
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      incomingCommand.trim();
      if (incomingCommand == "SET_T_ZERO") {
        setTriggerFromBridge();
        Serial.println("DONE_SET_T_ZERO");
      }
      incomingCommand = "";
      break;
    } else {
      incomingCommand += c;
    }
  }
}

// Log the detected color to the sheet (same format as LOG_COLOR)
void logDetectedColor() {
  const char* cname = "NONE";
  if      (targetValve == VALVE_WHITE) cname = "WHITE";
  else if (targetValve == VALVE_RED)   cname = "RED";
  else if (targetValve == VALVE_BLUE)  cname = "BLUE";
  unsigned long rel = esp_trigger_seen ? q10(millis() - esp_t_zero) : 0;
  unsigned long durq = q10(colorMeasDur);   // The time consumed by the measurement (ms), like the other stations
  Serial.print("EVT,"); Serial.print(STATION_NAME);
  Serial.print(","); Serial.print(rel);
  Serial.print(",COLOR,"); Serial.print(cname);
  Serial.print(","); Serial.println(durq);
}

void runColorSorterCycle() {
  // Reset
  pieceMinVoltage = 3.3f;
  targetPulse = 0;
  targetValve = -1;
  voltage = 0.0f;
  sensorValue = 0;

  // 1) Wait for the piece at SENSOR_BEFORE
  while (digitalRead(SENSOR_BEFORE) == HIGH) {
    csHousekeeping();
    delay(10);
  }

  // 2) Run the belt and read the color while passing through
  digitalWrite(BELT_MOTOR, HIGH);
  checkPinChanges(); printPinStates();

  unsigned long measStart = millis();   // Start of the measurement
  while (digitalRead(SENSOR_AFTER) == HIGH) {
    sensorValue = analogRead(COLOR_SENSOR);
    voltage = sensorValue * VOLTAGE_FACTOR;
    if (voltage > 0.05f && voltage < pieceMinVoltage) {
      pieceMinVoltage = voltage;
    }
    csHousekeeping();
    delay(10);
  }

  colorMeasDur = millis() - measStart;   // Duration of the measurement
  digitalWrite(BELT_MOTOR, LOW);
  checkPinChanges(); printPinStates();

  // 3) Analyze the color
  if (pieceMinVoltage > THRESHOLD_BLUE_RED) {
    targetPulse = 480; targetValve = VALVE_BLUE;
  } else if (pieceMinVoltage > THRESHOLD_RED_WHITE) {
    targetPulse = 280; targetValve = VALVE_RED;
  } else if (pieceMinVoltage > THRESHOLD_WHITE_MIN) {
    targetPulse = 110; targetValve = VALVE_WHITE;
  }

  // Log the color to the sheet
  logDetectedColor();

  // 4) Sort the piece
  if (targetValve != -1) {
    pulseCount = 0;
    digitalWrite(BELT_MOTOR, HIGH);
    while (pulseCount <= (unsigned int)targetPulse) {
      csHousekeeping();
      delay(1);
    }
    digitalWrite(BELT_MOTOR, LOW);

    digitalWrite(COMPRESSOR, HIGH);
    digitalWrite(targetValve, HIGH);
    csDelay(200);   // Pumps the logger while the valve is open -> the pulse gets logged in all three files
    digitalWrite(targetValve, LOW);
    digitalWrite(COMPRESSOR, LOW);
    checkPinChanges(); printPinStates();   // Logs the moment of closing
  }

  // 5) Reset in preparation for the next piece
  pieceMinVoltage = 3.3f;
  targetPulse = 0;
  targetValve = -1;
  voltage = 0.0f;
  csDelay(500);   // Pump the logger so the bridge/sender log the valve closing at the correct time
}
