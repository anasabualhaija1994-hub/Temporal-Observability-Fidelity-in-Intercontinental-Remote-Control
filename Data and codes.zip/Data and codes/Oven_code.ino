#include <Arduino.h>

// ===================================

// 0. Name of this station
// ==========================================
#define STATION_NAME "Oven"

// ==========================================
// 1. Pin Definitions
// ==========================================
#define RS_Table_vacum_position 36
#define RS_Table_belt_position  39
#define Belt_Light_Bar          34
#define RS_Table_Saw_position   35
#define RS_Vacum_Table_position 32
#define RS_Vacum_Oven_position  33
#define Oven_Light_Bar          25

#define Move_Table_TO_belt      23
#define Move_Table_TO_Vacuum    22
#define Belt_Motor              21
#define Saw_Motor               19
#define Move_Vacuum_To_OvenPin  18
#define Move_Vacuum_To_TablePin 17
#define Oven_Light              16
#define Compressor               4
#define Gripper                  2
#define Vacuum_Valve            14
#define Oven_DoorPin            12
#define Table_Valve             13
#define RS_Oven_Feed_In          5
#define RS_Oven_Feed_Out        15
#define Move_Oven_inside        26
#define Move_Oven_outside       27

// ==========================================
// 1.b Periodic Logger variables (every 20ms)
// ==========================================
unsigned long lastLogTime = 0;
const unsigned long LOG_INTERVAL_MS = 20;

// ==========================================
// 1.c Event Logger variables (for precise measurement on the ESP32)
// ==========================================
const int NUM_TRACKED_PINS = 23;

const char* PIN_NAMES[NUM_TRACKED_PINS] = {
  "RS_Table_vacum_position",
  "RS_Table_belt_position",
  "Belt_Light_Bar",
  "RS_Table_Saw_position",
  "RS_Vacum_Table_position",
  "RS_Vacum_Oven_position",
  "Oven_Light_Bar",
  "RS_Oven_Feed_In",
  "RS_Oven_Feed_Out",
  "Move_Table_TO_belt",
  "Move_Table_TO_Vacuum",
  "Belt_Motor",
  "Saw_Motor",
  "Move_Vacuum_To_OvenPin",
  "Move_Vacuum_To_TablePin",
  "Oven_Light",
  "Compressor",
  "Gripper",
  "Vacuum_Valve",
  "Oven_DoorPin",
  "Table_Valve",
  "Move_Oven_inside",
  "Move_Oven_outside"
};

const int PIN_NUMBERS[NUM_TRACKED_PINS] = {
  RS_Table_vacum_position,
  RS_Table_belt_position,
  Belt_Light_Bar,
  RS_Table_Saw_position,
  RS_Vacum_Table_position,
  RS_Vacum_Oven_position,
  Oven_Light_Bar,
  RS_Oven_Feed_In,
  RS_Oven_Feed_Out,
  Move_Table_TO_belt,
  Move_Table_TO_Vacuum,
  Belt_Motor,
  Saw_Motor,
  Move_Vacuum_To_OvenPin,
  Move_Vacuum_To_TablePin,
  Oven_Light,
  Compressor,
  Gripper,
  Vacuum_Valve,
  Oven_DoorPin,
  Table_Valve,
  Move_Oven_inside,
  Move_Oven_outside
};

// Last known state for each pin
int lastPinStates[NUM_TRACKED_PINS];

// Last change time for each pin (in milliseconds)
unsigned long lastChangeTime[NUM_TRACKED_PINS];

// Debouncing variables
int candidateState[NUM_TRACKED_PINS];
unsigned long candidateSince[NUM_TRACKED_PINS];
const unsigned long DEBOUNCE_MS = 5;

// The trigger flag and t=0 (comes from the Bridge via SET_T_ZERO)
bool esp_trigger_seen = false;
unsigned long esp_t_zero = 0;

const unsigned long EVT_MIN_DURATION_MS = 20;

// ==========================================
// 1.c.1 Function to round to the nearest 10ms
// ==========================================
unsigned long q10(unsigned long x) {
  return ((x + 5) / 10) * 10;
}

// ==========================================
// 1.d Function to print periodic Pin states (every 20ms)
// Format: Station,timestamp,p1,p2,...
// ==========================================
void printPinStates() {
  unsigned long now = millis();
  if (now - lastLogTime < LOG_INTERVAL_MS) return;
  lastLogTime = now;
  
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.print(now);
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    Serial.print(","); Serial.print(digitalRead(PIN_NUMBERS[i]));
  }
  Serial.println();
}

// ==========================================
// 1.e Function to check Pin changes and print EVT for precise measurement
// ==========================================
void checkPinChanges() {
  unsigned long now = millis();
  
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int cur = digitalRead(PIN_NUMBERS[i]);
    
    if (cur == lastPinStates[i]) {
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;
    }
    
    if (cur != candidateState[i]) {
      candidateState[i] = cur;
      candidateSince[i] = now;
      continue;
    }
    
    if (now - candidateSince[i] < DEBOUNCE_MS) {
      continue;
    }
    
    // Confirmed real change
    unsigned long change_time = candidateSince[i];
    
    if (!esp_trigger_seen) {
      lastPinStates[i] = cur;
      lastChangeTime[i] = change_time;
      continue;
    }
    
    unsigned long duration = change_time - lastChangeTime[i];
    
    if (duration > EVT_MIN_DURATION_MS) {
      unsigned long rel_time = change_time - esp_t_zero;
      // Format: EVT,Station,RelativeTime,Pin,NewState,Duration
      Serial.print("EVT,");
      Serial.print(STATION_NAME);
      Serial.print(",");
      Serial.print(q10(rel_time));
      Serial.print(",");
      Serial.print(PIN_NAMES[i]);
      Serial.print(",");
      Serial.print(cur);
      Serial.print(",");
      Serial.println(q10(duration));
    }
    
    lastPinStates[i] = cur;
    lastChangeTime[i] = change_time;
  }
}

// ==========================================
// 1.f Function to set t_zero via a command from the Bridge
// ==========================================
void setTriggerFromBridge() {
  if (esp_trigger_seen) return;
  
  unsigned long now = millis();
  esp_t_zero = now;
  esp_trigger_seen = true;
  
  for (int j = 0; j < NUM_TRACKED_PINS; j++) {
    lastChangeTime[j] = esp_t_zero;
    lastPinStates[j] = digitalRead(PIN_NUMBERS[j]);
    candidateState[j] = lastPinStates[j];
    candidateSince[j] = esp_t_zero;
  }
  
  Serial.print("EVT,");
  Serial.print(STATION_NAME);
  Serial.print(",0,SYSTEM_TRIGGER,1,0");
  Serial.println();
}

// ==========================================
// 2. Function to translate names into port numbers
// ==========================================
int getPinFromName(String pinName) {
  pinName.trim();
  // Input sensors
  if (pinName == "RS_Table_vacum_position") return 36;
  if (pinName == "RS_Table_belt_position")  return 39;
  if (pinName == "Belt_Light_Bar")          return 34;
  if (pinName == "RS_Table_Saw_position")   return 35;
  if (pinName == "RS_Vacum_Table_position") return 32;
  if (pinName == "RS_Vacum_Oven_position")  return 33;
  if (pinName == "Oven_Light_Bar")          return 25;
  if (pinName == "RS_Oven_Feed_In")         return 5;
  if (pinName == "RS_Oven_Feed_Out")        return 15;
  // Motors and valves
  if (pinName == "Move_Table_TO_belt")      return 23;
  if (pinName == "Move_Table_TO_Vacuum")    return 22;
  if (pinName == "Belt_Motor")              return 21;
  if (pinName == "Saw_Motor")               return 19;
  if (pinName == "Move_Vacuum_To_OvenPin")  return 18;
  if (pinName == "Move_Vacuum_To_TablePin") return 17;
  if (pinName == "Oven_Light")              return 16;
  if (pinName == "Compressor")              return 4;
  if (pinName == "Gripper")                 return 2;
  if (pinName == "Vacuum_Valve")            return 14;
  if (pinName == "Oven_DoorPin")            return 12;
  if (pinName == "Table_Valve")             return 13;
  if (pinName == "Move_Oven_inside")        return 26;
  if (pinName == "Move_Oven_outside")       return 27;
  
  return pinName.toInt();
}

// ==========================================
// 3. Setup
// ==========================================
void setupPins() {
  // Set up the input sensors
  pinMode(RS_Table_vacum_position, INPUT);
  pinMode(RS_Table_belt_position, INPUT);
  pinMode(Belt_Light_Bar, INPUT);
  pinMode(RS_Table_Saw_position, INPUT);
  pinMode(RS_Vacum_Table_position, INPUT);
  pinMode(RS_Vacum_Oven_position, INPUT);
  pinMode(Oven_Light_Bar, INPUT);
  pinMode(RS_Oven_Feed_In, INPUT);
  pinMode(RS_Oven_Feed_Out, INPUT);

  // Set up the motors and valves as outputs
  pinMode(Move_Table_TO_belt, OUTPUT);
  pinMode(Move_Table_TO_Vacuum, OUTPUT);
  pinMode(Belt_Motor, OUTPUT);
  pinMode(Saw_Motor, OUTPUT);
  pinMode(Move_Vacuum_To_OvenPin, OUTPUT);
  pinMode(Move_Vacuum_To_TablePin, OUTPUT);
  pinMode(Oven_Light, OUTPUT);
  pinMode(Compressor, OUTPUT);
  pinMode(Gripper, OUTPUT);
  pinMode(Vacuum_Valve, OUTPUT);
  pinMode(Oven_DoorPin, OUTPUT);
  pinMode(Table_Valve, OUTPUT);
  pinMode(Move_Oven_inside, OUTPUT);
  pinMode(Move_Oven_outside, OUTPUT);

  // Turn everything off as a starting state
  digitalWrite(Move_Table_TO_belt, LOW);
  digitalWrite(Move_Table_TO_Vacuum, LOW);
  digitalWrite(Belt_Motor, LOW);
  digitalWrite(Saw_Motor, LOW);
  digitalWrite(Move_Vacuum_To_OvenPin, LOW);
  digitalWrite(Move_Vacuum_To_TablePin, LOW);
  digitalWrite(Oven_Light, LOW);
  digitalWrite(Compressor, LOW);
  digitalWrite(Gripper, HIGH); // The default position for the Gripper is up
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Table_Valve, LOW);
  digitalWrite(Move_Oven_inside, LOW);
  digitalWrite(Move_Oven_outside, LOW);
}

void setup() {
  Serial.setRxBufferSize(1024);
  Serial.begin(115200);
  setupPins();
  
  // Initialize the last known state for each pin + debouncing variables
  unsigned long now_init = millis();
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    int initial_state = digitalRead(PIN_NUMBERS[i]);
    lastPinStates[i]  = initial_state;
    lastChangeTime[i] = now_init;
    candidateState[i] = initial_state;
    candidateSince[i] = now_init;
  }
  
  // Print the Header once
  delay(500);
  Serial.print(STATION_NAME); Serial.print(",");
  Serial.print("timestamp(ms)");
  for (int i = 0; i < NUM_TRACKED_PINS; i++) {
    Serial.print(",");
    Serial.print(PIN_NAMES[i]);
  }
  Serial.println();
}

// ==========================================
// 4. Forward declarations of functions
// ==========================================
void executeCommand(String command);
void executeSingleCommand(String command);
bool evaluateCondition(String condition);

// ==========================================
// 4.b Global variable for the Serial buffer (used in loop and inside while loops)
// ==========================================
String incomingCommand = "";

// ==========================================
// 5. Smart execution functions
// ==========================================
void executeCommand(String command) {
  command.trim();
  
  while (command.length() > 0) {
    if (command.startsWith("if") || command.startsWith("while")) {
      int closeBrace = command.indexOf('}');
      if (closeBrace != -1) {
        String block = command.substring(0, closeBrace + 1);
        executeSingleCommand(block);
        command = command.substring(closeBrace + 1);
      } else {
        executeSingleCommand(command);
        break;
      }
    }
    else {
      int semicolonIndex = command.indexOf(';');
      if (semicolonIndex != -1) {
        String singleCmd = command.substring(0, semicolonIndex);
        executeSingleCommand(singleCmd);
        command = command.substring(semicolonIndex + 1);
      } else {
        executeSingleCommand(command);
        break;
      }
    }
    command.trim();
  }
}

void executeSingleCommand(String command) {
  command.trim();
  
  if (command.startsWith("if")) {
    int conditionStart = command.indexOf('(') + 1; int conditionEnd = command.indexOf(')');
    String condition = command.substring(conditionStart, conditionEnd); condition.trim();
    int actionStart = command.indexOf('{') + 1; int actionEnd = command.lastIndexOf('}');
    String action = command.substring(actionStart, actionEnd); action.trim();
    if (evaluateCondition(condition)) { executeCommand(action); }
  }
  else if (command.startsWith("while")) {
    int conditionStart = command.indexOf('(') + 1;
    int conditionEnd = command.indexOf(')', conditionStart);
    if (command.substring(conditionStart, conditionEnd).indexOf("digitalRead") != -1) {
      conditionEnd = command.indexOf(')', conditionEnd + 1);
    }
    String condition = command.substring(conditionStart, conditionEnd); condition.trim();
    int actionStart = command.indexOf('{') + 1; int actionEnd = command.lastIndexOf('}');
    String action = command.substring(actionStart, actionEnd); action.trim();
    
    while (evaluateCondition(condition)) {
      executeCommand(action);
      checkPinChanges();  // ← precise monitoring of pin changes
      printPinStates();   // ← the periodic print every 20ms
      
      // Check the serial for SET_T_ZERO during the while (avoid a timeout on the Bridge)
      // ⚠️ We don't read normal execution commands here — only SET_T_ZERO
      while (Serial.available()) {
        char c = Serial.read();
        if (c == '\n') {
          incomingCommand.trim();
          if (incomingCommand == "SET_T_ZERO") {
            setTriggerFromBridge();
            Serial.println("DONE_SET_T_ZERO");
          }
          incomingCommand = "";
          break;
        } else {
          incomingCommand += c;
        }
      }
      
      delay(1);
    }
  }
  else if (command.startsWith("digitalWrite")) {
    int pinStart = command.indexOf('(') + 1; int pinEnd = command.indexOf(',');
    String pinString = command.substring(pinStart, pinEnd); pinString.trim();
    int pin = getPinFromName(pinString);
    String stateStr = command.substring(pinEnd + 1, command.indexOf(')')); stateStr.trim();
    int state = (stateStr.equals("HIGH")) ? HIGH : LOW;
    digitalWrite(pin, state);
    checkPinChanges();  // ← detect the change immediately
    printPinStates();   // ← the periodic print every 20ms
  }
  else if (command.startsWith("delay")) {
    int delayStart = command.indexOf('(') + 1; int delayEnd = command.indexOf(')');
    String delayString = command.substring(delayStart, delayEnd); delayString.trim();
    
    // Split the delay into small chunks to monitor the pins during it
    int totalDelay = delayString.toInt();
    int elapsed = 0;
    while (elapsed < totalDelay) {
      int chunk = (totalDelay - elapsed > 5) ? 5 : (totalDelay - elapsed);
      delay(chunk);
      elapsed += chunk;
      checkPinChanges();
      printPinStates();
    }
  }
  // ⚠️ The Oven has no variables (encoders) — only digitalWrite/while/delay
}

bool evaluateCondition(String condition) {
  condition.trim();

  if (condition.indexOf("digitalRead") != -1) {
    bool notEqual = (condition.indexOf("!=") != -1);
    int opPos = notEqual ? condition.indexOf("!=") : condition.indexOf("==");
    if (opPos == -1) return false;
    
    String leftPart = condition.substring(0, opPos);
    String rightPart = condition.substring(opPos + 2);
    int readStart = leftPart.indexOf("digitalRead(") + 12;
    int readEnd = leftPart.indexOf(')', readStart);
    String pinStr = leftPart.substring(readStart, readEnd);
    int pin = getPinFromName(pinStr);
    
    rightPart.trim();
    int expectedState = (rightPart.equals("HIGH")) ? HIGH : LOW;
    int actualState = digitalRead(pin);
    
    if (notEqual) return (actualState != expectedState);
    else return (actualState == expectedState);
  }
  
  return false;
}

// ==========================================
// 6. Main loop (Loop)
// ==========================================
// (incomingCommand defined in section 4.b)

void loop() {
  // Monitor the pins the instant they actually change
  checkPinChanges();
  
  // The periodic print every 20ms
  printPinStates();
  
  // Non-blocking serial read: read all available chars at once
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      // Command complete
      String commandData = incomingCommand;
      incomingCommand = "";
      commandData.trim();
      if (commandData.length() > 0) {
        // ============ Special command: SET_T_ZERO from the Bridge ============
        if (commandData == "SET_T_ZERO") {
          setTriggerFromBridge();
          Serial.println("DONE_SET_T_ZERO");
        } else {
          executeCommand(commandData);
          Serial.println("DONE"); // Acknowledgment for the second laptop
        }
      }
      break;  // Exit so checkPinChanges runs
    } else {
      incomingCommand += c;
    }
  }
}
