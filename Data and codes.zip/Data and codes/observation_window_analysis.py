import argparse, glob, os
import numpy as np
import pandas as pd
from scipy import stats

EXCLUDED_PINS   = {"SYSTEM_TRIGGER", "COLOR"}
MATCH_WINDOW_MS = 200.0
N_RUNS          = 11
QUANT_MS        = 10.0    # logging quantisation applied at every vantage point
BROADCAST_MS    = 20.0    # controller periodic state-broadcast period (50 Hz)


# ------------------------------------------------------------------------- I/O
def resolve(data_dir, filename):
    direct = os.path.join(data_dir, filename)
    if os.path.exists(direct):
        return direct
    hits = sorted(glob.glob(os.path.join(data_dir, "*", filename)))
    if hits:
        return hits[0]
    raise FileNotFoundError(f"{filename} not found under {data_dir}")


def load_pin_log(path):
    d = pd.read_csv(path)
    d.columns = [c.strip() for c in d.columns]
    d["Station"] = d["Station"].astype(str).str.strip()
    d["Pin"]     = d["Pin"].astype(str).str.strip()
    d = d[~d["Pin"].isin(EXCLUDED_PINS)].reset_index(drop=True)
    d["RelativeTime(ms)"] = d["RelativeTime(ms)"].astype(float)
    d["NewState"]    = d["NewState"].astype(str).str.extract(r"(-?\d+)").astype(int)
    d["Duration(ms)"] = d["Duration(ms)"].astype(float)
    return d


# -------------------------------------------------------------- offset / match
def estimate_run_offset(gt_g, ds_g):
    diffs = []
    for key, g in gt_g:
        if key not in ds_g.groups:
            continue
        a = g["RelativeTime(ms)"].values
        b = ds_g.get_group(key)["RelativeTime(ms)"].values
        n = min(len(a), len(b))
        diffs.extend(b[:n] - a[:n])
    return float(np.median(diffs)) if diffs else 0.0


def match_channel(gt_t, gt_d, ds_t, ds_d, window=MATCH_WINDOW_MS):
    used, out = np.zeros(len(ds_t), bool), []
    for i in range(len(gt_t)):
        best_j, best_dt = -1, window + 1.0
        for j in range(len(ds_t)):
            if used[j]:
                continue
            dt = abs(ds_t[j] - gt_t[i])
            if dt < best_dt:
                best_dt, best_j = dt, j
        if best_j >= 0:
            used[best_j] = True
            out.append((i, ds_t[best_j] - gt_t[i], ds_d[best_j] - gt_d[i]))
    return out


def event_table(dd, tag):
    """Per-matched-event table: onset residual, duration distortion, covariates."""
    rows = []
    for i in range(1, N_RUNS + 1):
        gt = load_pin_log(resolve(dd, f"esp32_pin_log_{i}.csv"))
        ds = load_pin_log(resolve(dd, f"{tag}_pin_log_{i}.csv"))
        gt_g = gt.groupby(["Station", "Pin", "NewState"])
        ds_g = ds.groupby(["Station", "Pin", "NewState"])
        off  = estimate_run_offset(gt_g, ds_g)

        t_all = np.sort(gt["RelativeTime(ms)"].values)
        st_sorted = gt.sort_values("RelativeTime(ms)")

        for key, g in gt_g:
            gt_t, gt_d = g["RelativeTime(ms)"].values, g["Duration(ms)"].values
            if key in ds_g.groups:
                dsub  = ds_g.get_group(key)
                ds_t  = dsub["RelativeTime(ms)"].values - off
                ds_d  = dsub["Duration(ms)"].values
            else:
                ds_t = ds_d = np.array([])
            for idx, onres, ddiff in match_channel(gt_t, gt_d, ds_t, ds_d):
                rows.append(dict(run=i, station=key[0], pin=key[1], state=key[2],
                                 t_gt=gt_t[idx], dur_gt=gt_d[idx],
                                 dur_diff=ddiff, onset_resid=onres))
        # instantaneous load covariates (+/- 500 ms window around each event)
        sub = pd.DataFrame(rows[-0:]) if False else None
    df = pd.DataFrame(rows)
    # add load covariates run by run
    out = []
    for i, g in df.groupby("run"):
        gt = load_pin_log(resolve(dd, f"esp32_pin_log_{i}.csv"))
        t  = np.sort(gt["RelativeTime(ms)"].values)
        st = gt.sort_values("RelativeTime(ms)")
        lo = np.searchsorted(t, g.t_gt.values - 500, "left")
        hi = np.searchsorted(t, g.t_gt.values + 500, "right")
        gg = g.copy()
        gg["rate"]      = hi - lo
        gg["nstations"] = [st.iloc[a:b].Station.nunique() for a, b in zip(lo, hi)]
        out.append(gg)
    return pd.concat(out).reset_index(drop=True)


# --------------------------------------------------------- observation-window model
def q(x):
    return np.round(x / QUANT_MS) * QUANT_MS


def simulate(T, rho=0.0, n=3_000_000, seed=0):
    """Forward model: uniform observation window of width T on onset and offset,
    then the same 10 ms logging quantisation the real logs carry."""
    rng  = np.random.default_rng(seed)
    ton  = rng.uniform(0, QUANT_MS, n)          # random phase w.r.t. the 10 ms grid
    toff = rng.uniform(0, QUANT_MS, n)
    if rho == 0.0:
        uon, uoff = rng.uniform(0, T, n), rng.uniform(0, T, n)
    else:                                        # Gaussian copula for correlated errors
        z1 = rng.standard_normal(n)
        z2 = rho * z1 + np.sqrt(1 - rho ** 2) * rng.standard_normal(n)
        uon, uoff = stats.norm.cdf(z1) * T, stats.norm.cdf(z2) * T
    onset = q(ton + uon) - q(ton)
    dur   = (q(toff + uoff) - q(ton + uon)) - (q(toff) - q(ton))
    return onset - np.median(onset), dur


def calibrate_T(target_sd, seed):
    """Estimate T_eff from the onset-residual SD alone (no duration data used)."""
    lo, hi = 1.0, 400.0
    for _ in range(35):
        mid = (lo + hi) / 2
        r, _ = simulate(mid, 0.0, 400_000, seed)
        if r.std(ddof=1) < target_sd:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def bands(x):
    a = np.abs(x)
    return (np.median(a), 100 * (a <= 10).mean(), 100 * (a <= 20).mean(),
            100 * (a <= 50).mean(), 100 * (a > 100).mean(), np.percentile(a, 95))


# ----------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    dd, SEED = a.data_dir, a.seed

    print("=" * 78)
    print("OBSERVATION-WINDOW ANALYSIS   (seed = %d)" % SEED)
    print("=" * 78)

    B = event_table(dd, "bridge")
    S = event_table(dd, "sender")

    # ---------------------------------------------------------------- [A]
    print("\n[A] Arrival-burst structure  (Sec. 4.8)")
    for tag in ("bridge", "sender"):
        modes = []
        for i in range(1, N_RUNS + 1):
            d = load_pin_log(resolve(dd, f"{tag}_pin_log_{i}.csv"))
            g = np.diff(np.unique(d["RelativeTime(ms)"].values))
            modes.append(pd.Series(g[g <= 400]).mode().iloc[0])
        m = pd.Series(modes).mode().iloc[0]
        print("    %-7s modal inter-arrival gap = %.0f ms in %d/11 runs  (all values %s)"
              % (tag, m, int((np.array(modes) == m).sum()), sorted(set(modes))))
    per = []
    for i in range(1, N_RUNS + 1):
        d = load_pin_log(resolve(dd, f"sender_pin_log_{i}.csv"))
        g = np.diff(np.unique(d["RelativeTime(ms)"].values))
        per.append(np.median(g[(g >= 100) & (g <= 250)]))
    rtt_all = np.concatenate([pd.read_csv(resolve(dd, f"network_ping_log_{i}.csv"))["RTT_ms"].values
                              for i in range(1, N_RUNS + 1)])
    print("    sender burst period (median of 100-250 ms gaps) = %.0f ms in all 11 runs"
          % np.mean(per))
    print("    burst period / mean ping RTT (%.2f ms) = %.2f" % (rtt_all.mean(), np.mean(per) / rtt_all.mean()))

    # ---------------------------------------------------------------- [B][C]
    print("\n[B] Effective observation window T_eff  (calibrated on onset residuals ONLY)")
    T = {}
    for nm, d in (("bridge", B), ("sender", S)):
        T[nm] = calibrate_T(d.onset_resid.std(ddof=1), SEED)
    print("    T_eff(bridge) = %.1f ms ;  T_eff(sender) = %.1f ms ;  ratio = %.2f"
          % (T["bridge"], T["sender"], T["sender"] / T["bridge"]))
    prT = np.array([S[S.run == i].onset_resid.std(ddof=1) * np.sqrt(12) for i in range(1, N_RUNS + 1)])
    print("    per-run sender T_eff = %.1f +/- %.1f ms (range %.1f-%.1f)"
          % (prT.mean(), prT.std(ddof=1), prT.min(), prT.max()))

    print("\n[C] Out-of-sample model test  (NOTHING fitted to duration data)")
    for nm, d in (("bridge", B), ("sender", S)):
        on_m, du_m = simulate(T[nm], 0.0, 3_000_000, SEED + 77)
        mo, po = np.abs(d.onset_resid.values), np.abs(on_m)
        print("    %-7s onset  : median %.0f/%.0f ms, p95 %.0f/%.0f ms   (measured/model)"
              % (nm, np.median(mo), np.median(po), np.percentile(mo, 95), np.percentile(po, 95)))
        me, mo_ = bands(d.dur_diff.values), bands(du_m)
        print("    %-7s duration: median %.0f/%.0f | <=10ms %.1f/%.1f%% | <=20ms %.1f/%.1f%% "
              "| <=50ms %.1f/%.1f%% | >100ms %.2f/%.2f%%"
              % (nm, me[0], mo_[0], me[1], mo_[1], me[2], mo_[2], me[3], mo_[3], me[4], mo_[4]))
    tgt = 100 * (np.abs(B.dur_diff.values) <= 10).mean()
    best = min(((r, abs(100 * (np.abs(simulate(T["bridge"], r, 800_000, SEED + 9)[1]) <= 10).mean() - tgt))
                for r in np.arange(0.0, 0.95, 0.05)), key=lambda z: z[1])
    print("    bridge onset/offset error correlation reproducing the measured spread: rho = %.2f"
          % best[0])

    # ---------------------------------------------------------------- [D]
    Ts = T["sender"]
    print("\n[D] Closed form  P(|dD|<=a) = 1-(1-a/T_eff)^2   (Eq. 2), T_eff = %.1f ms" % Ts)
    print("    median|dD| = 0.293*T_eff = %.1f ms" % (0.29289 * Ts))
    for x in (10, 20, 50, 100):
        print("      P(|dD| <= %3d ms) = %5.1f%%" % (x, 100 * (1 - (1 - x / Ts) ** 2)))
    print("    design inversion  T_eff <= a/(1-sqrt(1-p))   (Eq. 3)")
    for x in (10, 50, 100):
        for p in (0.95, 0.99):
            print("      +/-%3d ms at %2.0f%% of events  ->  T_eff <= %6.1f ms"
                  % (x, 100 * p, x / (1 - np.sqrt(1 - p))))
    print("    at T_eff = %.0f ms (broadcast period): median|dD| = %.1f ms"
          % (BROADCAST_MS, 0.29289 * BROADCAST_MS))

    # ---------------------------------------------------------------- [E]
    print("\n[E] Clock-rate drift  (model predicts additive, not proportional, distortion)")
    rng = np.random.default_rng(SEED)
    for nm, d in (("bridge", B), ("sender", S)):
        qd  = pd.qcut(d.dur_gt, 10, duplicates="drop")
        med = d.groupby(qd, observed=True).dur_diff.median().values
        D   = d.groupby(qd, observed=True).dur_gt.median().values
        idx = rng.choice(len(d), 3000, replace=False)
        ts  = stats.theilslopes(d.dur_diff.values[idx], d.dur_gt.values[idx], 0.95)
        print("    %-7s decile medians (D from %.0f ms to %.1f s): %s"
              % (nm, D.min(), D.max() / 1000, med.astype(int).tolist()))
        print("            Theil-Sen slope = %.2f ppm  (95%% CI %.2f - %.2f ppm)"
              % (ts[0] * 1e6, ts[2] * 1e6, ts[3] * 1e6))

    # ---------------------------------------------------------------- [F]
    print("\n[F] Far-tail attribution  (|dD| > 1 s)")
    cols = ["run", "station", "pin", "state", "t_gt"]
    so, bo = S[np.abs(S.dur_diff) > 1000][cols], B[np.abs(B.dur_diff) > 1000][cols]
    shared = len(so.merge(bo, on=cols, how="inner"))
    print("    sender %d, bridge %d, shared %d (%.0f%% of the sender's far tail)"
          % (len(so), len(bo), shared, 100 * shared / len(so)))
    for nm, d in (("bridge", B), ("sender", S)):
        x = np.abs(d.dur_diff.values); k = x <= 1000
        print("    %-7s fraction >100 ms: %.2f%% (all)  ->  %.2f%% (far tail excluded)"
              % (nm, 100 * (x > 100).mean(), 100 * (x[k] > 100).mean()))

    # ---------------------------------------------------------------- [G]
    print("\n[G] Load invariance  (Sec. 4.9)")
    for nm, d in (("bridge", B), ("sender", S)):
        d = d.assign(ad=np.abs(d.dur_diff))
        g = d[d.nstations <= 3].groupby("nstations").agg(
            n=("ad", "size"), median=("ad", "median"),
            over100=("ad", lambda v: 100 * (v > 100).mean()),
            T_eff=("onset_resid", lambda v: v.std(ddof=1) * np.sqrt(12)))
        print("    %s  (events with 1-3 active stations = %d of %d)"
              % (nm, int(g.n.sum()), len(d)))
        print("      " + g.round(2).to_string().replace("\n", "\n      "))
        print("      spearman |dD| vs active stations = %+.3f ; vs local event rate = %+.3f"
              % (stats.spearmanr(d.nstations, d.ad)[0], stats.spearmanr(d.rate, d.ad)[0]))
        print("      local event rate range: %d-%d transitions per 1 s window"
              % (d.rate.min(), d.rate.max()))

    # ---------------------------------------------------------------- [H]
    print("\n[H] Link quality -> T_eff -> fidelity  (per-run, n = 11)")
    rtt = np.array([pd.read_csv(resolve(dd, f"network_ping_log_{i}.csv"))["RTT_ms"].mean()
                    for i in range(1, N_RUNS + 1)])
    ov  = np.array([100 * (np.abs(S[S.run == i].dur_diff) > 100).mean() for i in range(1, N_RUNS + 1)])
    for x, y, lab in ((rtt, prT, "mean RTT  vs T_eff        "),
                      (prT, ov,  "T_eff     vs %|dD|>100 ms "),
                      (rtt, ov,  "mean RTT  vs %|dD|>100 ms ")):
        r, p = stats.pearsonr(x, y)
        print("    %s  Pearson r = %+.3f, p = %.3f" % (lab, r, p))
    print("    per-run mean RTT range %.2f-%.2f ms ; per-run %%>100 ms range %.2f-%.2f"
          % (rtt.min(), rtt.max(), ov.min(), ov.max()))
    sds = [pd.read_csv(resolve(dd, f"network_ping_log_{i}.csv"))["RTT_ms"].std(ddof=1)
           for i in range(1, N_RUNS + 1)]
    print("    per-run RTT SD: max %.1f ms against %.1f-%.1f ms elsewhere"
          % (max(sds), min(sds), sorted(sds)[-2]))
    print("\n" + "=" * 78)


if __name__ == "__main__":
    main()
