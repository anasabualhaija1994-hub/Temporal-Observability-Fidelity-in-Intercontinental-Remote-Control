import argparse, glob, os
import numpy as np
import pandas as pd
from scipy import stats
from fidelity_analysis import analyse_process_bounds, analyse_throughput

EXCLUDED_PINS   = {"SYSTEM_TRIGGER", "COLOR"}
MATCH_WINDOW_MS = 200.0
N_RUNS          = 11
QUANT_MS        = 10.0    # logging quantisation applied at every vantage point
BROADCAST_MS    = 20.0    # controller periodic state-broadcast period (50 Hz)

# ------------------------------------------------------------------------- I/O
def resolve(data_dir, filename):
    direct = os.path.join(data_dir, filename)
    if os.path.exists(direct):
        return direct
    hits = sorted(glob.glob(os.path.join(data_dir, "*", filename)))
    if hits:
        return hits[0]
    raise FileNotFoundError(f"{filename} not found under {data_dir}")


def load_pin_log(path):
    d = pd.read_csv(path)
    d.columns = [c.strip() for c in d.columns]
    d["Station"] = d["Station"].astype(str).str.strip()
    d["Pin"]     = d["Pin"].astype(str).str.strip()
    d = d[~d["Pin"].isin(EXCLUDED_PINS)].reset_index(drop=True)
    d["RelativeTime(ms)"] = d["RelativeTime(ms)"].astype(float)
    d["NewState"]    = d["NewState"].astype(str).str.extract(r"(-?\d+)").astype(int)
    d["Duration(ms)"] = d["Duration(ms)"].astype(float)
    return d


# -------------------------------------------------------------- offset / match
def estimate_run_offset(gt_g, ds_g):
    diffs = []
    for key, g in gt_g:
        if key not in ds_g.groups:
            continue
        a = g["RelativeTime(ms)"].values
        b = ds_g.get_group(key)["RelativeTime(ms)"].values
        n = min(len(a), len(b))
        diffs.extend(b[:n] - a[:n])
    return float(np.median(diffs)) if diffs else 0.0


def match_channel(gt_t, gt_d, ds_t, ds_d, window=MATCH_WINDOW_MS):
    used, out = np.zeros(len(ds_t), bool), []
    for i in range(len(gt_t)):
        best_j, best_dt = -1, window + 1.0
        for j in range(len(ds_t)):
            if used[j]:
                continue
            dt = abs(ds_t[j] - gt_t[i])
            if dt < best_dt:
                best_dt, best_j = dt, j
        if best_j >= 0:
            used[best_j] = True
            out.append((i, ds_t[best_j] - gt_t[i], ds_d[best_j] - gt_d[i]))
    return out


def event_table(dd, tag):
    """Per-matched-event table: onset residual, duration distortion, covariates."""
    rows = []
    for i in range(1, N_RUNS + 1):
        gt = load_pin_log(resolve(dd, f"esp32_pin_log_{i}.csv"))
        ds = load_pin_log(resolve(dd, f"{tag}_pin_log_{i}.csv"))
        gt_g = gt.groupby(["Station", "Pin", "NewState"])
        ds_g = ds.groupby(["Station", "Pin", "NewState"])
        off  = estimate_run_offset(gt_g, ds_g)

        t_all = np.sort(gt["RelativeTime(ms)"].values)
        st_sorted = gt.sort_values("RelativeTime(ms)")

        for key, g in gt_g:
            gt_t, gt_d = g["RelativeTime(ms)"].values, g["Duration(ms)"].values
            if key in ds_g.groups:
                dsub  = ds_g.get_group(key)
                ds_t  = dsub["RelativeTime(ms)"].values - off
                ds_d  = dsub["Duration(ms)"].values
            else:
                ds_t = ds_d = np.array([])
            for idx, onres, ddiff in match_channel(gt_t, gt_d, ds_t, ds_d):
                rows.append(dict(run=i, station=key[0], pin=key[1], state=key[2],
                                 t_gt=gt_t[idx], dur_gt=gt_d[idx],
                                 dur_diff=ddiff, onset_resid=onres))
    df = pd.DataFrame(rows)
    # add load covariates run by run
    out = []
    for i, g in df.groupby("run"):
        gt = load_pin_log(resolve(dd, f"esp32_pin_log_{i}.csv"))
        t  = np.sort(gt["RelativeTime(ms)"].values)
        st = gt.sort_values("RelativeTime(ms)")
        lo = np.searchsorted(t, g.t_gt.values - 500, "left")
        hi = np.searchsorted(t, g.t_gt.values + 500, "right")
        gg = g.copy()
        gg["rate"]      = hi - lo
        gg["nstations"] = [st.iloc[a:b].Station.nunique() for a, b in zip(lo, hi)]
        out.append(gg)
    return pd.concat(out).reset_index(drop=True)


# --------------------------------------------------------- observation-window model
def q(x):
    return np.round(x / QUANT_MS) * QUANT_MS


def simulate(T, rho=0.0, n=3_000_000, seed=0):
    """Forward model: uniform observation window of width T on onset and offset,
    then the same 10 ms logging quantisation the real logs carry."""
    rng  = np.random.default_rng(seed)
    ton  = rng.uniform(0, QUANT_MS, n)          # random phase w.r.t. the 10 ms grid
    toff = rng.uniform(0, QUANT_MS, n)
    if rho == 0.0:
        uon, uoff = rng.uniform(0, T, n), rng.uniform(0, T, n)
    else:                                        # Gaussian copula for correlated errors
        z1 = rng.standard_normal(n)
        z2 = rho * z1 + np.sqrt(1 - rho ** 2) * rng.standard_normal(n)
        uon, uoff = stats.norm.cdf(z1) * T, stats.norm.cdf(z2) * T
    onset = q(ton + uon) - q(ton)
    dur   = (q(toff + uoff) - q(ton + uon)) - (q(toff) - q(ton))
    return onset - np.median(onset), dur


def calibrate_T(target_sd, seed):
    """Estimate T_eff from the onset-residual SD alone (no duration data used)."""
    lo, hi = 1.0, 400.0
    for _ in range(35):
        mid = (lo + hi) / 2
        r, _ = simulate(mid, 0.0, 400_000, seed)
        if r.std(ddof=1) < target_sd:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def bands(x):
    a = np.abs(x)
    return (np.median(a), 100 * (a <= 10).mean(), 100 * (a <= 20).mean(),
            100 * (a <= 50).mean(), 100 * (a > 100).mean(), np.percentile(a, 95))


# ----------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    dd, SEED = a.data_dir, a.seed

    print("=" * 78)
    print("OBSERVATION-WINDOW ANALYSIS   (seed = %d)" % SEED)
    print("=" * 78)

    B = event_table(dd, "bridge")
    S = event_table(dd, "sender")

    # ---------------------------------------------------------------- [A]
    print("\n[A] Arrival-burst structure  (Sec. 4.8)")
    for tag in ("bridge", "sender"):
        modes = []
        for i in range(1, N_RUNS + 1):
            d = load_pin_log(resolve(dd, f"{tag}_pin_log_{i}.csv"))
            g = np.diff(np.unique(d["RelativeTime(ms)"].values))
            modes.append(pd.Series(g[g <= 400]).mode().iloc[0])
        m = pd.Series(modes).mode().iloc[0]
        print("    %-7s modal inter-arrival gap = %.0f ms in %d/11 runs  (all values %s)"
              % (tag, m, int((np.array(modes) == m).sum()), sorted(set(modes))))
    per = []
    for i in range(1, N_RUNS + 1):
        d = load_pin_log(resolve(dd, f"sender_pin_log_{i}.csv"))
        g = np.diff(np.unique(d["RelativeTime(ms)"].values))
        per.append(np.median(g[(g >= 100) & (g <= 250)]))
    rtt_all = np.concatenate([pd.read_csv(resolve(dd, f"network_ping_log_{i}.csv"))["RTT_ms"].values
                              for i in range(1, N_RUNS + 1)])
    print("    sender burst period (median of 100-250 ms gaps) = %.0f ms in all 11 runs"
          % np.mean(per))
    print("    burst period / mean ping RTT (%.2f ms) = %.2f" % (rtt_all.mean(), np.mean(per) / rtt_all.mean()))

    # ---------------------------------------------------------------- [B][C]
    print("\n[B] Effective observation window T_eff  (calibrated on onset residuals ONLY)")
    T = {}
    for nm, d in (("bridge", B), ("sender", S)):
        T[nm] = calibrate_T(d.onset_resid.std(ddof=1), SEED)
    print("    T_eff(bridge) = %.1f ms ;  T_eff(sender) = %.1f ms ;  ratio = %.2f"
          % (T["bridge"], T["sender"], T["sender"] / T["bridge"]))
    prT = np.array([S[S.run == i].onset_resid.std(ddof=1) * np.sqrt(12) for i in range(1, N_RUNS + 1)])
    print("    per-run sender T_eff = %.1f +/- %.1f ms (range %.1f-%.1f)"
          % (prT.mean(), prT.std(ddof=1), prT.min(), prT.max()))

    print("\n[C] Out-of-sample model test  (NOTHING fitted to duration data)")
    for nm, d in (("bridge", B), ("sender", S)):
        on_m, du_m = simulate(T[nm], 0.0, 3_000_000, SEED + 77)
        mo, po = np.abs(d.onset_resid.values), np.abs(on_m)
        print("    %-7s onset  : median %.0f/%.0f ms, p95 %.0f/%.0f ms   (measured/model)"
              % (nm, np.median(mo), np.median(po), np.percentile(mo, 95), np.percentile(po, 95)))
        me, mo_ = bands(d.dur_diff.values), bands(du_m)
        print("    %-7s duration: median %.0f/%.0f | <=10ms %.1f/%.1f%% | <=20ms %.1f/%.1f%% "
              "| <=50ms %.1f/%.1f%% | >100ms %.2f/%.2f%%"
              % (nm, me[0], mo_[0], me[1], mo_[1], me[2], mo_[2], me[3], mo_[3], me[4], mo_[4]))
    tgt = 100 * (np.abs(B.dur_diff.values) <= 10).mean()
    best = min(((r, abs(100 * (np.abs(simulate(T["bridge"], r, 800_000, SEED + 9)[1]) <= 10).mean() - tgt))
                for r in np.arange(0.0, 0.95, 0.05)), key=lambda z: z[1])
    print("    bridge onset/offset error correlation reproducing the measured spread: rho = %.2f"
          % best[0])

    # ---------------------------------------------------------------- [D]
    Ts = T["sender"]
    print("\n[D] Closed form  P(|dD|<=a) = 1-(1-a/T_eff)^2   (Eq. 2), T_eff = %.1f ms" % Ts)
    print("    median|dD| = 0.293*T_eff = %.1f ms" % (0.29289 * Ts))
    for x in (10, 20, 50, 100):
        print("      P(|dD| <= %3d ms) = %5.1f%%" % (x, 100 * (1 - (1 - x / Ts) ** 2)))
    print("    design inversion  T_eff <= a/(1-sqrt(1-p))   (Eq. 3)")
    for x in (10, 50, 100):
        for p in (0.95, 0.99):
            print("      +/-%3d ms at %2.0f%% of events  ->  T_eff <= %6.1f ms"
                  % (x, 100 * p, x / (1 - np.sqrt(1 - p))))
    print("    at T_eff = %.0f ms (broadcast period): median|dD| = %.1f ms"
          % (BROADCAST_MS, 0.29289 * BROADCAST_MS))

    # ---------------------------------------------------------------- [E]
    print("\n[E] Clock-rate drift")
    print("    (i) Insensitive baseline test: does distortion grow with the duration measured?")
    for nm, d in (("bridge", B), ("sender", S)):
        qd  = pd.qcut(d.dur_gt, 10, duplicates="drop")
        med = d.groupby(qd, observed=True).dur_diff.median().values
        D   = d.groupby(qd, observed=True).dur_gt.median().values
        print("      %-7s decile medians (D from %.0f ms to %.1f s): %s"
              % (nm, D.min(), D.max() / 1000, med.astype(int).tolist()))
    print("      -> flat at the 10 ms logging resolution; a single 10 ms step over the")
    print("         60.9 s longest decile is only ~%.0f ppm, so this test cannot resolve" % (10 / 60.9e3 * 1e6))
    print("         drift below that level. It does NOT show drift is absent (see (ii)).")
    print("    (ii) Sensitive test: per-run linear regression of onset residual on elapsed time")
    drift = {}
    for nm, d in (("bridge", B), ("sender", S)):
        sl = np.array([stats.linregress(g.t_gt, g.onset_resid).slope * 1e6 for _, g in d.groupby("run")])
        drift[nm] = sl
        print("      %-7s per-run drift (ppm): %s" % (nm, np.round(sl, 1).tolist()))
        print("              mean %.1f +/- %.1f ppm (SE %.1f), range %.1f to %.1f, all-same-sign=%s"
              % (sl.mean(), sl.std(ddof=1), sl.std(ddof=1) / np.sqrt(len(sl)), sl.min(), sl.max(),
                 len(set(np.sign(sl))) == 1))
    print("      bridge drift accumulated over one 589.81 s run: %.1f ms"
          % (drift["bridge"].mean() * 1e-6 * 589810))
    print("      bridge drift expressed per minute of state duration: %.2f ms/min"
          % (drift["bridge"].mean() * 1e-6 * 60000))
    res = np.concatenate([(g.onset_resid - np.polyval(np.polyfit(g.t_gt, g.onset_resid, 1), g.t_gt)).values
                          for _, g in B.groupby("run")])
    print("      bridge T_eff: raw %.1f ms  ->  %.1f ms after removing each run's linear drift"
          % (calibrate_T(B.onset_resid.std(ddof=1), SEED), calibrate_T(res.std(ddof=1), SEED)))

    # ---------------------------------------------------------------- [F]
    print("\n[F] Far-tail attribution  (|dD| > 1 s) and its link to spurious pulses (Sec. 4.4)")
    cols = ["run", "station", "pin", "state", "t_gt"]
    so, bo = S[np.abs(S.dur_diff) > 1000][cols], B[np.abs(B.dur_diff) > 1000][cols]
    shared = len(so.merge(bo, on=cols, how="inner"))
    print("    sender %d, bridge %d, shared %d (%.0f%% of the sender's far tail)"
          % (len(so), len(bo), shared, 100 * shared / len(so)))
    for nm, d in (("bridge", B), ("sender", S)):
        x = np.abs(d.dur_diff.values); k = x <= 1000
        print("    %-7s fraction >100 ms: %.2f%% (all)  ->  %.2f%% (far tail excluded)"
              % (nm, 100 * (x > 100).mean(), 100 * (x[k] > 100).mean()))
    all_over100 = 100 * (np.abs(S.dur_diff) > 100).mean()
    excl_over100 = 100 * (np.abs(S.dur_diff[np.abs(S.dur_diff) <= 1000]) > 100).mean()
    model_over100 = bands(simulate(T["sender"], 0.0, 3_000_000, SEED + 77)[1])[4]
    print("    measured %.2f%% -> %.2f%% once the on-site-linked far tail is excluded (model predicts %.2f%%)"
          % (all_over100, excl_over100, model_over100))
    print("    share of the (measured - model) gap explained by the on-site far tail: %.0f%%"
          % (100 * (all_over100 - excl_over100) / (all_over100 - model_over100)))
    ft = B[np.abs(B.dur_diff) > 1000]
    linked = 0
    for _, r in ft.iterrows():
        d = load_pin_log(resolve(dd, f"bridge_pin_log_{int(r.run)}.csv"))
        x = d[(d.Station == r.station) & (d.Pin == r.pin)]
        n = ((x["RelativeTime(ms)"] > r.t_gt - r.dur_gt + 110) & (x["RelativeTime(ms)"] < r.t_gt - 10)).sum()
        linked += n >= 2
    print("    gateway far-tail events with a spurious pulse inside the true-state interval: %d of %d"
          % (linked, len(ft)))

    # ---------------------------------------------------------------- [I] missed / spurious mechanism
    print("\n[I] The 13 unmatched Sender transitions (Sec. 4.4): late arrival vs. log truncation")
    for i in range(1, N_RUNS + 1):
        gt = load_pin_log(resolve(dd, f"esp32_pin_log_{i}.csv")); ds = load_pin_log(resolve(dd, f"sender_pin_log_{i}.csv"))
        gg = gt.groupby(["Station", "Pin", "NewState"]); dg = ds.groupby(["Station", "Pin", "NewState"])
        off = estimate_run_offset(gg, dg); last = ds["RelativeTime(ms)"].max() - off
        for key, g in gg:
            gt_t = g["RelativeTime(ms)"].values
            dtv = dg.get_group(key)["RelativeTime(ms)"].values - off if key in dg.groups else np.array([])
            used = np.zeros(len(dtv), bool)
            for t in gt_t:
                bj, bd = -1, MATCH_WINDOW_MS + 1.0
                for j in range(len(dtv)):
                    if not used[j] and abs(dtv[j] - t) < bd: bd, bj = abs(dtv[j] - t), j
                if bj >= 0: used[bj] = True
                else:
                    un = dtv[~used]
                    if t > last:
                        print("    run %2d %-30s truncated: event after end of Sender log (log ends %.0f ms)"
                              % (i, str(key), last))
                    else:
                        near = un[np.argmin(np.abs(un - t))] - t if len(un) else np.nan
                        print("    run %2d %-30s late arrival: nearest unmatched Sender entry %+.0f ms away (outside %.0f ms window)"
                              % (i, str(key), near, MATCH_WINDOW_MS))

    print("\n[J] Spurious transitions are phantom pulses, not duplicates (Sec. 4.4)")
    def spurious(tag):
        rows = []
        for i in range(1, N_RUNS + 1):
            gt = load_pin_log(resolve(dd, f"esp32_pin_log_{i}.csv")); ds = load_pin_log(resolve(dd, f"{tag}_pin_log_{i}.csv"))
            gg = gt.groupby(["Station", "Pin", "NewState"]); dg = ds.groupby(["Station", "Pin", "NewState"])
            off = estimate_run_offset(gg, dg)
            for key, d in dg:
                dtv = d["RelativeTime(ms)"].values - off; ddv = d["Duration(ms)"].values
                gtt = gg.get_group(key)["RelativeTime(ms)"].values if key in gg.groups else np.array([])
                used = np.zeros(len(dtv), bool)
                for t in gtt:
                    bj, bd = -1, MATCH_WINDOW_MS + 1.0
                    for j in range(len(dtv)):
                        if not used[j] and abs(dtv[j] - t) < bd: bd, bj = abs(dtv[j] - t), j
                    if bj >= 0: used[bj] = True
                for j in np.where(~used)[0]:
                    rows.append((i,) + key + (dtv[j], ddv[j]))
        return pd.DataFrame(rows, columns=["run", "station", "pin", "state", "t", "dur"])
    b_spur, s_spur = spurious("bridge"), spurious("sender")
    for tag in ("bridge", "sender"):
        na = 0
        for i in range(1, N_RUNS + 1):
            d = load_pin_log(resolve(dd, f"{tag}_pin_log_{i}.csv"))
            for _, x in d.groupby(["Station", "Pin"]):
                s_ = x.NewState.values
                na += int((s_[1:] == s_[:-1]).sum())
        print("    %-7s consecutive same-state log entries (would indicate a true duplicate): %d" % (tag, na))
    p = b_spur[b_spur.dur <= 100]
    print("    bridge spurious n=%d; %d of them close a phantom pulse of <=100 ms (range %.0f-%.0f, median %.0f ms)"
          % (len(b_spur), len(p), p.dur.min(), p.dur.max(), p.dur.median()))
    print("    concentrated on: \n      " + b_spur.groupby(["station", "pin"]).size()
          .sort_values(ascending=False).head(5).to_string().replace("\n", "\n      "))
    m = sum(len(s_spur[(s_spur.run == r.run) & (s_spur.station == r.station) & (s_spur.pin == r.pin)
                        & (s_spur.state == r.state) & (np.abs(s_spur.t - r.t) < 200)]) > 0
            for _, r in b_spur.iterrows())
    print("    bridge spurious transitions that reappear at the Sender within 200 ms: %d of %d"
          " (local origin, not the link)" % (m, len(b_spur)))

    print("\n[K] Short-state duration bias (Sec. 4.5): distortion is not signed-symmetric for dur_gt<=150 ms")
    for nm, d in (("bridge", B), ("sender", S)):
        x = d[(d.dur_gt > 0) & (d.dur_gt <= 150)]
        print("    %-7s n=%d median %+.0f ms mean %+.1f ms  (all-durations signed median = %+.0f ms)"
              % (nm, len(x), x.dur_diff.median(), x.dur_diff.mean(), d.dur_diff.median()))

    # ---------------------------------------------------------------- [G]
    print("\n[G] Load invariance  (Sec. 4.9)")
    for nm, d in (("bridge", B), ("sender", S)):
        d = d.assign(ad=np.abs(d.dur_diff))
        g = d[d.nstations <= 3].groupby("nstations").agg(
            n=("ad", "size"), median=("ad", "median"),
            over100=("ad", lambda v: 100 * (v > 100).mean()),
            T_eff=("onset_resid", lambda v: v.std(ddof=1) * np.sqrt(12)))
        print("    %s  (events with 1-3 active stations = %d of %d)"
              % (nm, int(g.n.sum()), len(d)))
        print("      " + g.round(2).to_string().replace("\n", "\n      "))
        print("      spearman |dD| vs active stations = %+.3f ; vs local event rate = %+.3f"
              % (stats.spearmanr(d.nstations, d.ad)[0], stats.spearmanr(d.rate, d.ad)[0]))
        print("      local event rate range: %d-%d transitions per 1 s window"
              % (d.rate.min(), d.rate.max()))

    # ---------------------------------------------------------------- [H]
    print("\n[H] Link quality -> T_eff -> fidelity  (per-run, n = 11, and n = 10 excluding the")
    print("    one run with unusually high short-term RTT dispersion)")
    rtt = np.array([pd.read_csv(resolve(dd, f"network_ping_log_{i}.csv"))["RTT_ms"].mean()
                    for i in range(1, N_RUNS + 1)])
    ov  = np.array([100 * (np.abs(S[S.run == i].dur_diff) > 100).mean() for i in range(1, N_RUNS + 1)])
    sds = np.array([pd.read_csv(resolve(dd, f"network_ping_log_{i}.csv"))["RTT_ms"].std(ddof=1)
                     for i in range(1, N_RUNS + 1)])
    k = sds < sds.max()
    for x, y, lab in ((rtt, prT, "mean RTT  vs T_eff        "),
                      (prT, ov,  "T_eff     vs %|dD|>100 ms "),
                      (rtt, ov,  "mean RTT  vs %|dD|>100 ms ")):
        r, p = stats.pearsonr(x, y); rk, pk = stats.pearsonr(x[k], y[k])
        print("    %s  all: r = %+.3f, p = %.3f   |  excl. outlier run: r = %+.3f, p = %.3f"
              % (lab, r, p, rk, pk))
    print("    per-run mean RTT range %.2f-%.2f ms ; per-run %%>100 ms range %.2f-%.2f"
          % (rtt.min(), rtt.max(), ov.min(), ov.max()))
    print("    per-run RTT SD: max %.1f ms (run %d) against %.1f-%.1f ms elsewhere"
          % (sds.max(), int(np.argmax(sds)) + 1, sds[k].min(), sds[k].max()))
    print("    note: the T_eff-vs->100ms correlation is partly structural, since both are")
    print("    computed from the same per-run Sender onset residuals / duration distortions.")

    # ---------------------------------------------------------------- [L]
    print("\n[L] Section 4.7 process-time bounds vs. run-to-run variability")
    B7 = analyse_process_bounds(dd); Tp = analyse_throughput(dd)
    se = Tp["sd"] / np.sqrt(N_RUNS)
    print("    process-time mean +/- SD = %.2f +/- %.2f s ; SE of the mean = %.2f s"
          % (Tp["mean"], Tp["sd"], se))
    for k2, lbl in [("upper58", "upper bound (58 blocks)"), ("chain28_retrieve", "structure-aware bound")]:
        m, sd_, lo, hi = B7[k2]
        print("    %-24s = %.2f s = %.1f x SE of the process-time mean, %.1f x its SD"
              % (lbl, m, m / se, m / Tp["sd"]))

    # ---------------------------------------------------------------- [M]
    print("\n[M] Station-specific time origins and T_eff  (Sec. 3.3, 4.8)")
    print("    HBW takes its origin from its own trigger edge; the other controllers on")
    print("    receipt of the relayed SET_T_ZERO marker. A single per-run offset leaves")
    print("    station-specific residual offsets, which (like drift) are common to the onset")
    print("    and offset of a state and cancel in its duration.")
    for nm, d in (("bridge", B), ("sender", S)):
        piv = d.groupby(["run", "station"]).onset_resid.median().unstack()
        print("    %-7s per-station median onset residual (ms), mean over runs: %s"
              % (nm, piv.mean().round(1).to_dict()))
        r1 = d.onset_resid - d.groupby(["run", "station"]).onset_resid.transform("median")
        tmp = d.assign(r1=r1)
        r2 = pd.concat([g.r1 - np.polyval(np.polyfit(g.t_gt, g.r1, 1), g.t_gt)
                        for _, g in tmp.groupby("run")])
        T1 = calibrate_T(r1.std(ddof=1), SEED); T2 = calibrate_T(r2.std(ddof=1), SEED)
        print("    %-7s T_eff: single offset %.1f ms -> per-station offset %.1f ms "
              "-> + linear drift removed %.1f ms" % (nm, T[nm], T1, T2))
        m = bands(simulate(T2, 0.0, 3_000_000, SEED + 77)[1]); e = bands(d.dur_diff.values)
        print("    %-7s duration with corrected T_eff (measured/model): median %.0f/%.0f | "
              "<=10ms %.1f/%.1f%% | <=20ms %.1f/%.1f%% | <=50ms %.1f/%.1f%%"
              % (nm, e[0], m[0], e[1], m[1], e[2], m[2], e[3], m[3]))
        print("    %-7s median|dD| implied by Eq. (2) = 0.293*T_eff = %.1f ms" % (nm, 0.29289 * T2))
    print("\n" + "=" * 78)


if __name__ == "__main__":
    main()
